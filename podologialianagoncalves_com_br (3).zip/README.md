# Crawl4AI Dataset: podologialianagoncalves_com_br

**URL Original:** https://podologialianagoncalves.com.br/  
**Domínio:** podologialianagoncalves.com.br  
**Data da Extração:** 31/08/2026, 10:35:00  
**Total de Páginas:** 28  
**Total de Imagens:** 149  
**Total de Links Internos:** 515  
**Total de Links Externos:** 153  
**Total de Palavras:** 32.317  
**Duração da Varredura:** 25.0 segundos  

---

## 📁 Estrutura do Arquivo ZIP

- `manifest.json` - Metadados gerais da extração, configurações usadas e resumo.
- `content_all.md` - Arquivo Markdown unificado ideal para ingestão em LLMs, RAG, embeddings e vector databases.
- `data.json` - Base de dados completa em JSON estruturado com todas as páginas, metadados e tags.
- `links.csv` & `links.json` - Mapeamento completo de todos os links internos e externos encontrados.
- `images.json` - Catálogo com todas as imagens, URLs absolutas, textos alternativos (alt) e contexto.
- `structured_data.json` - Entidades Schema.org / JSON-LD extraídas.
- `images/` - Todos os arquivos binários das imagens baixadas do site (JPG, PNG, WebP, SVG, GIF) e seu manifesto (`images_manifest.json`).
- `pages/` - Cada página extraída individualmente:
  - `*.md` - Markdown limpo formatado
  - `*.json` - Metadados e dados estruturados da página
  - `*.txt` - Texto plano sem formatação

---

## 🤖 Como Utilizar com Modelos de IA (LLMs) & RAG

Este conjunto de dados foi processado e limpo segundo os padrões do Crawl4AI para maximizar a densidade de informação para LLMs:

1. **RAG / Vector DBs (Pinecone, Chroma, FAISS, Weaviate):** Ingeste o arquivo `content_all.md` ou as páginas individuais em `pages/*.md`.
2. **Context Injection:** Utilize `content_all.md` diretamente no contexto de prompts do Gemini, Claude ou GPT.
3. **Análise de Links e SEO:** Analise `links.csv` para mapear a arquitetura de links internos do site.

---
*Gerado automaticamente pelo Crawl4AI Web Scraper & Archiver.*
