# Podologia Clínica - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/podologia-clinica
- **Data:** 2026-08-31T10:35:22.886Z

---

# Podologia Clínica

# Ela achava que o bebê tinha cólica. A dor vinha de outro lugar.

Quando a causa mais improvável é a que ninguém pensa em checar — e a que mais alivia quando finalmente é tratada.

Categoria: PodopediatriaTempo de leitura: 6 min

---

Eram três da manhã quando a Juliana chegou no consultório com o celular cheio de anotações. Horário das mamadas, horário do choro, duração de cada crise. Duas semanas de choro. Ela tinha certeza: era cólica.

O bebê tinha 23 dias. Chorava em momentos que pareciam aleatórios, mas com uma intensidade que ia além do desconforto digestivo normal. O pediatra já tinha descartado infecção. A gastroenterologista havia passado seis tipos de fórmulas diferentes. Nada resolvia.

Quando examinei o pé direito do bebê, encontrei em trinta segundos o que duas semanas de consultas não haviam identificado: a borda da unha do dedão estava encravada no tecido lateral. A pele ao redor estava vermelha, levemente inchada. Sem secreção — ainda era cedo. Mas dolorosa o suficiente para despertar qualquer recém-nascido.

Juliana olhou para mim e perguntou: “Isso pode causar todo esse choro?”

Pode. E causa com mais frequência do que qualquer um imagina.

A dor de uma unha encravada em bebê é real, intensa — e completamente invisível para quem não sabe onde procurar.

## Por que o dedão do seu bebê pode estar doendo agora

Quando pensamos em unha encravada, pensamos em adulto, calçado apertado, corte errado. Em bebês, a lógica é completamente diferente — e mais difícil de suspeitar justamente por isso.

As unhas dos recém-nascidos são finas, maleáveis, e crescem numa velocidade surpreendente. Em alguns bebês, especialmente nas primeiras semanas de vida, a pele ao redor do dedão se forma mais espessa, mais “envolvente” do que a unha consegue empurrar. O resultado: a borda lateral da unha começa a pressionar o tecido sem que nenhum adulto tenha feito nada de errado.

Não é culpa de como você cortou a unha. Não é culpa do tamanho da meia. É anatomia — e acontece em bebês perfeitamente saudáveis, de famílias que cuidam muito bem dos seus filhos.

O problema é que ninguém ensina os pais a procurar isso. E o bebê não consegue apontar onde dói.

## O que você está vendo — e interpretando errado

O choro de um bebê com unha encravada tem uma característica: piora nos momentos de contato com o pé. Quando você coloca a meia, quando veste o macacão, quando segura o pezinho para trocar a fralda. Mas como esses momentos acontecem junto com outras atividades — a troca geralmente antecede a mamada, a mamada antecede o sono — a conexão raramente é feita.

Os sinais que merecem atenção:

-   Choro intenso e desproporcional ao manusear ou vestir o pé
-   Vermelhidão na lateral do dedão — especialmente do lado interno
-   Inchaço pequeno ao redor da unha
-   Bebê que afasta o pé quando você toca a região
-   Febre sem outro foco identificado (sinal de que a infecção já começou)

**Atenção imediata** Se você observar secreção amarelada ou esverdeada ao redor da unha, a infecção já está instalada. Não espere — procure atendimento no mesmo dia.

## O instinto de resolver em casa — e por que ele pode piorar tudo

Entendo o impulso. Ver seu filho chorando e ter nas mãos uma tesoura, uma pomada, um YouTube cheio de tutoriais — a tentação é real.

Mas em bebês, a margem de erro é pequena demais.

Empurrar a pele para liberar a unha sem técnica adequada pode aprofundar o encravamento. Cortar a ponta da unha em ângulo errado cria uma espícula que vai encavar novamente em dias. Aplicar pomada sem resolver a causa é tratar o sintoma enquanto o problema avança.

E existe um risco que os pais raramente consideram: qualquer microlesão na pele de um recém-nascido é uma porta de entrada. A infecção que começa na lateral de uma unhinha pode progredir mais rápido do que em adultos, porque o sistema imune ainda está se calibrando.

Não é falta de habilidade — é que esse procedimento foi desenvolvido para ser feito por mãos treinadas, com instrumental adequado, em menos tempo do que você imagina.

## Como é o tratamento — e o que os pais sempre me dizem depois

Quando atendo um bebê com unha encravada, os pais entram tensos, segurando o filho como se qualquer movimento pudesse machucar ainda mais. O procedimento em recém-nascidos geralmente dura menos de um minuto.

Usamos técnica específica para a faixa etária — sem agulha injetável, com analgesia tópica quando necessário, com o bebê no colo de quem trouxe. O encravamento é resolvido, a área é tratada, e os pais recebem orientação detalhada sobre como cuidar em casa nos dias seguintes.

A frase que ouço com mais frequência quando termino é: “Não acredito que era isso.”

Não existe idade mínima para atendimento podológico. Já atendi bebês com dias de vida. O que existe é a crença equivocada de que podologia é coisa de adulto — e enquanto essa crença persiste, bebês continuam chorando por uma causa que tem solução em uma consulta.

## Uma última coisa

A Juliana voltou três dias depois da consulta. O bebê estava dormindo. Ela estava com sono — o tipo de sono que só vem depois que uma angústia que durava semanas finalmente termina.

“Ele dormiu a noite inteira”, ela disse.

Se você está lendo isso às três da manhã com um bebê no colo, verifique os pés antes de tentar mais uma coisa. Pode ser mais simples — e mais próximo — do que você imagina.

Seu bebê está chorando sem causa aparente?

Agende uma avaliação. O atendimento é rápido, os pais ficam presentes durante todo o procedimento, e o alívio geralmente é imediato.[Agendar pelo WhatsApp →](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Li%20o%20artigo%20sobre%20unha%20encravada%20em%20beb%C3%AA%20e%20gostaria%20de%20agendar%20uma%20consulta.)

Liana Gonçalves é podóloga com graduação pela Unicesumar, 15 anos de experiência clínica em Campo Grande-MS, e atendimento pediátrico desde recém-nascidos.

## Deixe um comentário [Cancelar resposta](/podologia-clinica/#respond)

O seu endereço de e-mail não será publicado. Campos obrigatórios são marcados com \*

Comentário \*

Nome \* 

E-mail \* 

Site 

 Salvar meus dados neste navegador para a próxima vez que eu comentar.