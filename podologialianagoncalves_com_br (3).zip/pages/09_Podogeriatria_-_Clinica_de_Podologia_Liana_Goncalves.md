# Podogeriatria - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/podogeriatria
- **Data:** 2026-08-31T10:35:04.961Z

---

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20de%20podogeriatria.)

👴 Cuidado especializado para a melhor idade

# Pés que carregaram  
uma vida inteira  
merecem cuidado especializado.

Na terceira idade, os pés mudam — pele mais fina, unhas mais espessas, circulação reduzida e maior risco de complicações. A podogeriatria é o cuidado clínico adaptado para essas necessidades específicas.

✅

**Não é só limpeza.** O atendimento geriátrico envolve avaliação de circulação, sensibilidade, risco de queda, adequação do calçado e identificação precoce de condições que, sem tratamento, podem comprometer seriamente a mobilidade e a qualidade de vida.

[📲 Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20de%20podogeriatria.) [O que avaliamos ↓](#pg-cuidados)

Pós-grad. Geriatria e  
Gerontologia

Consulta R$ 150,00 isenta se  
contratar algum tratamento no mesmo dia

15 anos de experiência  
especializada

4.9 ★ 207 avaliações  
no Google

Entenda o problema

## O pé idoso é clinicamente diferente —  
e precisa de abordagem diferente

Com o envelhecimento, o pé passa por mudanças fisiológicas profundas que alteram sua resposta ao cuidado. O que funciona num adulto jovem pode ser inadequado ou até perigoso em um idoso. Reconhecer essas diferenças é o que define a qualidade do atendimento geriátrico.

🩸🫀❄️🦶

### Circulação reduzida

O fluxo sanguíneo para os membros inferiores diminui progressivamente. Cicatrização mais lenta, maior risco de infecção e menor tolerância a procedimentos mais invasivos.

🧓🧬🩹⚠️

### Pele mais fina e frágil

A perda de elasticidade e hidratação natural torna a pele suscetível a fissuras, bolhas e lesões que num adulto jovem seriam triviais — e num idoso podem complicar rapidamente.

😬💅🩹⚠️

### Unhas mais espessas e quebradiças

O crescimento das unhas diminui e a placa fica mais espessa, densa e difícil de cortar. Corte incorreto causa dor, encravamento e lesões na pele ao redor.

🩺🦶️🫥⚡

### Sensibilidade reduzida

Neuropatia periférica — mesmo sem diabetes — é comum na terceira idade. O pé deixa de avisar quando está sendo machucado, permitindo que feridas evoluam sem dor.

🦶😣⚠️🩺

### Deformidades acumuladas

Décadas de uso incorreto de calçados, alterações posturais e doenças como artrite resultam em deformidades que redistribuem pressão e criam pontos de atrito crônicos.

🧓🦵⬇️🏥

### Risco de queda aumentado

Dor nos pés, calosidades espessas e calçado inadequado comprometem o equilíbrio e a segurança da marcha — um dos principais fatores de risco de quedas em idosos.

⚠️

### Por que problemas nos pés são mais sérios na terceira idade

Uma calosidade espessa num idoso pode esconder uma úlcera se formando por baixo. Uma unha espessada mal cortada pode causar lesão que não cicatriza por semanas. Um fungo não tratado pode disseminar para a pele. **Na terceira idade, problemas nos pés não são pequenos — merecem atenção clínica regular, não esporádica.**

Condições frequentes

## O que tratamos na podogeriatria

Todas as condições podológicas podem afetar idosos — mas algumas são especialmente prevalentes e exigem protocolo adaptado à faixa etária.

✂️

#### Unhas espessadas e de difícil corte

A principal queixa da podogeriatria. Unhas que a pessoa não consegue mais cortar sozinha com segurança — especialmente após os 70 anos. O corte incorreto em casa é a principal causa de lesões em idosos.

🦠

#### Fungos nas unhas (onicomicose)

Prevalência muito alta em idosos — a circulação reduzida favorece a instalação e progressão do fungo. Diagnóstico laboratorial e protocolo adaptado à faixa etária e ao uso de medicamentos.

🦶

#### Calosidades e fissuras no calcanhar

A pele ressecada da terceira idade forma calosidades com mais facilidade e fissuras profundas no calcanhar — que podem sangrar e infectar. Tratamento e hidratação clínica fazem diferença real.

🩹

#### Unha encravada

Comum em idosos que cortam as próprias unhas com dificuldade de visão ou mobilidade reduzida. O protocolo de tratamento considera a fragilidade vascular e cicatricial da faixa etária.

🔴

#### Heloma mole entre os dedos

Calo úmido entre os dedos que pode se tornar porta de entrada para infecção bacteriana. Em idosos, a progressão é mais rápida e o tratamento precisa ser mais cuidadoso.

🩺

#### Pé do diabético idoso

A combinação de diabetes e envelhecimento é o cenário de maior risco em toda a podologia. Acompanhamento mensal obrigatório com protocolo específico — prevenção de úlceras e amputações.

**A frequência ideal para idosos é mensal** — mesmo sem sintomas aparentes. A avaliação regular é o que evita que pequenos problemas se tornem grandes complicações.

[📲 Agendar avaliação](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20de%20podogeriatria.)

Como funciona

## Atendimento Adaptado:  
Técnica e Cuidado para a Terceira Idade

1

Avaliação clínica

### Avaliação geriátrica completa dos pés

A podóloga avalia circulação, sensibilidade, integridade da pele, estado das unhas, deformidades e pontos de pressão. **Para idosos diabéticos, a avaliação de risco é parte central da consulta** — classificação de risco, orientações e plano de acompanhamento são definidos aqui.

2

Procedimento adaptado

### Técnica específica para pele e unhas geriátricas

Instrumental específico para unhas espessas, técnica de corte adaptada à mobilidade e visão do paciente, pressão e velocidade ajustadas para pele mais fina. **Nenhum procedimento é feito sem o cuidado que a fragilidade da faixa etária exige.**

3

Hidratação e laser

### Cuidado completo da pele + laser quando indicado

Hidratação clínica profissional para pele ressecada e fissuras. Laser DMC para cicatrização acelerada de áreas com lesão, inflamação ou infecção fúngica. O laser é especialmente útil em idosos pela sua capacidade de estimular tecidos com circulação comprometida.

4

Orientações completas

### Orientações para família e cuidadores

Quando o idoso tem cuidador ou familiar presente, a podóloga orienta sobre como monitorar os pés em casa, sinais de alerta, como hidratar corretamente, qual calçado usar e quando retornar. **A família é parte do protocolo de cuidado.**

Investimento

Consulta R$ 150,00

Quando necessário tratamento a consulta é isenta se o tratamento for iniciado no mesmo dia · valor conforme condições identificadas

-   Avaliação clínica geriátrica completa
-   Corte e cuidado das unhas com técnica adaptada
-   Remoção de calosidades e tratamento de fissuras
-   Hidratação clínica profissional
-   Laser DMC quando indicado
-   Orientações para família e cuidadores

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20de%20podogeriatria.)

### Frequência recomendada

👴

#### Idoso saudável

A cada 30 dias — unhas crescem mais devagar mas ficam mais espessas; pele precisa de hidratação regular

🩺

#### Idoso diabético

Mensalmente — obrigatório. Combinação de diabetes e envelhecimento é o maior fator de risco em podologia

🦽

#### Mobilidade reduzida

Conforme necessidade — idosos acamados ou com dificuldade de locomoção podem precisar de atenção mais frequente

💊

#### Uso de anticoagulantes

Protocolo específico — medicamentos como warfarina e AAS exigem atenção redobrada durante qualquer procedimento

**Formas de pagamento:** Pix, débito e crédito em até 10 vezes (taxa operadora). Clínica particular — não atendemos convênios.

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20768%20768'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

Especialista responsável

## Formação específica em  
Geriatria e Gerontologia

Liana Gonçalves é pós-graduada em Geriatria e Gerontologia — formação específica para entender as mudanças fisiológicas do envelhecimento e adaptar cada protocolo clínico às necessidades reais do paciente idoso. **Não é o mesmo tratamento de um adulto jovem feito com mais cuidado — é um protocolo genuinamente diferente.**

Combinada com sua pós-graduação em Diabetes e Complicações Crônicas, Liana está entre as podólogas mais bem preparadas de Campo Grande para o atendimento geriátrico — especialmente para o perfil mais crítico: o idoso diabético.

### 👴 Idoso diabético — o perfil de maior risco

A combinação de envelhecimento, diabetes e neuropatia periférica cria o cenário de maior risco em toda a podologia. Liana tem pós-graduação em ambas as áreas e protocolo específico para esse perfil — com avaliação de risco estruturada, acompanhamento mensal e orientação para a família.

✓ Graduação em PodologiaUnicesumar · Nível Superior

✓ Pós-grad. Geriatriae Gerontologia

✓ Pós-grad. Diabetese Complicações Crônicas

✓ Laser DMC TherapyiLib e XT

✓ CIAP Internacional2023 · 2024 · 2025

✓ 15 anos de experiênciaem podologia clínica

🩺

**Indicada por médicos geriátras e clínicos gerais de Campo Grande** para acompanhamento podológico de idosos — especialmente casos com diabetes, neuropatia ou histórico de úlceras.

Dúvidas frequentes

## Perguntas sobre  
Podogeriatria

A partir de que idade é considerado atendimento geriátrico? +

Geralmente a partir dos 60 anos — que é a definição legal de idoso no Brasil. Mas o que define a necessidade de protocolo geriátrico não é só a idade: é a presença de condições associadas ao envelhecimento como circulação reduzida, neuropatia, pele frágil, dificuldade de mobilidade ou uso de múltiplos medicamentos. **Se o paciente tem essas características, o protocolo é adaptado independentemente da idade.**

Meu pai/mãe tem dificuldade de locomoção. Pode ser atendido assim mesmo? +

Sim. A clínica está preparada para receber pacientes com mobilidade reduzida. Acompanhantes e cuidadores são bem-vindos e fazem parte do atendimento — orientamos a família sobre como monitorar os pés em casa. Se tiver alguma necessidade especial de acessibilidade, entre em contato pelo WhatsApp antes de vir para nos prepararmos adequadamente e disponibilizarmos o estacionamento no interior do prédio para maior comodidade do paciente.

Com que frequência o idoso deve fazer podogeriatria? +

Para idosos saudáveis, a cada 30 dias. Para idosos diabéticos, mensalmente — sem exceção. Quanto mais fatores de risco presentes (diabetes, neuropatia, anticoagulantes, mobilidade reduzida), mais importante é a regularidade do acompanhamento. **O atendimento mensal é o que permite identificar problemas antes que se tornem complicações sérias.**

Meu pai usa anticoagulante (warfarina, AAS). Pode fazer o procedimento? +

Sim, com protocolo adaptado. O uso de anticoagulantes exige técnica mais cuidadosa e atenção ao risco de sangramento durante qualquer procedimento. **Informe o uso de medicamentos no agendamento** para que a podóloga se prepare adequadamente. Nunca suspenda medicamentos antes da consulta sem orientação do médico responsável.

O idoso pode fazer o tratamento de fungo nas unhas? +

Sim — e é especialmente importante tratar, pois fungos em idosos tendem a progredir mais rapidamente pela circulação reduzida. O protocolo considera a faixa etária, os medicamentos em uso e o estado geral da pele e da unha. O laser DMC é especialmente indicado para idosos por não exigir medicação sistêmica.

Posso ir como filho/a em nome do meu pai ou mãe para agendar? +

Sim. Filhos e cuidadores podem agendar pelo WhatsApp informando que é para um familiar idoso. Se possível, mencione as principais condições de saúde (diabetes, uso de anticoagulantes, mobilidade reduzida) para que possamos reservar o tempo adequado e nos preparar para o atendimento.

Quem já foi atendido

## O que nossos pacientes  
dizem sobre o atendimento

★★★★★ 4.9 · 207 avaliações no Google

★★★★★

"Acolhedor, ótimo atendimento, passa segurança e confiança. Obrigada!"

L

Luzia Petricio

Verificado no Google

★★★★★

"Atendimento excelente, desde a recepcionista até o procedimento realizado pela doutora Liana. Indico o consultório com certeza!"

A

Avaliação Google

Verificado no Google

★★★★★

"Gostei muito, trabalho sensacional, atenciosos e explicam bem o tratamento para os pés, muito bom mesmo!"

J

Avaliação Google

Verificado no Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

Também atendemos

## Outros Tratamentos na Clínica

Todos os tratamentos com o mesmo cuidado clínico — adaptado para cada faixa etária.

[🦠

### Fungos nas Unhas

Diagnóstico laboratorial e protocolo especializado para todas as idades.

Saiba mais →](/fungos-micose-onicomicose/) [🩺

### Pé do Diabético

Acompanhamento mensal especializado. Prevenção de úlceras e amputações.

Saiba mais →](/pe-do-diabetico/) [🦶

### Calos e Calosidades

Remoção completa com protocolo específico para pele geriátrica.

Saiba mais →](/calos-e-calosidades/) [✨

### Podoprofilaxia

Manutenção clínica mensal — a base do cuidado preventivo na terceira idade.

Saiba mais →](/podoprofilaxia/)

👴 Cuidado que respeita a idade

## Seus pés merecem cuidado  
na medida certa para esta fase.

Agende a consulta — na primeira avaliação identificamos todas as condições presentes, definimos o protocolo adequado e orientamos a família sobre como monitorar em casa.

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20de%20podogeriatria.) [📞 (67) 3305-0219](tel:6733050219)

Seg–Sex · 8h às 12h e 13h às 17h  
Rua Doutor Arthur Jorge, 2523 · Campo Grande-MS

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD