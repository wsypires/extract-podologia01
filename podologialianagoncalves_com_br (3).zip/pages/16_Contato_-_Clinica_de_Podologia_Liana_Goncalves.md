# Contato - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/contato-podologa/
- **Data:** 2026-08-31T10:35:10.267Z

---

[![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)](https://podologialianagoncalves.com.br/)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

📍 Campo Grande-MS

# Agende sua Consulta —  
estamos prontos  
para te atender

O primeiro passo é simples: mande uma mensagem pelo WhatsApp ou ligue. Emily vai encontrar o melhor horário para você.

## Como nos  
encontrar

[

WhatsApp — mais rápido

(67) 99916-0929

Resposta rápida · Seg–Sex · 8h às 12h e 13h às 17h

→

](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)[

☎️

Telefone fixo

(67) 3305-0219

Seg–Sex · 8h às 12h e 13h às 17h

→

](tel:6733050219)[

📱

Celular

(67) 99916-0929

Seg–Sex · 8h às 12h e 13h às 17h

→

](tel:67999160929)[

📍

Endereço

Rua Doutor Arthur Jorge, 2523

Monte Castelo · Campo Grande-MS · CEP 79010-210

→

](https://maps.google.com/?q=Rua+Doutor+Arthur+Jorge+2523+Campo+Grande+MS)

🕐

Horário de Atendimento

Segunda a Sexta

8h às 12h · 13h às 17h

💳

### Formas de pagamento

Pix · Débito · Crédito em até 10x (taxa operadora) · Dinheiro  
Clínica particular — não atendemos convênios

### 📌 Como chegar

A clínica fica na Rua Doutor Arthur Jorge, 2523, no bairro Monte Castelo. Próximo à Av. Afonso Pena. Há estacionamento na rua.

Antes de entrar em contato

## Dúvidas frequentes  
sobre agendamento

Como faço para agendar uma consulta? +

O jeito mais rápido é pelo WhatsApp — mande uma mensagem para **(67) 99916-0929** e Emily vai confirmar o horário disponível. Você também pode ligar para **(67) 3305-0219**. O agendamento é feito de Segunda a Sexta feira · Das 8h às 12h e das 13h às 17h.

Preciso levar algum documento ou exame? +

Não é obrigatório mas facilita o cadastro em nosso sistema para a primeira consulta. Se você tiver exames anteriores relacionados ao problema — como exame micológico para fungo, ou histórico de tratamentos — traga para que a podóloga possa avaliar o histórico completo. Diabéticos devem trazer resultados recentes de glicemia quando disponíveis.

Vocês atendem por convênio ou plano de saúde? +

A clínica é particular. Aceitamos Pix, débito e crédito em até 10 vezes (sujeito à taxa da operadora). Se você tiver plano de saúde com cobertura para podologia, pode solicitar reembolso diretamente à sua operadora — **emitimos nota fiscal de todos os serviços prestados.**

Qual o valor da consulta? +

A consulta inicial custa **R$ 150** e é isenta quando o tratamento é iniciado na mesma sessão. A podoprofilaxia tem valor **a partir de R$ 200,00**. Tratamentos específicos como fungos, verruga plantar e calosidades têm valores definidos na avaliação conforme a complexidade do caso. Não há cobrança surpresa — você recebe o plano completo com valores antes de iniciar qualquer procedimento.

Tem estacionamento próximo? +

Sim. Há vagas de estacionamento na própria Rua Doutor Arthur Jorge e nas ruas adjacentes. Temos uma vaga no interior do prédio disponível para pessoas com dificuldade de locomoção. A clínica fica no bairro Monte Castelo, entre as rua Alegrete e Dolor Ferreira de Andrade, de fácil acesso pela região central de Campo Grande.

Posso levar acompanhante na consulta? +

Sim. No atendimento infantil os pais ficam presentes durante toda a consulta — isso é parte do protocolo da clínica. Para adultos, acompanhantes são bem-vindos, especialmente idosos que precisam de suporte para locomoção.

📲 Fale com a gente agora

## Pronto para cuidar  
dos seus pés de verdade?

Mande uma mensagem pelo WhatsApp — Emily responde rápido e encontra o melhor horário para você. Primeira consulta com avaliação completa.

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.) [📞 (67) 3305-0219](tel:6733050219)

Seg–Sex · 8h às 12h e 13h às 17h  
Rua Doutor Arthur Jorge, 2523 · Monte Castelo · Campo Grande-MS

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD