# Blog - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/blog
- **Data:** 2026-08-31T10:35:06.492Z

---

[

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20600'%3E%3C/svg%3E)

](https://podologialianagoncalves.com.br/podologia-clinica/)

# [Podologia Clínica](https://podologialianagoncalves.com.br/podologia-clinica/)

16/04/2026 Nenhum comentário

Ela achava que o bebê tinha cólica. A dor vinha de outro lugar. Quando a causa mais improvável é a que ninguém pensa em checar — e a que mais

[Leia mais »](https://podologialianagoncalves.com.br/podologia-clinica/)