# Dataset Unificado: podologialianagoncalves_com_br

> Extraído de https://podologialianagoncalves.com.br/ em 2026-08-31T11:45:03.319Z

---

## [Página 1] Início - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/
- **Profundidade:** 1
- **Descrição:** Melhor Clínica de podologia de mato grosso do Sul, especialista em unhas encravadas, fungos, pé do diabético e podologia infantil
- **Palavras:** 1795 | **Imagens:** 17 | **Links:** 24

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #1 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #2 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #3 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #4 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #5 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #6 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #7 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #8 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #9 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Contexto: "<img decoding="async" width="720" height="980" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175282399.jpeg" cla"
> *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H1: Seus Pés Merecem Cuidado Clínico. Não Improvisação. • Seção: Conteúdo da Página • Sob: H1: Seus Pés Merecem Cuidado Clínico. Não Improvisação.
![Imagem extraída](images/img_010_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399.jpg)

> **[Imagem 11]** Contexto: "<img decoding="async" width="720" height="980" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175282399.jpeg" cla"
> *Posição:* Posição #11 na página • Seção: Conteúdo da Página • Sob H1: Seus Pés Merecem Cuidado Clínico. Não Improvisação. • Seção: Conteúdo da Página • Sob: H1: Seus Pés Merecem Cuidado Clínico. Não Improvisação.
![Imagem extraída](images/img_011_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399-220x300.jpg)

> **[Imagem 12]** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-remove"
> *Posição:* Posição #12 na página • Seção: Conteúdo da Página • Sob H2: A Profissional que Cuida dos seus Pés • Seção: Conteúdo da Página • Sob: H2: A Profissional que Cuida dos seus Pés
![Imagem extraída](images/img_012_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png)

> **[Imagem 13]** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-remove"
> *Posição:* Posição #13 na página • Seção: Conteúdo da Página • Sob H2: A Profissional que Cuida dos seus Pés • Seção: Conteúdo da Página • Sob: H2: A Profissional que Cuida dos seus Pés
![Imagem extraída](images/img_013_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png)

> **[Imagem 14]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
> *Posição:* Posição #14 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 15]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #15 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 16]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #16 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 17]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #17 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

[![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)](https://podologialianagoncalves.com.br/)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

207 Avaliações no Google  |  7 Anos Cuidando dos seus Pés

# Seus Pés Merecem  
Cuidado Clínico.  
Não Improvisação.

Clínica de Podologia Clínica em Campo Grande — MS. Foco exclusivo na **saúde dos seus pés**, com protocolos médicos, equipamentos de ponta e mais de 15 anos de experiência especializada.

Indicada por médicos e dermatologistas de Campo Grande.

2.000+ Pacientes Tratados

90% Taxa de Sucesso

15 anos de Experiência

207 ★ Avaliações Google

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.) [Ver tratamentos →](/a-podologia/)

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20720%20980'%3E%3C/svg%3E)

✓ Indicada por Médicos

e Dermatologistas de CG

Você se identifica?

## Você Está Sofrendo com Algum Desses Problemas?

Problemas nos pés não desaparecem sozinhos — e quanto mais você espera, mais difícil e caro fica o tratamento.

🦠

### Fungos nas Unhas

Unhas amareladas, espessas, quebradiças. Vergonha de usar sandálias. Já tentou pomadas e não resolveu?

[Entender o tratamento →](/fungos-micose-onicomicose/)

😣

### Unha Encravada

Dor intensa a cada passo, inflamação, até pus. Evitando calçados por causa da dor?

[Aliviar a dor hoje →](/unha-encravada/)

🩺

### Pé Diabético

Feridas que não cicatrizam, dormência, formigamento. O diabético precisa de acompanhamento especializado.

[Proteção especializada →](/pes-do-diabetico/)

🦶

### Calos e Calosidades

Dor ao caminhar, fissuras que sangram, pele grossa e endurecida na planta ou calcanhar.

[Resolver agora →](/calos-e-calosidades/)

🎯

### Verruga Plantar

Conhecido como olho de peixe. Dor ao pisar, lesão que cresce e pode se multiplicar se não tratada.

[Ver tratamento →](/olho-de-peixe-verruga-plantar/)

👶

### Podopediatria

Pés de crianças e bebês precisam de atenção especializada. Somos referência em podologia infantil.

[Cuidar dos pequenos →](/podologia-infantil-podopediatria-especialista-em-criancas/)

Não sabe exatamente qual é seu problema? Nossa podóloga identifica na primeira consulta.

[Falar com Especialista →](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

Nosso posicionamento

## Podologia Clínica.  
Não é Estética.  
É Saúde.

A maioria dos concorrentes ainda trata podologia como estética. Aqui, atuamos com a seriedade e os protocolos da medicina — porque os seus pés fazem parte do seu sistema de saúde, e não de um salão de beleza.

Somos indicados por médicos e dermatologistas de Campo Grande porque eles sabem: quando um paciente precisa de podologia clínica de verdade, é aqui que encontra.

🔬

**Exame Micológico Laboratorial**

Identificamos o fungo exato antes de tratar — não chutamos o protocolo.

⚡

**Laser DMC — A Marca Referência do Mercado**

Equipamentos Therapy iLib e XT para resultados precisos e sem dor.

📚

**Congressos Médicos Internacionais**

CIAP 2023, 2024 e 2025 — atualização constante nos melhores eventos da área.

🏥

**Pós-Graduações na Área Clínica**

Diabetes, Dermatologia, Geriatria — formação que vai além da podologia convencional.

15+

Anos de Experiência da Podóloga Liana

2.000+

Pacientes Atendidos e Cadastrados

90%

Taxa de Sucesso nos Tratamentos

207

Avaliações ⭐ Google

🏆

**50+ Cursos e Especializações**

CIAP Internacional · Jornada Internacional de Podologia · Pós-Graduações Clínicas

👩‍⚕️

**Indicada por médicos e dermatologistas de Campo Grande**

Quando um médico indica a nossa clínica, é porque sabe que o paciente vai receber um tratamento com base científica, equipamentos certificados e protocolo individualizado — não um atendimento genérico.

Tratamentos especializados

## Nossos Principais Tratamentos

Cada caso é único. Cada protocolo é personalizado. Isso é o que separa o tratamento eficaz do paliativo.

🦠

### Fungos nas Unhas

Carro-chefe

Diagnóstico com exame micológico laboratorial. Identificamos o fungo exato para o protocolo certo. Protocolo especializado e comprovado.

Consulta inclui

✓ Coleta micológica   ✓ Análise laboratorial  
✓ 1ª limpeza completa   ✓ Plano de tratamento

R$ 370,00  a consulta de fungos com tudo incluso

[Iniciar Tratamento →](/fungos-micose-onicomicose/)

😣

### Unha Encravada

Urgência

Procedimento rápido com alívio imediato da dor. Atendemos casos infeccionados, com granuloma, em bebês e em diabéticos.

O procedimento inclui

✓ Analgesia com laser   ✓ Todos os curativos necessários  
✓ Todos os retornos inclusos   ✓ Alívio imediato

Consulta R$ 150,00  Valor da consulta não é cobrado se fizer o procedimento no mesmo dia da consulta

[Aliviar a Dor Hoje →](/unha-encravada/)

🩺

### Pé do Diabético

Especialidade

Prevenção e tratamento especializado com pós-graduação em Diabetes. Evite úlceras e complicações graves com acompanhamento contínuo.

Nosso diferencial

✓ Pós-graduação em Diabetes   ✓ Ozonioterapia  
✓ Semiologia do pé diabético   ✓ Protocolos atualizados

Consulta R$ 150,00  Valor da consulta não é cobrado se iniciar o tratamento no mesmo dia, valor do tratamento definido na consulta

[Agendar Avaliação →](/pes-do-diabetico/)

[Ver todos os tratamentos →](/a-podologia/)

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20433%20577'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

Conheça a especialista

## A Profissional que  
Cuida dos seus Pés

Liana Gonçalves começou sua trajetória em 2011, quando abandonou a faculdade de Recursos Humanos ao se apaixonar pela podologia. Desde então, dedicou mais de 15 anos ao estudo e à prática da podologia clínica — com formação técnica, nível superior pela Unicesumar e mais de 50 especializações.

Participa dos principais congressos internacionais da área — incluindo o CIAP (2023, 2024 e 2025) — e foi convidada para eventos voltados exclusivamente a médicos. Não é por acaso que médicos e dermatologistas de Campo Grande indiquem a clínica para seus pacientes.

Palestrante em eventos relevantes nacionalmente como o palco da podologia na beaulty fair 2025, a maior feira de estética e saúde das américas, a segunda maior do mundo. Também atuou como tutora de turmas de curso técnico de podologia pelo Senac MS.

✓ Graduação Nível SuperiorUnicesumar · Campo Grande

✓ Pós-Grad. Diabetese Complicações Crônicas

✓ Pós-Grad. Dermatologiae Tratamento de Feridas

✓ CIAP Internacional2023 · 2024 · 2025

✓ Especialização em LaserDescomplicando Laserterapia

✓ 50+ Cursos Livrese Especializações

[Conhecer toda a trajetória →](/sobre-nos)

A voz de quem viveu

## Mais de 2.000 pacientes.  
207 avaliações. Uma consistência.

★★★★★ 4.9 · média Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

Dúvidas comuns

## Perguntas Frequentes

O procedimento vai doer? +

Usamos analgesia com laser DMC e anestésico tópico antes de qualquer procedimento. Na unha encravada, por exemplo, o procedimento dura menos de 1 minuto e o alívio da dor é imediato após a retirada da espícula. A grande maioria dos pacientes relata que foi bem menos incômodo do que imaginava.

Quanto custa uma consulta? +

A consulta padrão custa R$ 150 e inclui anamnese completa, exame da patologia e definição do protocolo personalizado. O valor da consulta é isento caso o tratamento seja iniciado no mesmo dia. Para fungos/micose, a consulta é R$ 370 e já inclui coleta para exame micológico laboratorial, primeira limpeza e plano de tratamento.

Vocês atendem plano de saúde? +

Atendemos somente particular. Aceitamos Pix, dinheiro, débito e crédito. Parcelamos em até 10x no cartão de crédito (com taxa da operadora). Nosso foco é oferecer a melhor qualidade de atendimento, equipamentos e protocolo — sem limitações impostas por convênios.

Posso saber o valor por foto antes de ir? +

Não é possível precificar o tratamento por foto — e fazemos isso pela sua segurança. O valor correto só pode ser definido após examinar pessoalmente o grau da patologia, possíveis comorbidades e outros fatores que só a podóloga identifica presencialmente. Isso garante que você receba exatamente o tratamento que precisa, nem mais nem menos.

Diabéticos podem ser atendidos? +

Sim, e é ainda mais importante que diabéticos tenham acompanhamento especializado. A Liana tem pós-graduação em Diabetes e Complicações Crônicas, além de especialização em Semiologia do Pé Diabético. O diabético com problema nos pés não pode esperar — o risco de agravamento é muito maior.

Atendem crianças e bebês? +

Sim! Somos referência em Podopediatria em Campo Grande. Atendemos bebês recém-nascidos — inclusive casos de unha encravada em recém-nascidos, que é mais comum do que se imagina. Nossa estrutura foi preparada para receber os pequenos com todo o cuidado e segurança que eles merecem.

Transparência

## Quanto Custa Cuidar  
da Saúde dos seus Pés?

Acreditamos em transparência. Abaixo os valores de referência — o valor exato do tratamento só é definido após a consulta, pois cada caso é único.

Procedimento / Consulta Investimento

🦠 Consulta de Fungos / Onicomicose

Inclui: coleta micológica · análise laboratorial · 1ª limpeza completa · plano de tratamento

R$ 370,00

😣 Consulta necessária para definir valor

O tratamento inclui: procedimento · curativos · laser · retornos e aconsulta não é cobrada se feito procedimento no mesmo dia

R$ 150,00

🧴 Podoprofilaxia (Limpeza Completa)

Higienização, corte técnico das unhas e cuidados preventivos completos

A partir de R$ 200,00

🦶 Calos, Calosidades e Calo com Núcleo

Remoção especializada com protocolo clínico

A partir de R$ 180,00

🩺 Consulta Geral (demais patologias)

Anamnese · exame clínico · definição do protocolo personalizado. Em todos os atendimentos a consulta não é cobrada caso o tratamento seja contratado no mesmo dia da consulta

R$ 150,00

💳 Parcelamos em até **10x no cartão** (taxa operadora) · Pix · Débito · Dinheiro ⚠️ Valor do tratamento definido após consulta presencial

[Tirar Dúvidas pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

⚠️

## Problemas nos Pés não Desaparecem Sozinhos

Fungos ficam mais resistentes com o tempo. Unhas encravadas podem infeccionar e evoluir para granuloma. Pés diabéticos sem acompanhamento chegam à amputação.

Quanto mais cedo você agenda, mais simples e eficaz é o tratamento.

[Agendar Agora pelo WhatsApp →](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.) [☎ (67) 3305-0219](tel:6733050219)

✓ Aprovado pelo CFM · 2025

## Ozonioterapia  
na mesma clínica

Contamos com a enfermeira Marciana Soares — especialista em ozonioterapia com 15 anos de experiência e equipamento Philozon certificado. 8 técnicas disponíveis para dor crônica, imunidade, fibromialgia, lipedema e muito mais.

[Conhecer a Ozonioterapia →](/ozonioterapia/)

🦵

Dor Crônica

🛡️

Imunidade

🌊

Lipedema

🧘

Fibromialgia

🦶

Fascite Plantar

\+ 7 outras indicações

[Ver todas →](/ozonioterapia/)

Estamos prontos para te atender

## Agende sua Consulta

[

WhatsApp

(67) 99916-0929 · Resposta rápida

→

](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Gostaria%20de%20agendar%20uma%20consulta.)[

☎

Telefone Fixo

(67) 3305-0219

→

](tel:6733050219)[

📍

Endereço

Rua Doutor Arthur Jorge, 2523 · Campo Grande - MS

→

](https://maps.google.com/?q=Rua+Doutor+Arthur+Jorge+2523+Campo+Grande+MS)

🕐

Horário de Funcionamento

Segunda a Sexta · 8h às 12h e 13h às 17h

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD

---

## [Página 2] Sobre nós - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/sobre-nos
- **Profundidade:** 2
- **Descrição:** Ligue agora! Agendar Consulta Nossa história · Campo Grande-MS Nascemos do amor à podologia. Crescemos pela confiança de quem cuidamos. Desde 2019, a Clínica de Podologia Liana Gonçalves atende Campo Grande com um propósito claro: elevar o nível da podologia clínica no Mato Grosso do Sul — com rigor técnico, atualização constante e cuidado verdadeiramente […]
- **Palavras:** 1661 | **Imagens:** 23 | **Links:** 22

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #1 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #2 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #3 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #4 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #5 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #6 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #7 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #8 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #9 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-remove"
> *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Uma paixão que começouem 2011 e nunca parou • Seção: Conteúdo da Página • Sob: H2: Uma paixão que começouem 2011 e nunca parou
![Imagem extraída](images/img_012_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png)

> **[Imagem 11]** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-remove"
> *Posição:* Posição #11 na página • Seção: Conteúdo da Página • Sob H2: Uma paixão que começouem 2011 e nunca parou • Seção: Conteúdo da Página • Sob: H2: Uma paixão que começouem 2011 e nunca parou
![Imagem extraída](images/img_013_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png)

> **[Imagem 12]** Contexto: "<img decoding="async" width="720" height="980" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175282399.jpeg" cla"
> *Posição:* Posição #12 na página • Seção: Conteúdo da Página • Sob H2: Liana Gonçalves • Seção: Conteúdo da Página • Sob: H2: Liana Gonçalves
![Imagem extraída](images/img_010_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399.jpg)

> **[Imagem 13]** Contexto: "<img decoding="async" width="720" height="980" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175282399.jpeg" cla"
> *Posição:* Posição #13 na página • Seção: Conteúdo da Página • Sob H2: Liana Gonçalves • Seção: Conteúdo da Página • Sob: H2: Liana Gonçalves
![Imagem extraída](images/img_011_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399-220x300.jpg)

> **[Imagem 14]** Contexto: "<img loading="lazy" decoding="async" width="400" height="548" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-09-at-10.41.27-1-e177367"
> *Posição:* Posição #14 na página • Seção: Conteúdo da Página • Sob H3: Marciana Soares • Seção: Conteúdo da Página • Sob: H3: Marciana Soares
![Imagem extraída](images/img_018_WhatsApp-Image-2026-03-09-at-10_41_27-1-e1773675928249.jpg)

> **[Imagem 15]** Contexto: "<img loading="lazy" decoding="async" width="400" height="548" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.13-e17736753"
> *Posição:* Posição #15 na página • Seção: Conteúdo da Página • Sob H3: Jocineia • Seção: Conteúdo da Página • Sob: H3: Jocineia
![Imagem extraída](images/img_019_WhatsApp-Image-2026-03-16-at-10_59_13-e1773675323462.jpg)

> **[Imagem 16]** Contexto: "<img loading="lazy" decoding="async" width="400" height="548" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.13-e17736753"
> *Posição:* Posição #16 na página • Seção: Conteúdo da Página • Sob H3: Jocineia • Seção: Conteúdo da Página • Sob: H3: Jocineia
![Imagem extraída](images/img_020_WhatsApp-Image-2026-03-16-at-10_59_13-e1773675323462-219x300.jpg)

> **[Imagem 17]** Contexto: "<img loading="lazy" decoding="async" width="768" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.11-2-768x10"
> *Posição:* Posição #17 na página • Seção: Conteúdo da Página • Sob H2: Emily Regis • Seção: Conteúdo da Página • Sob: H2: Emily Regis
![Imagem extraída](images/img_021_WhatsApp-Image-2026-03-16-at-10_59_11-2-768x1024.jpg)

> **[Imagem 18]** Contexto: "<img loading="lazy" decoding="async" width="768" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.11-2-768x10"
> *Posição:* Posição #18 na página • Seção: Conteúdo da Página • Sob H2: Emily Regis • Seção: Conteúdo da Página • Sob: H2: Emily Regis
![Imagem extraída](images/img_022_WhatsApp-Image-2026-03-16-at-10_59_11-2-225x300.jpg)

> **[Imagem 19]** Contexto: "<img loading="lazy" decoding="async" width="768" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.11-2-768x10"
> *Posição:* Posição #19 na página • Seção: Conteúdo da Página • Sob H2: Emily Regis • Seção: Conteúdo da Página • Sob: H2: Emily Regis
![Imagem extraída](images/img_023_WhatsApp-Image-2026-03-16-at-10_59_11-2.jpg)

> **[Imagem 20]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
> *Posição:* Posição #20 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 21]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #21 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 22]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #22 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 23]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #23 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

[![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)](https://podologialianagoncalves.com.br/)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

Nossa história · Campo Grande-MS

# Nascemos do amor à podologia.  
Crescemos pela _confiança_  
de quem cuidamos.

Desde 2019, a Clínica de Podologia Liana Gonçalves atende Campo Grande com um propósito claro: elevar o nível da podologia clínica no Mato Grosso do Sul — com rigor técnico, atualização constante e cuidado verdadeiramente personalizado.

2011 início da trajetória  
de Liana

2.000+ pacientes  
atendidos

4.9 ★ 207 avaliações  
no Google

50+ cursos e  
especializações

90% taxa de  
sucesso

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20433%20577'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

A origem

## Uma paixão que começou  
em 2011 e nunca parou

2011

### Amor à primeira vista com a podologia

Cursando Recursos Humanos, Alveliana Gonçalves teve seu primeiro contato com a podologia como auxiliar. Foi imediato: **ela abandonou o curso de RH e se dedicou completamente à podologia**. Não foi uma escolha de carreira — foi uma vocação.

2018

### O sonho começa a tomar forma

Depois de 7 anos acumulando experiência, especializações e o olhar clínico que só o tempo constrói, Liana decidiu que Campo Grande merecia **uma podologia em outro nível**. Nasceu o projeto da clínica.

2019

### A Clínica abre as portas

Com equipamentos de última geração — incluindo o laser DMC Therapy iLib e XT, referência do mercado — a Clínica de Podologia Liana Gonçalves começa a atender com um padrão que até então não existia em Campo Grande-MS.

Hoje

### Referência em Mato Grosso do Sul

Mais de 2.000 pacientes atendidos, 207 avaliações 4.9★ no Google, indicada por médicos e dermatologistas da cidade — e formando outros profissionais de podologia no estado. **O sonho virou legado.**

"Focada exclusivamente na saúde dos pés, pois ter pés sem dores é muito importante para o seu bem-estar — e eu cuido de tudo pessoalmente para garantir o nível máximo de qualidade."

— Liana Gonçalves, podóloga responsável

As pessoas por trás do cuidado

## Nossa Equipe

😊

Clínica de podologia Liana Gonçalves

Nossa equipe

Todos os profissionais que atuam em nossa clínica são treinados para estarem sempre prontos para te atender da melhor forma possível sempre que precisar, conheça um pouco mais de cada uma das pessoas que amam cuidar da saúde dos seus pés e melhorar a sua qualidade de vida.

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20720%20980'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

Podóloga Responsável · Fundadora

Podóloga · 15 anos de experiência

## Liana Gonçalves

Graduada em Podologia · Unicesumar · Nível Superior

Liana começou na podologia em 2011 por vocação pura — largou o curso de Recursos Humanos no meio para se dedicar completamente à área. Depois de 7 anos acumulando experiência e especializações, fundou em 2019 a clínica com um propósito claro: **elevar o padrão da podologia clínica em Campo Grande**.

Hoje, além de atender mais de 2.000 pacientes com 90% de taxa de sucesso, **forma outros profissionais de podologia no Mato Grosso do Sul** e participa anualmente do CIAP — o maior congresso internacional de podologia do mundo.

✓ Pós-grad. Diabetese Complicações Crônicas

✓ Pós-grad. Dermatologiae Tratamento de Feridas

✓ Pós-grad. Geriatriae Gerontologia

✓ Laser DMC TherapyiLib e XT

✓ SemiologiaPé Diabético

✓ CIAP Internacional2023 · 2024 · 2025

🩺

**Indicada por médicos e dermatologistas de Campo Grande** — e referência no MS para formação de novos profissionais de podologia.

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20400%20548'%3E%3C/svg%3E)

Marciana da Silva Soares

Enfermeira certificada Ozonioterapeuta · 15 anos

★★★★★

Enfermeira · Ozonioterapeuta

### Marciana Soares

COREN 296.442 · 15 anos de experiência

Marciana traz a visão da enfermagem clínica para potencializar os resultados dos tratamentos podológicos. Responsável pelo serviço de **ozonioterapia da clínica**, é especialista Master O3 e uma das profissionais de referência no tema em Campo Grande-MS.

Graduação em Enfermagem

Especialização Master O3 em Ozonioterapia

15 anos de experiência clínica

Responsável técnica pela ozonioterapia

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20400%20548'%3E%3C/svg%3E)

Jocineia Lima

Podóloga Clínica · Seus pés em boas mãos

★★★★★

Podóloga Clínica

### Jocineia

Podóloga · equipe clínica

Jocineia integra a equipe clínica da Liana Gonçalves atuando com os mesmos protocolos e padrão de excelência que definem cada atendimento da clínica. **Cada paciente recebe o mesmo nível de cuidado, independentemente de qual profissional esteja atendendo** — isso é uma escolha deliberada de cultura, não coincidência.

Podologia clínica

Atendimento com protocolos padronizados da clínica

Tratamentos: onicomicose, unha encravada, calos, podoprofilaxia

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20768%201024'%3E%3C/svg%3E)

O primeiro contato com a clínica

Recepção e Agendamento

## Emily Regis

Recepcionista · atendimento presencial e WhatsApp

Antes de qualquer procedimento, existe um primeiro contato — e ele importa. Emily é a pessoa que recebe cada paciente na porta, responde pelo WhatsApp, organiza a agenda e garante que a experiência na clínica comece da forma certa: **com atenção, clareza e acolhimento genuíno**.

📲

**Agendamentos pelo WhatsApp e telefone** — tira dúvidas sobre valores, horários e como funciona cada tratamento antes da consulta

😊

**Recepção presencial** — recebe cada paciente com o nome e o cuidado que cada pessoa merece desde o momento em que entra

🗂️

**Organização da agenda** — garante que os atendimentos fluam sem atrasos e que cada paciente tenha o tempo necessário para seu caso

"Cuidado começa **antes** do consultório. A experiência que queremos entregar começa já no primeiro 'olá' — seja pelo WhatsApp ou na porta da clínica."

O que nos move

## Os valores que guiam  
cada atendimento

🔬

### Rigor Clínico

Podologia é saúde, não estética. Cada protocolo é baseado em evidência científica e atualizado constantemente — por isso participamos dos principais congressos internacionais da área todo ano.

🎯

### Personalização Real

Não existe protocolo genérico aqui. Cada paciente tem um histórico, um perfil de risco, um ritmo. O plano de tratamento é construído especificamente para você — não para "a condição".

🤝

### Transparência Total

Explicamos o diagnóstico, as opções de tratamento e os custos com clareza. Você toma decisões informado — não porque "a especialista disse". Respeito à autonomia do paciente é inegociável.

📚

### Atualização Permanente

Mais de 50 especializações e cursos acumulados. CIAP Internacional 2023, 2024 e 2025. A podologia avança — e nossa equipe avança junto. O que você recebe hoje é o que há de mais atual na área.

⚡

### Tecnologia de Ponta

Laser DMC Therapy iLib e XT — referência do mercado nacional em laserterapia podológica. Equipamentos de última geração não são diferencial de luxo: são parte do resultado que entregamos.

🏆

### Resultado, Não Aparência

Nosso trabalho é medido em dor zero, mobilidade recuperada, infecções resolvidas, amputações prevenidas. Métricas de saúde — não de estética. Isso é podologia clínica de verdade.

Credenciais e reconhecimento

### Formação que vai além do básico

Cada pós-graduação e especialização foi escolhida para atender melhor os perfis mais complexos — diabéticos, idosos, pacientes com feridas crônicas.

-   Pós-grad. em Diabetes e Complicações Crônicas
-   Pós-grad. em Enfermagem em Dermatologia e Tratamento de Feridas
-   Pós-grad. em Geriatria e Gerontologia
-   Pós-grad. em Nutrição com Ênfase em Obesidade
-   Especialização Master O3 em Ozonioterapia
-   Especialização em Semiologia do Pé Diabético
-   Especialização em Laser — Descomplicando Laserterapia
-   CIAP Internacional 2023 · 2024 · 2025
-   1º Congresso de Podologia MS · XIX Jornada Internacional
-   Forma outros profissionais de podologia no MS

2.000+ Pacientes atendidos

4.9 ★ 207 avaliações no Google

90% Taxa de sucesso nos tratamentos

50+ Cursos e especializações

15 anos de trajetória na podologia

3x CIAP Internacional consecutivo

A voz de quem viveu

## Mais de 2.000 pacientes.  
207 avaliações. Uma consistência.

★★★★★ 4.9 · média Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

🔒 LGPD · Lei nº 13.709/2018

## Nosso compromisso com  
a privacidade dos seus dados

Em nossa clínica, tratamos dados pessoais e de saúde com o mesmo rigor que aplicamos aos nossos procedimentos clínicos. Seus dados são coletados apenas para o que é necessário ao seu atendimento — e protegidos em conformidade com a Lei Geral de Proteção de Dados.

🔒 LGPD Lei nº 13.709/2018  
Em conformidade

🩺

### Dados de saúde protegidos

Informações clínicas são dados sensíveis pela LGPD. Coletamos apenas o necessário para o seu tratamento, com acesso restrito à equipe clínica.

🎯

### Finalidade específica

Seus dados são usados exclusivamente para agendamento, atendimento clínico e comunicação relacionada à sua saúde. Não vendemos nem compartilhamos para fins comerciais.

✅

### Consentimento explícito

Dados sensíveis de saúde são coletados apenas com seu consentimento. Você pode revogar a qualquer momento sem prejuízo do atendimento já realizado.

🛡️

### Armazenamento seguro

Site com SSL, prontuário com acesso restrito e parceiros de tecnologia com obrigações contratuais de proteção. Seus dados não ficam expostos.

👤

### Seus direitos garantidos

Acesso, correção, portabilidade e exclusão dos seus dados. Respondemos solicitações em até 15 dias úteis pelo WhatsApp ou e-mail da clínica.

👶

### Proteção reforçada para menores

Dados de crianças e adolescentes são coletados apenas com consentimento dos responsáveis legais, presentes durante todo o atendimento.

### Política de Privacidade completa

Acesse nossa política unificada — LGPD, cookies, dados de saúde e todos os seus direitos explicados de forma clara e transparente.

[🔒 Ler política completa →](/politica-de-privacidade/)

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD

---

## [Página 3] Patologias - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/a-podologia
- **Profundidade:** 2
- **Descrição:** Ligue agora! Agendar Consulta 🩺 Podologia Clínica — Saúde para seus pés Recupere o prazer de caminhar sem dor Tratamento especializado para Unha Encravada, Fungos, Verrugas e Pé Diabético. Alívio imediato e cuidado clínico com 15 anos de experiência em Campo Grande. Agendar Avaliação pelo WhatsApp Conhecer Tratamentos 15 Anos De Experiência 2.000+ Pacientes Atendidos […]
- **Palavras:** 923 | **Imagens:** 15 | **Links:** 28

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #1 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #2 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #3 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #4 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #5 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #6 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #7 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #8 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #9 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Contexto: "<img decoding="async" width="640" height="664" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/12/Imagem-do-WhatsApp-de-2023-12-13-as-17.55.34_77b6483f-1.webp" "
> *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Por que escolher a nossa Podologia Clínica? • Seção: Conteúdo da Página • Sob: H2: Por que escolher a nossa Podologia Clínica?
![Imagem extraída](images/img_024_Imagem-do-WhatsApp-de-2023-12-13-as-17_55_34_77b6483f-1.webp)

> **[Imagem 11]** Contexto: "<img decoding="async" width="640" height="664" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/12/Imagem-do-WhatsApp-de-2023-12-13-as-17.55.34_77b6483f-1.webp" "
> *Posição:* Posição #11 na página • Seção: Conteúdo da Página • Sob H2: Por que escolher a nossa Podologia Clínica? • Seção: Conteúdo da Página • Sob: H2: Por que escolher a nossa Podologia Clínica?
![Imagem extraída](images/img_025_Imagem-do-WhatsApp-de-2023-12-13-as-17_55_34_77b6483f-1-289x.webp)

> **[Imagem 12]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
> *Posição:* Posição #12 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 13]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #13 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 14]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #14 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 15]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #15 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

[![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)](https://podologialianagoncalves.com.br/)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

🩺 Podologia Clínica — Saúde para seus pés

# Recupere o prazer de caminhar sem dor

Tratamento especializado para Unha Encravada, Fungos, Verrugas e Pé Diabético. Alívio imediato e cuidado clínico com **15 anos de experiência em Campo Grande.**

[Agendar Avaliação pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.) [Conhecer Tratamentos](#tratamentos)

**15 Anos** De Experiência

**2.000+** Pacientes Atendidos

**4.9 ★** Avaliações no Google

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20640%20664'%3E%3C/svg%3E)

Não é Estética, é Saúde

## Por que escolher a nossa Podologia Clínica?

✓

#### Biossegurança Rigorosa

Materiais 100% esterilizados em autoclave e descartáveis de uso único para sua total segurança.

✓

#### Diagnóstico Especializado

Identificamos a causa raiz do seu problema, não apenas tratamos o sintoma superficial.

✓

#### Tecnologia de Ponta

Uso de Laser Terapêutico e equipamentos de última geração para acelerar sua recuperação.

[Quero falar com uma especialista](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

## Nossas especialidades

Identifique seu sintoma e agende uma avaliação para iniciar seu protocolo de cura.

[_🩹_

### Unha Encravada

Alívio imediato da dor e tratamento da infecção com técnicas indolores.

](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20unha%20encravada.)[_🦠_

### Fungos nas Unhas

Protocolos com Laser DMC para eliminação definitiva de micoses resistentes.

](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20fungo%20nas%20unhas.)[_🎯_

### Verruga Plantar

Remoção segura e eficaz do "olho de peixe" com cicatrização acelerada.

](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20verruga%20plantar.)[_🦶_

### Calos e Calosidades

Remoção completa e identificação da causa para evitar que retornem.

](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20calos%20e%20calosidades.)[_🩺_

### Pé Diabético

Acompanhamento preventivo vital para evitar úlceras e complicações graves.

](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.)[_✨_

### Podoprofilaxia

A "limpeza profunda" dos pés para manutenção da saúde e prevenção de doenças.

](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20sess%C3%A3o%20de%20podoprofilaxia.)

### 🎁 Consulta com Bônus Especial

A consulta com anamnese, avaliação completa do paciente e apresentação do plano de tratamento tem o valor de R$ 150,00, mas **se você iniciar o tratamento no dia da consulta, esse valor é totalmente abatido.**

[Agendar Minha Avaliação Agora](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

A voz de quem viveu

## Mais de 2.000 pacientes.  
207 avaliações. Uma consistência.

★★★★★ 4.9 · média Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

🩺 Podologia Clínica — Não é Estética, é Saúde

# Todos os tratamentos  
em um só lugar

Da unha encravada ao pé diabético — cada condição tem um protocolo especializado, equipamentos de última geração e 15 anos de experiência clínica.

8 tratamentos  
especializados

2.000+ pacientes  
atendidos

15 anos de experiência  
clínica

4.9 ★ 207 avaliações  
no Google

Tratamentos clínicos

## Escolha o tratamento  
que você precisa

Antes de qualquer tratamento, é indispensável passar pela consulta podológica. É ela que garante um diagnóstico preciso e um protocolo personalizado para o seu caso. A consulta tem valor de R$ 150,00 e, caso você inicie o tratamento no mesmo dia, esse valor é totalmente abatido.

[

Alta demanda 🦠 Onicomicose

### Fungos nas Unhas

Diagnóstico laboratorial, limpeza especializada e laser DMC. Protocolo completo do exame ao acompanhamento.

Consulta **R$ 150,00**

Ver tratamento →

](/fungos-micose-onicomicose/)[

Alta demanda 🩹 Onicocriptose

### Unha Encravada

Alívio imediato na consulta. Atendemos bebês, adultos e casos com infecção. Retornos inclusos no valor.

Consulta **R$ 150,00**

Ver tratamento →

](/unha-encravada/)[

🩺 Diabetes

### Pé do Diabético

Acompanhamento mensal obrigatório para todo diabético. Prevenção de úlceras, amputações e complicações graves.

Consulta **R$ 150,00**

Ver tratamento →

](/pes-do-diabetico/)[

🎯 HPV plantar

### Verruga Plantar (Olho de peixe)

Remoção com protocolo clínico especializado e comprovado, cicatrização rápida e sem recidiva na maioria dos casos.

Consulta **R$ 150,00**

Ver tratamento →

](/olho-de-peixe-verruga-plantar/)[

🦶 Heloma

### Calos e Calosidades

Remoção completa com identificação da causa. Alívio imediato da dor — na maioria dos casos tratado na mesma sessão.

Consulta **R$ 150,00**

Ver tratamento →

](/calos-e-calosidades/)[

👶 Crianças e bebês

### Podopediatria

Desde recém-nascidos. Sem agulha, procedimento rápido e pais presentes durante todo o atendimento.

Consulta **R$ 150,00**

Ver tratamento →

](/podologia-infantil-podopediatria-especialista-em-criancas/)

Prevenção e terapias complementares

## Cuidado preventivo e terapias inovadoras

[✨

### Podoprofilaxia

Manutenção clínica completa dos pés — corte correto das unhas, remoção de calosidades, hidratação e avaliação preventiva. O tratamento mais procurado da clínica. A partir de R$ 200,00.

Saiba mais →](/podoprofilaxia/) [⚡

### Ozonioterapia

Tratamento inovador com ozônio medicinal — Enfermeira especializada com 15 anos de experiência — ação antifúngica, anti-inflamatória e analgésica com multiplos benefícios. Potencializa os resultados de tratamentos.

Saiba mais →](/ozonioterapia/)

📲 Primeira consulta

## Não sabe por onde começar?  
Tire suas dúvidas agora mesmo.

Na primeira consulta identificamos o problema, definimos o tratamento correto e você já sai com um plano claro — valores e prazos incluídos.

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.) [📞 (67) 3305-0219](tel:6733050219)

Seg–Sex · 8h às 12h e 13h às 17h  
Rua Doutor Arthur Jorge, 2523 · Campo Grande-MS

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD

---

## [Página 4] Unha encravada - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/unha-encravada
- **Profundidade:** 2
- **Descrição:** Você sofre com unha encravada ou infeccionada? pare de sentir dor hoje mesmo! volte a ter qualidade de vida e liberdade para usar calçados.
- **Palavras:** 2488 | **Imagens:** 20 | **Links:** 27

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #1 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #2 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #3 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #4 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #5 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #6 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #7 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #8 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #9 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Contexto: "<img decoding="async" width="800" height="1000" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-i"
> *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H2: O perigo de tentar resolver "em casa" • Seção: Conteúdo da Página • Sob: H2: O perigo de tentar resolver "em casa"
![Imagem extraída](images/img_026_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

> **[Imagem 11]** Contexto: "<img decoding="async" width="800" height="1000" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-i"
> *Posição:* Posição #11 na página • Seção: Conteúdo da Página • Sob H2: O perigo de tentar resolver "em casa" • Seção: Conteúdo da Página • Sob: H2: O perigo de tentar resolver "em casa"
![Imagem extraída](images/img_027_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

> **[Imagem 12]** Contexto: "<img decoding="async" width="800" height="1000" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-i"
> *Posição:* Posição #12 na página • Seção: Conteúdo da Página • Sob H2: O perigo de tentar resolver "em casa" • Seção: Conteúdo da Página • Sob: H2: O perigo de tentar resolver "em casa"
![Imagem extraída](images/img_028_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

> **[Imagem 13]** Contexto: "<img decoding="async" width="800" height="1000" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-i"
> *Posição:* Posição #13 na página • Seção: Conteúdo da Página • Sob H2: O perigo de tentar resolver "em casa" • Seção: Conteúdo da Página • Sob: H2: O perigo de tentar resolver "em casa"
![Imagem extraída](images/img_029_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

> **[Imagem 14]** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-remove"
> *Posição:* Posição #14 na página • Seção: Conteúdo da Página • Sob H2: A escolha de quem busca segurança absoluta • Seção: Conteúdo da Página • Sob: H2: A escolha de quem busca segurança absoluta
![Imagem extraída](images/img_012_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png)

> **[Imagem 15]** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-remove"
> *Posição:* Posição #15 na página • Seção: Conteúdo da Página • Sob H2: A escolha de quem busca segurança absoluta • Seção: Conteúdo da Página • Sob: H2: A escolha de quem busca segurança absoluta
![Imagem extraída](images/img_013_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png)

> **[Imagem 16]** Contexto: "<img loading="lazy" decoding="async" width="694" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175"
> *Posição:* Posição #16 na página • Seção: Conteúdo da Página • Sob H2: Especialista com 15 Anos Tratando Onicocriptose • Seção: Conteúdo da Página • Sob: H2: Especialista com 15 Anos Tratando Onicocriptose
![Imagem extraída](images/img_030_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175206114-694x102.jpg)

> **[Imagem 17]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
> *Posição:* Posição #17 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 18]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #18 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 19]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #19 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 20]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #20 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

[![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)](https://podologialianagoncalves.com.br/)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20unha%20encravada.)

🚨 Alívio Imediato: Procedimento em menos de 1 minuto

# Sofrendo com Unha Encravada?  
Recupere o Alívio Hoje

Pare de sofrer e de tentar "resolver" em casa. Use a técnica definitiva da Clínica Liana Gonçalves para eliminar a dor e a infecção **sem cirurgias desnecessárias.**

[Quero Alívio Imediato Agora](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20unha%20encravada.)

★★★★★

**4.9/5 estrelas** baseadas em **207 avaliações reais** no Google

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%201000'%3E%3C/svg%3E)

Resultados Reais

## O perigo de tentar resolver "em casa"

Ao lado, você vê o resultado de um tratamento profissional. Quando você tenta cortar a unha em casa com alicates comuns, você corre o risco de deixar uma **espícula (pedaço de unha)** ainda mais profunda, o que causa inflamações graves e infecções.

#### ⚠️ Não arrisque sua saúde

Tentar desencravar em casa é a principal causa de **Granuloma (carne esponjosa)** e infecções que podem exigir meses de tratamento se não forem cuidadas na hora certa.

### 🎁 Oferta de Alívio Imediato

Se você iniciar seu procedimento no dia da avaliação, **o valor da consulta é 100% bonificado.** Você paga apenas pelo tratamento e já sai sem dor!

[Quero resolver meu problema agora](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20unha%20encravada.)

Referência em Podologia

## A escolha de quem busca segurança absoluta

Com **15 anos de experiência clínica** e 7 anos à frente da sua própria clínica em Campo Grande, **Liana Gonçalves** é a profissional indicada por médicos e dermatologistas para casos complexos de unha encravada.

G

4.9 ★★★★★

207 Avaliações Reais no Google

"Excelente profissional, atendeu minha filha com muita paciência... me orientou como cortar as unhas corretamente. Recomendo sem dúvidas."

[Agendar com a Especialista](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20unha%20encravada.)

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20433%20577'%3E%3C/svg%3E)

## Perguntas Frequentes

### ⚡ O procedimento de desencravar dói?

O medo da dor é o que faz as pessoas adiarem o tratamento. Na nossa clínica, utilizamos anestésicos tópicos e Laser DMC para garantir que o procedimento seja o mais confortável possível. A maioria dos pacientes relata que a dor de ficar com a unha encravada é infinitamente maior que o procedimento em si que na pratica dura menos de 1 minuto para ser realizado e gera alívio imediato da dor.

### 🔬 Vou precisar de cirurgia?

Em 99,9% dos casos, resolvemos o problema de forma clínica, sem necessidade de cirurgias invasivas ou repouso prolongado. Nossa técnica preserva a saúde da sua unha e permite que você volte às suas atividades quase que imediatamente.

### 📅 Quanto tempo leva para curar?

O alívio da dor é imediato, logo após o procedimento. O tempo total de cicatrização depende do grau de inflamação, mas com o uso do Laser Terapêutico, conseguimos acelerar esse processo em até 3x comparado aos métodos tradicionais.

Agenda com Alta Procura

## Chega de adiar o seu alívio!

Aproveite nossa condição de **Consulta Bonificada** e resolva seu problema com quem é referência em Campo Grande.

[Quero Alívio Imediato Agora](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20unha%20encravada.)

💉 Tratamento Clínico Especializado

# Unha Encravada?  
Solução Definitiva  
— Sem Cirurgia Desnecessária

Dor, inchaço, infecção e até granuloma — a onicocriptose tem tratamento clínico eficaz. Na maioria dos casos, não é preciso cirurgia. Tratamos com técnica especializada, laser e acompanhamento completo até a resolução.

⚠️

**Não tente resolver sozinho cortando a unha em casa.** O corte incorreto é a principal causa de reencravamento e pode transformar um caso simples em uma infecção grave.

[📲 Agendar Consulta pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20unha%20encravada.) [Como funciona o tratamento ↓](#ue-tratamento)

15 anosde Especialização

2.000+Pacientes Tratados

99%Taxa de Sucesso

4.9 ★207 Avaliações Google

Você se identifica?

## Sintomas e Causas da  
Unha Encravada

A onicocriptose acontece quando a borda lateral da unha cresce para dentro da pele, causando dor, inflamação e — se ignorada — infecção com pus. Reconhecer os sinais cedo facilita muito o tratamento.

### 🚨 Sinais e Sintomas

-   Dor na lateral do dedo ao calçar sapato ou caminhar
-   Vermelhidão e inchaço ao redor da borda da unha
-   Pele crescendo sobre a lateral da unha
-   Sensação de pressão ou "espinho" no dedo
-   Pus ou secreção — sinal de infecção instalada
-   Dor intensa ao toque, mesmo leve

### 🔍 Principais Causas

-   Corte incorreto da unha — em curva, muito rente às bordas
-   Calçados apertados ou bico fino que comprimem os dedos
-   Predisposição genética para unhas mais curvas
-   Trauma ou impacto repetido na ponta do pé
-   Meias e calçados de compressão (comum em atletas)
-   Tentativas de "resolver em casa" que pioram o quadro

### Graus de Gravidade — Quanto antes tratar, mais simples é

Grau 1 · Leve

#### Inflamação sem infecção

Dor e vermelhidão na lateral. Tratamento clínico resolve na primeira consulta na maioria dos casos.

Grau 2 · Moderado

#### Infecção com secreção

Presença de pus e tecido granulado. Requer procedimento clínico com drenagem e curativos de acompanhamento.

Grau 3 · Avançado

#### Tecido exuberante e dor intensa

Grande quantidade de tecido granulado, dor constante. Pode exigir procedimento mais invasivo e mais retornos para acompanhamento.

Não sabe em qual grau está? **Agende uma avaliação — identificamos o grau e o melhor protocolo na mesma consulta.**

[📲 Agendar consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20avalia%C3%A7%C3%A3o%20para%20unha%20encravada.)

⚠️ O erro mais comum

## Por que Tentar Resolver em Casa  
Quase Sempre Piora a Situação

A maioria das pessoas que chega à clínica com casos graves de unha encravada tentou resolver sozinha antes — cortando em ângulo, usando palito ou alicate sem técnica. O resultado quase sempre é o mesmo: mais dor, infecção e uma unha ainda mais encravada do que antes.

❌

### Tentativa em casa

-   Corte em curva remove só a parte visível — a espícula continua encravada
-   Uso de palito ou objeto improvisado introduz bactérias no local
-   Sem analgesia — dor desnecessária e risco de trauma na pele
-   Sem técnica correta, o reencravamento acontece em dias ou semanas
-   Em caso de infecção, manipular em casa piora e aprofunda o quadro
-   Em diabéticos, qualquer lesão sem cuidado pode virar complicação séria

✅

### Tratamento em nossa Clínica

-   Remoção completa da espícula com técnica que preserva a placa ungueal
-   Analgesia com laser e anestésico tópico — procedimento rápido e profissional
-   Drenagem correta em casos com infecção — sem risco de aprofundamento
-   Ensino do corte correto para evitar reencravamento futuro
-   Retornos e curativos inclusos até a resolução completa
-   Protocolo específico para diabéticos e casos de alto risco

⚡

### 95% dos procedimentos duram menos de 1 minuto

Com a técnica correta e analgesia adequada, o procedimento de desencravamento é muito rápido e eficaz. A maioria dos pacientes se surpreende — o medo da dor que adiou o tratamento por semanas não se confirma na prática. E o alívio imediato após o procedimento é quase sempre relatado logo na saída.

Passo a passo

## Como Funciona o  
Tratamento de Unha Encravada

1

1ª Consulta · R$ 150,00

### Avaliação clínica e diagnóstico do grau

A podóloga avalia o grau de encravamento, a presença de infecção e o histórico do paciente, faz uma anamnese completa. A consulta inclui orientações sobre corte correto e prevenção de reencravamento. **Se o procedimento for iniciado no mesmo dia, a consulta é isenta.**

2

Procedimento

### Desencravamento com técnica especializada

Remoção completa da espícula com técnica que preserva ao máximo a placa ungueal. Em casos com infecção, é feita a drenagem e limpeza do local. A analgesia é feita com laser e anestésico tópico — o procedimento dura em média menos de 1 minuto e o alívio da dor é imediato.

3

Pós-procedimento

### Curativo + laser de cicatrização

Após o procedimento, é aplicado curativo adequado e, quando indicado, laser DMC para acelerar a cicatrização e reduzir a inflamação. Você recebe orientações detalhadas para os cuidados em casa.

4

Retornos inclusos

### Acompanhamento até a resolução completa

Os retornos para troca de curativo e acompanhamento da cicatrização estão inclusos no valor do procedimento. Você não paga a mais para que seu caso seja resolvido de verdade.

Consulta inicial

R$ 150,00

Isenta se o tratamento iniciar no mesmo dia

-   Avaliação clínica completa
-   Diagnóstico do grau de encravamento
-   Orientações e plano de tratamento

procedimento RÁPIDO E SEGURO

PROTOCOLO COMPROVADO

Valor conforme grau de infecção e complexidade do caso

-   Procedimento clínico especializado
-   Analgesia com laser + anestésico tópico
-   Curativo + laser de cicatrização
-   Retornos inclusos até a resolução

💡

Na prática, quem inicia o tratamento na mesma consulta paga **somente o procedimento** — a consulta é isenta. A maioria dos pacientes resolve o caso em uma única visita.

**Formas de pagamento:** Aceitamos Pix, dinheiro, débito e crédito. Parcelamos em até 10x no cartão de crédito (com taxa da operadora). Atendemos somente particular. Nosso foco é oferecer a melhor qualidade de atendimento, equipamentos e protocolo — sem limitações impostas por convênios.

[📲 Agendar minha consulta agora](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20unha%20encravada.)

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20694%201024'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

Quem vai te atender

## Especialista com  
15 Anos Tratando Onicocriptose

Todos os procedimentos e protocolos realizados na clínica são criados e/ou validados pela podologista Liana Gonçalves que é graduada em Podologia pela Unicesumar, com pós-graduações em Diabetes, Dermatologia e Tratamento de Feridas. Atende pacientes de todas as idades — da primeira infância (inclusive recém nascidos) à terceira idade — com protocolos específicos para cada perfil.

Participa anualmente do CIAP — o principal congresso internacional de podologia — e acumula mais de 50 especializações e cursos na área. Com mais de 2.000 pacientes tratados e 90% de taxa de sucesso, você está em mãos experientes.

✓ Graduação em PodologiaUnicesumar · Nível Superior

✓ Pós-Grad. Diabetese Complicações Crônicas

✓ Laser DMC TherapyiLib e XT — referência do mercado

✓ CIAP Internacional2023 · 2024 · 2025

✓ Atende crianças e bebêsPodopediatria especializada

✓ 50+ cursos e especializaçõesem podologia clínica

🩺

**Indicada por médicos e dermatologistas de Campo Grande** para seus pacientes — inclusive diabéticos e gestantes que precisam de protocolo especializado.

Quem já foi atendido

## O Que Nossos Pacientes  
Dizem Sobre o Tratamento

★★★★★ 4.9 · 207 avaliações no Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

Também tratamos

## Outros Tratamentos na Clínica

Muitos pacientes chegam com uma queixa e descobrem que outro problema precisa de atenção também. Aqui você resolve tudo em um só lugar.

[🔬

### Fungos nas Unhas

Diagnóstico laboratorial e protocolo clínico personalizado. Não é só pomada.

Saiba mais →](/fungos-nas-unhas/) [🩺

### Pé do Diabético

Prevenção e tratamento especializado para quem tem diabetes e precisa de cuidado redobrado.

Saiba mais →](/pe-do-diabetico/) [🦶

### Verruga Plantar

Remoção definitiva — sem recidiva e sem dor desnecessária.

Saiba mais →](/verruga-plantar/) [✨

### Podoprofilaxia

Manutenção preventiva dos pés para quem quer evitar problemas antes que apareçam.

Saiba mais →](/podoprofilaxia/)

💉 Resolva hoje mesmo

## Quanto mais você espera,  
mais difícil fica o tratamento.

Unha encravada com dor, inchaço ou infecção não melhora sozinha. Agende sua consulta agora e saia com o problema resolvido — na maioria dos casos, na mesma visita.

⏰ Casos com infecção não podem esperar

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20unha%20encravada.) [📞 (67) 3305-0219](tel:6733050219)

Seg–Sex · 8h às 12h e 13h às 17h  
Rua Doutor Arthur Jorge, 2523 · Campo Grande-MS

Dúvidas frequentes

## Perguntas sobre  
Unha Encravada

O tratamento de unha encravada dói? +

O medo da dor é a principal razão pela qual as pessoas adiam o tratamento — e acabam piorando o caso. Na clínica, usamos analgesia com laser e anestésico tópico, e o procedimento dura em média menos de 1 minuto. **Aproximadamente 95% dos pacientes relatam que foi muito mais rápido e tranquilo do que esperavam** — e o alívio da dor após é imediato.

Precisa de cirurgia para tratar unha encravada? +

Na grande maioria dos casos, não. O tratamento clínico especializado resolve sem cirurgia — inclusive casos com infecção. A matricectomia (remoção da raiz lateral da unha) e a cantoplastia só são indicadas em situações muito específicas quase nunca necessários, com o tratamento correto e com os protocolos que utilizamos em nossa clínica eliminamos não somente o problema da unha encravada, mas também a causa para que não volte a encravar novamente.

Minha unha encravada está com pus. Posso esperar para tratar? +

**Não espere.** Pus indica infecção instalada — e ela pode se aprofundar rapidamente. Ao contrário do que muita gente pensa, não é necessário esperar a infecção "baixar" antes de fazer o procedimento. **O correto é desencravar imediatamente: é a remoção da causa que cessa a infecção.** Em diabéticos, o risco de agravamento é muito maior e a urgência ainda maior.

Quanto tempo leva a recuperação? +

Casos sem infecção geralmente se resolvem na primeira consulta, muitas vezes até sem necessidade com retornos para troca de curativo. Casos com infecção ou tecido granulado levam um pouco mais de tempo, com acompanhamento para troca de curativos e aplicação de laser (quando necessário) até a cicatrização completa. **Todos os retornos estão inclusos no valor do procedimento** — sem custos adicionais.

Como evitar que a unha encrave de novo? +

O reencravamento quase sempre acontece por corte incorreto — em curva, muito rente às bordas laterais. Durante a consulta a podóloga ensina a técnica de corte correto. Além disso, calçados com espaço adequado para os dedos e meias sem compressão excessiva ajudam na prevenção. Para quem tem predisposição genética, o acompanhamento periódico (podoprofilaxia) é o melhor caminho, em casos de marcha ou pisadura errada indicamos palmilhas ortopédicas personalizadas, tudo é resolvido na clínica mesmo sem necessidade de ir a outro local para nada, economizando tempo e deslocamento.

Atende crianças e bebês com unha encravada? +

Sim — inclusive recém-nascidos. Unha encravada em bebês é mais comum do que se imagina, e os sinais são choro excessivo, vermelhidão e febre. O atendimento pediátrico é feito com cuidado especial, técnica adaptada e equipamentos específicos. Os pais podem acompanhar durante todo o procedimento.

Tenho diabetes. Posso fazer o tratamento? +

Sim — e para diabéticos o tratamento é ainda mais urgente. Qualquer lesão no pé de um diabético tem risco elevado de infecção grave e complicações sérias. Liana tem pós-graduação em Diabetes e Complicações Crônicas e especialização em Semiologia do Pé Diabético — é uma das profissionais mais capacitadas de Campo Grande para esse perfil de paciente.

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD

---

## [Página 5] Fungos e Micose (Onicomicose) - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/fungos-micose-onicomicose
- **Profundidade:** 2
- **Descrição:** Vergonha de usar calçados abertos por causa de fungos nas unhas? Podemos te ajudar! Somos a melhor clínica de podologia de Ms
- **Palavras:** 2215 | **Imagens:** 20 | **Links:** 23

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #1 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #2 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #3 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #4 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #5 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #6 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #7 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #8 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #9 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Contexto: "<img decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104.jpg" title="" alt="" load"
> *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Por que pomadas e esmaltes raramente funcionam? • Seção: Conteúdo da Página • Sob: H2: Por que pomadas e esmaltes raramente funcionam?
![Imagem extraída](https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104.jpg)

> **[Imagem 11]** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2-768x960.webp" class="attachment-medium_large size-medium_lar"
> *Posição:* Posição #11 na página • Seção: Conteúdo da Página • Sob H2: A ciência por trás da sua nova unha • Seção: Conteúdo da Página • Sob: H2: A ciência por trás da sua nova unha
![Imagem extraída](images/img_032_2-768x960.webp)

> **[Imagem 12]** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2-768x960.webp" class="attachment-medium_large size-medium_lar"
> *Posição:* Posição #12 na página • Seção: Conteúdo da Página • Sob H2: A ciência por trás da sua nova unha • Seção: Conteúdo da Página • Sob: H2: A ciência por trás da sua nova unha
![Imagem extraída](images/img_033_2-240x300.webp)

> **[Imagem 13]** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2-768x960.webp" class="attachment-medium_large size-medium_lar"
> *Posição:* Posição #13 na página • Seção: Conteúdo da Página • Sob H2: A ciência por trás da sua nova unha • Seção: Conteúdo da Página • Sob: H2: A ciência por trás da sua nova unha
![Imagem extraída](images/img_034_2-819x1024.webp)

> **[Imagem 14]** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2-768x960.webp" class="attachment-medium_large size-medium_lar"
> *Posição:* Posição #14 na página • Seção: Conteúdo da Página • Sob H2: A ciência por trás da sua nova unha • Seção: Conteúdo da Página • Sob: H2: A ciência por trás da sua nova unha
![Imagem extraída](images/img_035_2.webp)

> **[Imagem 15]** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_c5861866-remove"
> *Posição:* Posição #15 na página • Seção: Conteúdo da Página • Sob H2: Especialista com15 Anos Tratando Onicomicose • Seção: Conteúdo da Página • Sob: H2: Especialista com15 Anos Tratando Onicomicose
![Imagem extraída](images/img_036_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_c5861866-remov.webp)

> **[Imagem 16]** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_c5861866-remove"
> *Posição:* Posição #16 na página • Seção: Conteúdo da Página • Sob H2: Especialista com15 Anos Tratando Onicomicose • Seção: Conteúdo da Página • Sob: H2: Especialista com15 Anos Tratando Onicomicose
![Imagem extraída](images/img_037_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_c5861866-remov.webp)

> **[Imagem 17]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
> *Posição:* Posição #17 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 18]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #18 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 19]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #19 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 20]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #20 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

[![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)](https://podologialianagoncalves.com.br/)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20fungo%20nas%20unhas.)

⚡ Protocolo Exclusivo com Laser Terapêutico

# Cansado de esconder seus pés? Elimine os Fungos de vez

Se você já tentou pomadas e esmaltes sem sucesso, conheça o tratamento clínico que atinge a raiz do fungo. Recupere a saúde e a estética das suas unhas com **tecnologia Laser e 15 anos de experiência.**

[Quero Minhas Unhas Saudáveis de Volta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20fungo%20nas%20unhas.)

★★★★★

**4.9/5 estrelas** baseadas em **207 avaliações reais** no Google

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E)

A Ciência da Cura

## Por que pomadas e esmaltes raramente funcionam?

A unha é uma barreira natural extremamente resistente. Quando você aplica uma pomada, ela **não consegue penetrar** na placa ungueal para atingir o fungo que está por baixo. É por isso que você gasta meses e o fungo sempre volta.

#### 🚫 O Ciclo da Frustração

Remédios caseiros e esmaltes de farmácia tratam apenas a superfície. O fungo continua vivo e se alimentando da queratina na parte profunda da sua unha.

### 💡 A Solução: Laser Terapêutico

O feixe de luz do Laser atravessa a unha sem dor, atingindo diretamente o foco do fungo e eliminando a infecção de dentro para fora.

[Consultar Especialista em Laser](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20fungo%20nas%20unhas.)

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20768%20960'%3E%3C/svg%3E)

Resultados Comprovados

## A ciência por trás da sua nova unha

Ao lado, você vê o que acontece quando unimos tecnologia de ponta com conhecimento clínico. Não é apenas estética; é a recuperação da saúde da sua unha através de um protocolo validado por quem entende de **Dermatologia e Diabetes.**

_✓_ Pós-Graduada em Dermatologia

_✓_ Especialista em Pé Diabético

_✓_ 15 anos eliminando micoses resistentes

"Muitos pacientes chegam desanimados após anos de tentativas. O segredo está no diagnóstico correto e no uso do Laser DMC para esterilizar a área."

[Agendar com a Especialista](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20fungo%20nas%20unhas.)

A voz de quem viveu

## Mais de 2.000 pacientes.  
207 avaliações. Uma consistência.

★★★★★ 4.9 · média Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

## Dúvidas Comuns sobre o Tratamento

### ⏱️ Quanto tempo leva para a unha ficar limpa?

O resultado é visível ja nas primeiras sessões, mas a aparência da unha melhora conforme ela cresce. Uma unha saudável cresce cerca de 1 a 2 milímetros por mês, por isso o acompanhamento mensal é fundamental para garantir que a nova unha nasça 100% livre da infecção.

### 🩹 O Laser dói ou queima?

Absolutamente não. O Laser DMC que utilizamos emite um feixe de luz que gera apenas uma leve sensação de aquecimento, totalmente suportável. É um procedimento seguro, indolor e sem efeitos colaterais.

### 👞 Posso usar sapatos normalmente?

Sim! Diferente de cirurgias, o tratamento a laser não exige repouso. Você sai da clínica e segue sua rotina normalmente. Inclusive, orientamos sobre como higienizar seus calçados para evitar que o fungo retorne.

Tecnologia a seu favor

## Recupere a liberdade dos seus pés

Não espere o fungo destruir toda a sua unha. Comece o seu protocolo hoje com a **Consulta Bonificada** ao fechar o tratamento.

[Quero Minhas Unhas Saudáveis](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20fungo%20nas%20unhas.)

🔬 Tratamento Clínico Especializado

# Fungo nas Unhas?  
Tratamento de Verdade  
— Não Só Pomada

A onicomicose não some com produto de farmácia. O tratamento correto começa com diagnóstico laboratorial e protocolo clínico personalizado — feito por especialista com 15 anos de experiência.

⚠️

**Se você está usando pomada ou esmalte antifúngico há meses sem resultado,** provavelmente o fungo já atingiu a matriz da unha. Quanto mais tempo passa, mais difícil é o tratamento.

[📲 Agendar Consulta pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20fungo%20nas%20unhas.) [Como funciona o tratamento ↓](#como-funciona)

15 anos de Especialização

2.000+ Pacientes Tratados

90% Taxa de Sucesso

4.9 ★ 207 Avaliações Google

Você se identifica?

## Sinais de que Você  
Pode Ter Fungo nas Unhas

A onicomicose raramente causa dor nos estágios iniciais — por isso muita gente ignora até o problema se agravar. Se você percebe qualquer um dos sinais abaixo, o momento de tratar é agora.

🟡

### Unhas amareladas ou marrons

A mudança de cor é um dos primeiros sinais. A unha perde o aspecto saudável e rosado, ficando opaca e descolorida.

📏

### Unha grossa e difícil de cortar

O fungo altera a estrutura da placa ungueal, deixando-a mais espessa, dura e quebradiça do que o normal.

🔍

### Separação da unha do dedo

A onicólise — descolamento da unha — é um sinal avançado de que o fungo está comprometendo a base da una.

💨

### Odor desagradável

A proliferação do fungo entre a unha e a pele pode gerar odor, especialmente após o uso de calçados fechados.

🧩

### Bordas irregulares e quebradiças

A destruição da estrutura da unha faz as bordas se desfazerem facilmente, dificultando até o corte doméstico.

📦

### Meses usando pomada sem resultado

Se você já tentou esmalte ou creme antifúngico e a unha não melhorou, é sinal de que o fungo está na matriz — onde produtos tópicos não chegam.

🚨

### Quanto mais tempo espera, mais unhas são afetadas

O fungo é contagioso e se espalha para as outras unhas — e até para outras pessoas da família. **Um caso de 2 unhas pode virar 8 ou 10 sem tratamento adequado.** Além disso, em pacientes diabéticos o fungo pode abrir porta para infecções sérias que colocam o pé em risco.

Por que não resolve sozinho

## Produto de Farmácia  
Não Elimina o Fungo da Matriz

Esmaltes e cremes antifúngicos agem na superfície da unha. O problema é que o fungo vive na matriz — a raiz da unha — onde nenhum produto tópico consegue penetrar em concentração suficiente para eliminar a infecção. É por isso que o tratamento sem diagnóstico e protocolo clínico raramente funciona.

❌

### Tratamento por conta própria

-   Sem diagnóstico — pode ser psoríase, trauma ou outra condição, não fungo
-   Produto age só na superfície, não chega à matriz da unha
-   Meses de uso sem resultado real — dinheiro perdido
-   O fungo continua se espalhando para outras unhas
-   Risco de piora e contaminação de familiares
-   Sem acompanhamento, sem plano e sem previsão de cura

✅

### Tratamento com protocolo profissional e resultados comprovados

-   Coleta micológica laboratorial para confirmar se é fungo e qual tipo
-   Protocolo clínico personalizado com base no resultado do exame
-   Limpeza especializada da área infectada já na 1ª consulta
-   Laser DMC Therapy iLib e XT — referência no mercado
-   Acompanhamento completo até a resolução do caso
-   Evolução real com resultados desde o início do tratamento

🔬

### Diagnóstico laboratorial: o que diferencia nosso tratamento

Na maioria dos casos de "fungo nas unhas" tratados por conta própria, o diagnóstico é incorreto. Somente o exame micológico confirma se é realmente um fungo — e qual espécie — permitindo escolher o tratamento certo. Em nosso protocolo a coleta para análise e a análise laboratorial estão incluídos na consulta inicial.

Passo a passo

## Como Funciona o  
Tratamento de Fungo nas Unhas

1

1ª Consulta

### Avaliação clínica e coleta micológica

Nossa podóloga avalia o estado das unhas, identifica o grau de comprometimento e realiza a coleta para exame micológico laboratorial. O exame confirma se é fungo (e qual espécie) — base para o tratamento correto. O resultado sai em aproximadamente 15 dias.

2

Ainda na 1ª consulta

### Primeira limpeza especializada

Já na consulta inicial, é realizada a remoção do tecido infectado da área afetada — procedimento que alivia o desconforto e prepara a unha para o tratamento. Sem dor, com técnica especializada.

3

Com resultado do exame

### Plano de tratamento personalizado

Com o laudo em mãos, a podóloga monta o protocolo ideal para o seu caso: combinação de laser DMC, medicação oral e/ou tópica adequada, e frequência de retornos. Cada caso é tratado de forma individual — não existe protocolo genérico aqui.

4

Sessões de acompanhamento

### Laser DMC + limpezas periódicas + aplicação de ozônio

O laser DMC é o equipamento referência do mercado para onicomicose — age diretamente no fungo sem agredir a pele ou a unha. As sessões são combinadas com limpezas clínicas periódicas e aplicações de ozônio o combate ao fungo até a resolução completa.

5

Resultado

### Unhas saudáveis com protocolos testados e resultado real

Você percebe o avanço no tratamento desde a 1ª consulta. O crescimento de unhas novas e saudáveis é progressivo — com acompanhamento até a resolução completa do caso.

### O que está incluso na Consulta Inicial

Tudo que você precisa para começar o tratamento com segurança — em uma única consulta.

R$ 370,00

Consulta inicial · Valor único

Avaliação clínica completa das unhas

Coleta e exame micológico laboratorial

Primeira limpeza especializada

Plano de tratamento personalizado

Orientações para o período em casa

Resultados visíveis desde a 1ª consulta

[📲 Agendar minha consulta agora](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20fungo%20nas%20unhas.)

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20433%20577'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

Quem vai te atender

## Especialista com  
15 Anos Tratando Onicomicose

Liana Gonçalves é graduada em Podologia pela Unicesumar, com pós-graduações em Diabetes, Dermatologia e Tratamento de Feridas. Participa anualmente do CIAP — o principal congresso internacional de podologia — e foi convidada para eventos destinados exclusivamente a médicos.

Não é à toa que médicos e dermatologistas de Campo Grande indicam a clínica para seus pacientes. Com mais de 2.000 pacientes tratados e taxa de sucesso de 90%, você está em mãos experientes.

✓ Graduação em PodologiaUnicesumar · Nível Superior

✓ Pós-Grad. Diabetese Complicações Crônicas

✓ Laser DMC TherapyiLib e XT — referência do mercado

✓ CIAP Internacional2023 · 2024 · 2025

✓ Indicada por médicose dermatologistas de CG

✓ 50+ cursos e especializaçõesem podologia clínica

Dúvidas frequentes

## Perguntas sobre  
Tratamento de Fungo

Quanto custa o tratamento de fungo nas unhas? +

A consulta inicial custa **R$ 370,00** e já inclui avaliação clínica, coleta e exame micológico laboratorial, primeira limpeza e plano de tratamento personalizado. O custo das sessões seguintes varia conforme o protocolo definido após o resultado do exame — que depende do tipo e grau de comprometimento do fungo. Você recebe uma previsão completa de valores logo na primeira consulta, sem surpresas.

O tratamento de fungo nas unhas dói? +

Não. A limpeza clínica e as sessões de laser e ozônio são realizadas com técnica especializada e não causam dor. O laser DMC e o ozônio agem diretamente no fungo sem agredir a pele ou a estrutura da unha. A maioria dos pacientes relata apenas uma leve sensação de calor durante a aplicação.

Quanto tempo leva para o fungo sumir? +

Depende uma série de fatores, como tempo de contaminação, resposta do sistema imunológico, grau de comprometimento das unhas e do número de unhas afetadas. Casos iniciais podem se resolver mais rápido; casos avançados podem levar mais tempo, acompanhando o crescimento da unha saudável. **Todas as informações possíveis são passadas na consulta inicial**, com base no seu exame — não trabalhamos com respostas genéricas.

Por que o esmalte antifúngico da farmácia não funcionou? +

Produtos tópicos agem na superfície da unha, mas o fungo vive na matriz — a raiz. A concentração do princípio ativo não é suficiente para eliminar a infecção na profundidade. Além disso, muitos casos diagnosticados como "fungo" são na verdade psoríase ungueal ou trauma — condições que não respondem a antifúngico. Só o exame micológico confirma o diagnóstico correto.

O plano de saúde cobre o tratamento? +

A clínica trabalha como particular. Aceitamos Pix, débito e crédito em até 10 vezes (sujeito à taxa da operadora). Nosso foco é oferecer a melhor qualidade de atendimento, equipamentos e protocolo — sem limitações impostas por convênios.

Tenho diabetes. Posso fazer o tratamento? +

Sim — e para diabéticos o tratamento é ainda mais urgente. O fungo nas unhas pode evoluir para infecções graves no pé diabético, com risco real de complicações sérias. Liana tem pós-graduação em Diabetes e Complicações Crônicas e especialização em Semiologia do Pé Diabético — é uma das profissionais mais capacitadas de Campo Grande para tratar esse perfil de paciente.

🔬 Comece o tratamento certo

## Chega de tentar  
produto que não resolve.

O tratamento de fungo nas unhas tem solução — com diagnóstico correto e protocolo clínico especializado. Agende sua consulta e saia com um plano real nas mãos.

⏰ Quanto mais cedo, mais simples e rápido é o tratamento

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20fungo%20nas%20unhas.) [📞 (67) 3305-0219](tel:6733050219)

Seg–Sex · 8h às 12h e 13h às 17h  
Rua Doutor Arthur Jorge, 2523 · Campo Grande-MS

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD

---

## [Página 6] Olho de peixe (verruga plantar) - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/olho-de-peixe-verruga-plantar
- **Profundidade:** 2
- **Descrição:** Você sofre com unha encravada ou infeccionada? pare de sentir dor hoje mesmo! volte a ter qualidade de vida e liberdade para usar calçados.
- **Palavras:** 1810 | **Imagens:** 15 | **Links:** 26

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #1 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #2 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #3 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #4 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #5 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #6 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #7 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #8 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #9 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Contexto: "<img decoding="async" width="720" height="980" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175282399.jpeg" cla"
> *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Especialização em Laser — não só o equipamento,a técnica por trás dele • Seção: Conteúdo da Página • Sob: H2: Especialização em Laser — não só o equipamento,a técnica por trás dele
![Imagem extraída](images/img_010_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399.jpg)

> **[Imagem 11]** Contexto: "<img decoding="async" width="720" height="980" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175282399.jpeg" cla"
> *Posição:* Posição #11 na página • Seção: Conteúdo da Página • Sob H2: Especialização em Laser — não só o equipamento,a técnica por trás dele • Seção: Conteúdo da Página • Sob: H2: Especialização em Laser — não só o equipamento,a técnica por trás dele
![Imagem extraída](images/img_011_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399-220x300.jpg)

> **[Imagem 12]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
> *Posição:* Posição #12 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 13]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #13 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 14]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #14 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 15]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #15 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20verruga%20plantar.)

🎯 Remoção definitiva com protocolo comprovado

# Chega de evitar  
praia, piscina e academia  
por causa do olho de peixe.

A verruga plantar não some sozinha — e quanto mais você espera, mais o vírus do HPV se espalha e cresce. Com nossos protocolos e auxílio do laser DMC, eliminamos o problema pela raiz: sem cirurgia, sem pontos, sem cicatriz e sem precisar ficar parado.

⚠️

**Não tente remover em casa.** Cortar, lixar ou aplicar produtos ácidos sem orientação profissional pode espalhar o HPV para outras áreas do pé — transformando uma verruga em várias.

[📲 Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20verruga%20plantar.) [Como funciona o laser ↓](#vp-tratamento)

Laser DMC referência do  
mercado nacional

Sem cirurgia protocolo  
comprovado

15 anos de experiência  
especializada

4.9 ★ 207 avaliações  
no Google

Entenda o problema

## O que é a Verruga Plantar  
e por que ela não some sozinha

Você provavelmente já tentou de tudo: ácido, esparadrapo, produtos da farmácia. Talvez até tratou em casa. E ela voltou — ou piorou. Isso acontece porque a verruga plantar não é um problema de superfície. O HPV vive nas camadas profundas da pele, e nada que age por fora consegue eliminá-lo de verdade. Enquanto não for tratada corretamente, ela cresce, aprofunda e se multiplica.

### 🚨 Sinais de que é verruga plantar

-   Dor ao pisar sobre a área contaminada
-   Lesão endurecida com pontinhos escuros no centro (capilares sanguíneos)
-   Pele espessada ao redor da lesão
-   Dor que piora com pressão direta sobre a área
-   Pode aparecer isolada ou em grupos (mosaico plantar)

### ⚡ Por que ela se multiplica

-   O HPV é altamente contagioso por contato direto com a lesão
-   Lixar ou cortar em casa libera partículas virais que infectam áreas vizinhas
-   Andar descalço em locais úmidos facilita a reinfecção
-   Sistema imunológico enfraquecido favorece a proliferação
-   Uma verruga não tratada pode virar 10 em poucos meses

🔬

### Verruga vs. Calo: você sabe diferenciar?

Muita gente trata verruga como calo — e vice-versa — perdendo meses sem resultado. A diferença principal: **o calo não tem pontinhos escuros e a maioria dos casos doem com pressão lateral**. A verruga não. Só uma avaliação clínica confirma o diagnóstico correto e define o tratamento adequado.

⚠️ O erro mais comum

## Por que Tratamento Caseiro  
Quase Sempre Piora

Produtos ácidos, esparadrapo, lixar, cortar — a internet está cheia de "soluções" para verruga plantar. O problema é que nenhuma delas elimina o vírus pela raiz, e muitas ativamente espalham a infecção para áreas vizinhas.

❌

### Tentativa em casa

-   Ácido age na superfície — a raiz viral permanece intacta
-   Lixar e cortar liberam partículas do HPV que infectam outras regiões
-   Sem diagnóstico correto — pode ser calo, não verruga
-   Risco de lesão na pele sã ao redor, abrindo porta para infecção bacteriana
-   Meses de tentativa sem resultado — enquanto a verruga se expande

✅

### Tratamento em nossa clínica

-   Laser DMC age diretamente no tecido infectado — elimina pela raiz
-   Sem corte profundo, sem pontos e sem cicatriz visível
-   Diagnóstico clínico diferencia verruga de calo antes de tratar
-   Protocolo individualizado conforme número, tamanho e localização
-   Orientações para evitar reinfecção e proteger as áreas vizinhas

Com uma ou muitas — **cada caso tem um protocolo específico.** Agende uma consulta e saiba qual é o melhor caminho para o seu.

[📲 Agendar avaliação](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20avalia%C3%A7%C3%A3o%20para%20verruga%20plantar.)

Como funciona

## Remoção com Laser DMC:  
Remoção Pela Raiz, sem corte profundo

1

Avaliação clínica · valor após consulta

### Diagnóstico e avaliação clínica

A podóloga examina a lesão, confirma que é verruga plantar (diferenciando de calo com núcleo e outras condições), avalia tamanho, profundidade e número de lesões. **O plano de tratamento é definido aqui** — você sai da consulta sabendo exatamente o que esperar.

2

Preparação

### Avaliação do nível de sensibilidade antes de começar

O tratamento com laser para verruga plantar não costuma causar dor aguda na maioria dos casos — o que surpreende muitos pacientes que chegam com medo. A sensação durante a aplicação é geralmente de calor ou leve desconforto, bem tolerada. Quando necessário, pode ser utilizado anestésico tópico, mas isso não é a regra.

3

Sessão de laser

### Laser DMC age diretamente no tecido infectado

O laser destrói as células infectadas pelo HPV e coagula os vasos que alimentam a verruga — eliminando pela raiz. O procedimento utiliza bisturi para desbaste do tecido contaminado como parte do protocolo clínico, com cicatrização mais rápida e controlada do que métodos convencionais.

4

Pós-sessão

### Curativo + orientações de cuidado em casa

Após cada sessão, curativo adequado é aplicado e você recebe orientações detalhadas de como cuidar em casa, indicação dos produtos mais eficientes para utilizar, quando molhar o pé e sinais de que a recuperação está indo bem. Casos com múltiplas verrugas ou mosaico plantar exigem mais sessões com intervalo entre elas.

⚡

### Laser DMC Therapy — a referência do mercado

A Clínica utiliza os equipamentos DMC Therapy iLib e XT — os lasers de referência no mercado nacional para tratamentos podológicos. A precisão do laser permite agir exatamente na profundidade da lesão, preservando o tecido saudável e acelerando a cicatrização após a remoção.

Protocolo clínico especializado Sem pontos Sem cicatriz visível Certificação DMC Referência nacional

Investimento

Consulta R$ 150,00

Valor da consulta fica isento fechando tratamento no dia da primeira consulta. Valor do tratamento, número de sessões e protocolo a ser adotado definidos na avaliação conforme tamanho, profundidade e quantidade de lesões

-   Avaliação clínica e diagnóstico diferencial
-   Plano de tratamento individualizado
-   Sessões de laser DMC Therapy
-   Curativo pós-sessão incluído
-   Orientações completas de cuidado em casa

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20verruga%20plantar.)

### O que determina o número de sessões

1️⃣

#### Verruga única e superficial

Geralmente se resolve com menos tempo, quanto antes se iniciar o tratamento, mais rápido o vírus é elimiando.

🔢

#### Múltiplas verrugas

Pode levar um pouco mais de tempo para eliminar a infecção por completo dependendo do grau de contaminação.

🗺️

#### Mosaico plantar

Verrugas em cluster exigem protocolo específico — mais sessões e acompanhamento mais próximo

⏱️

#### Tempo de diagnóstico

Verrugas antigas e mais profundas geralmente exigem mais sessões do que as recentes

**Formas de pagamento:** Pix, débito e crédito em até 10 vezes (taxa operadora). Clínica particular — não atendemos convênios.

Especialista responsável

## Especialização em Laser —  
não só o equipamento,  
a técnica por trás dele

Qualquer clínica pode comprar um laser. O que diferencia o resultado é saber calibrá-lo para cada tipo de lesão — profundidade, tamanho, localização, tempo de diagnóstico. Liana tem certificação específica em laser terapêutico (Descomplicando Laserterapia) e opera os equipamentos DMC Therapy iLib e XT com domínio técnico de quem entende o que acontece sob a pele a cada disparo. **Cada sessão é calibrada individualmente — não existe protocolo genérico aqui.**

Participante dos três últimos congressos CIAP — maior evento internacional de podologia — e formadora de outros profissionais no MS, Liana traz para cada tratamento o protocolo mais atual disponível na área.

### ⚡ Especialização em laser podológico

Certificação em Laser Terapêutico — Descomplicando Laserterapia · Equipamentos DMC Therapy iLib e XT · Protocolo de calibração por tipo e profundidade de lesão.

✓ Graduação em PodologiaUnicesumar · Nível Superior

✓ Especialização em LaserDescomplicando Laserterapia

✓ Laser DMC TherapyiLib e XT — referência nacional

✓ CIAP Internacional2023 · 2024 · 2025

✓ Pós-grad. Dermatologiae Tratamento de Feridas

✓ 50+ especializaçõese cursos livres

🩺

**Indicada por médicos e dermatologistas de Campo Grande** para tratamento de verruga plantar — especialmente casos com múltiplas lesões ou histórico de recidiva após tratamento convencional.

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20720%20980'%3E%3C/svg%3E)

✓ Indicada por Médicos

e Dermatologistas de CG

Dúvidas frequentes

## Perguntas sobre  
Verruga Plantar

Quantas sessões de laser são necessárias? +

Depende do tamanho, profundidade e número de verrugas. Casos simples podem resolver em até 4 sessões. Múltiplas verrugas ou mosaico plantar exigem mais sessões. **Na avaliação a podóloga define o plano completo e você já sabe o que esperar antes de começar.**

O tratamento com laser dói? +

A aplicação de laser de baixa potência não causa dor, pelo contrário, ele tem função analgésica — o que surpreende quem chega com medo do procedimento. A sensação durante a aplicação do laser é geralmente de calor leve relatado por alguns pacientes.

Vou ficar com cicatriz após a remoção? +

Na grande maioria dos casos, não. O laser DMC preserva o tecido saudável ao redor da lesão, o que permite uma cicatrização limpa. Em lesões muito profundas ou extensas, pode ficar uma área de pele levemente diferente temporariamente — mas sem cicatriz permanente relevante.

Posso andar normalmente após a sessão? +

Sim, com alguns cuidados. É possível caminhar logo após a sessão — mas atividades que geram pressão intensa na área (corrida, esportes) devem ser evitadas logo após o procedimento. Orientamos sobre calçado adequado e cuidados específicos para cada paciente no pós-sessão.

A verruga pode voltar depois do tratamento? +

O laser elimina a verruga existente pela raiz. Porém, como o HPV pode permanecer no organismo, há risco de reinfecção — especialmente se o sistema imunológico estiver comprometido. **Orientamos sobre prevenção de reinfecção**: higiene adequada, não andar descalço em locais úmidos e de uso comum e cuidados no período pós-tratamento para reduzir ao máximo esse risco.

Criança e diabético podem fazer o tratamento com laser? +

Sim para ambos — com protocolo adaptado. Em crianças, o procedimento é adaptado à faixa etária com toda a cautela necessária, e os pais ficam presentes durante todo o atendimento. Em diabéticos, o cuidado é redobrado em cada etapa do tratamento e da cicatrização, com acompanhamento mais próximo. Liana tem formação específica em pé diabético e podopediatria.

Quem já foi atendido

## O que nossos pacientes  
dizem sobre o atendimento

★★★★★ 4.9 · 207 avaliações no Google

★★★★★

"Acolhedor, ótimo atendimento, passa segurança e confiança. Obrigada!"

L

Luzia Petricio

Verificado no Google

★★★★★

"Atendimento excelente, desde a recepcionista até o procedimento realizado pela doutora Liana. Indico o consultório com certeza!"

A

Avaliação Google

Verificado no Google

★★★★★

"Gostei muito, trabalho sensacional, atenciosos e explicam bem o tratamento para os pés, muito bom mesmo!"

J

Avaliação Google

Verificado no Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

Também tratamos

## Outros Tratamentos na Clínica

Resolve tudo em um só lugar — com o mesmo nível de cuidado e especialização.

[🦠

### Fungos nas Unhas

Diagnóstico laboratorial e protocolo clínico especializado.

Saiba mais →](/fungos-micose-onicomicose/) [🩹

### Unha Encravada

Alívio imediato da dor. Atendemos inclusive casos com infecção.

Saiba mais →](/unha-encravada/) [🩺

### Pé do Diabético

Acompanhamento mensal especializado e preventivo.

Saiba mais →](/pe-do-diabetico/) [👶

### Podopediatria

Cuidados específicos para crianças e bebês de todas as idades.

Saiba mais →](/podopediatria/)

🎯 Elimine de vez

## Cada dia sem tratar  
é um dia a mais de dor e risco de espalhar.

Agende sua consulta — identificamos quantas lesões existem, qual o protocolo ideal e quantas sessões você precisará. Você sai com um plano claro nas mãos.

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20verruga%20plantar.) [📞 (67) 3305-0219](tel:6733050219)

Seg–Sex · 8h às 12h e 13h às 17h  
Rua Doutor Arthur Jorge, 2523 · Campo Grande-MS

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD

---

## [Página 7] Pés do diabetico - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/pes-do-diabetico
- **Profundidade:** 2
- **Descrição:** Ligue agora! Agendar Consulta 🩺 Pós-Graduação em Diabetes e Complicações Crônicas Segurança máxima para o Pé do Diabético Para quem tem diabetes, um corte errado pode ser fatal. Proteja sua saúde com um acompanhamento clínico especializado, protocolos de biossegurança e 15 anos de experiência em prevenção de complicações. Agendar Avaliação Especializada ★★★★★ 4.9/5 estrelas baseadas […]
- **Palavras:** 2809 | **Imagens:** 23 | **Links:** 24

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #1 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #2 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #3 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #4 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #5 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #6 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #7 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #8 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #9 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Contexto: "<img decoding="async" width="768" height="857" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104-"
> *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real? • Seção: Conteúdo da Página • Sob: H2: Por que um "cortezinho" é um risco real?
![Imagem extraída](images/img_038_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp)

> **[Imagem 11]** Contexto: "<img decoding="async" width="768" height="857" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104-"
> *Posição:* Posição #11 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real? • Seção: Conteúdo da Página • Sob: H2: Por que um "cortezinho" é um risco real?
![Imagem extraída](images/img_039_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp)

> **[Imagem 12]** Contexto: "<img decoding="async" width="768" height="857" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104-"
> *Posição:* Posição #12 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real? • Seção: Conteúdo da Página • Sob: H2: Por que um "cortezinho" é um risco real?
![Imagem extraída](images/img_040_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp)

> **[Imagem 13]** Contexto: "<img decoding="async" width="768" height="857" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104-"
> *Posição:* Posição #13 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real? • Seção: Conteúdo da Página • Sob: H2: Por que um "cortezinho" é um risco real?
![Imagem extraída](images/img_041_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp)

> **[Imagem 14]** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-im"
> *Posição:* Posição #14 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real? • Seção: Conteúdo da Página • Sob: H2: Por que um "cortezinho" é um risco real?
![Imagem extraída](images/img_042_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

> **[Imagem 15]** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-im"
> *Posição:* Posição #15 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real? • Seção: Conteúdo da Página • Sob: H2: Por que um "cortezinho" é um risco real?
![Imagem extraída](images/img_043_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

> **[Imagem 16]** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-im"
> *Posição:* Posição #16 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real? • Seção: Conteúdo da Página • Sob: H2: Por que um "cortezinho" é um risco real?
![Imagem extraída](images/img_044_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

> **[Imagem 17]** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-im"
> *Posição:* Posição #17 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real? • Seção: Conteúdo da Página • Sob: H2: Por que um "cortezinho" é um risco real?
![Imagem extraída](images/img_045_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

> **[Imagem 18]** Contexto: "<img loading="lazy" decoding="async" width="720" height="980" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e17731752"
> *Posição:* Posição #18 na página • Seção: Conteúdo da Página • Sob H2: Formação Específica em Diabetes e Pé Diabético • Seção: Conteúdo da Página • Sob: H2: Formação Específica em Diabetes e Pé Diabético
![Imagem extraída](images/img_010_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399.jpg)

> **[Imagem 19]** Contexto: "<img loading="lazy" decoding="async" width="720" height="980" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e17731752"
> *Posição:* Posição #19 na página • Seção: Conteúdo da Página • Sob H2: Formação Específica em Diabetes e Pé Diabético • Seção: Conteúdo da Página • Sob: H2: Formação Específica em Diabetes e Pé Diabético
![Imagem extraída](images/img_011_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399-220x300.jpg)

> **[Imagem 20]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
> *Posição:* Posição #20 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 21]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #21 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 22]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #22 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 23]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #23 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

[![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)](https://podologialianagoncalves.com.br/)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.)

🩺 Pós-Graduação em Diabetes e Complicações Crônicas

# Segurança máxima para o Pé do Diabético

Para quem tem diabetes, um corte errado pode ser fatal. Proteja sua saúde com um acompanhamento clínico especializado, protocolos de biossegurança e **15 anos de experiência em prevenção de complicações.**

[](whatsapp-float)[Agendar Avaliação Especializada](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.)

★★★★★

**4.9/5 estrelas** baseadas em **207 avaliações reais** no Google

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20768%20857'%3E%3C/svg%3E)

Prevenção é Sobrevivência

## Por que um "cortezinho" é um risco real?

Para quem tem diabetes, a cicatrização é mais lenta e a sensibilidade nos pés pode estar reduzida. Isso significa que você pode se machucar e **não sentir**, abrindo porta para infecções que evoluem rapidamente.

#### ⚠️ O Perigo da Neuropatia

A perda de sensibilidade faz com que muitos diabéticos tentem cortar calos ou unhas em casa e acabem criando feridas profundas sem perceber. Na podologia clínica, isso nunca acontece.

_✓_ Materiais 100% Estéreis (Autoclave)

_✓_ Descartáveis de uso único

_✓_ Ambiente Clínico Rigoroso

_✓_ Técnica Indolor e Segura

[Agendar com Segurança Máxima](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.)

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20768%20960'%3E%3C/svg%3E)

Prevenção é Sobrevivência

## Por que um "cortezinho" é um risco real?

Para quem tem diabetes, a cicatrização é mais lenta e a sensibilidade nos pés pode estar reduzida. Isso significa que você pode se machucar e **não sentir**, abrindo porta para infecções que evoluem rapidamente.

#### ⚠️ O Perigo da Neuropatia

A perda de sensibilidade faz com que muitos diabéticos tentem cortar calos ou unhas em casa e acabem criando feridas profundas sem perceber. Na podologia clínica, isso nunca acontece.

_✓_ Materiais 100% Estéreis (Autoclave)

_✓_ Descartáveis de uso único

_✓_ Ambiente Clínico Rigoroso

_✓_ Técnica Indolor e Segura

[Agendar com Segurança Máxima](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.)

Aviso de Saúde Crítico

## A cada 20 segundos, um diabético perde um pé

No Brasil, a diabetes é a maior causa de amputações não traumáticas. O que começa com uma simples unha encravada ou um calo mal cortado pode se transformar em uma **úlcera profunda** que leva à perda do membro em poucos dias.

#### 🚨 Não espere o pior acontecer

A perda de sensibilidade (neuropatia) é silenciosa. Você pode estar com uma ferida aberta e **não sentir absolutamente nada** até que a infecção atinja o osso. O acompanhamento clínico não é um luxo, é a **única forma de garantir que você continuará caminhando.**

Tratamento conduzido por Especialista com Pós-Graduação em Diabetes e 15 anos de experiência clínica.

[Proteger Meus Pés da Amputação](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.)

## Tire suas dúvidas e proteja sua saúde

### 🧐 Por que eu não posso cortar minhas unhas em casa?

O diabético muitas vezes tem a visão comprometida ou perda de sensibilidade nos pés (neuropatia). Isso faz com que você possa se cortar sem perceber. Um pequeno ferimento pode evoluir para uma infecção óssea e amputação em poucos dias. Na clínica, usamos iluminação cirúrgica e técnica especializada para sua segurança total.

### 📅 De quanto em quanto tempo devo vir à clínica?

O padrão ouro para a segurança do diabético é o acompanhamento mensal. Em 30 dias, unhas crescem e calosidades podem surgir, criando pontos de pressão que geram úlceras invisíveis. A visita mensal garante que qualquer problema seja detectado e resolvido antes de se tornar uma emergência.

### 🩹 Já estou com uma ferida, vocês tratam?

Sim! A Liana possui pós-graduação em Tratamento de Feridas e utiliza protocolos avançados com Laserterapia e Ozonioterapia para acelerar a cicatrização e combater infecções. Se você notou qualquer alteração, a hora de agir é agora.

Sua vida em primeiro lugar

## Proteja seu futuro e sua mobilidade

Não faça parte das estatísticas de amputação. Garanta sua **Consulta Bonificada** ao iniciar seu acompanhamento preventivo hoje.

[Proteger Meus Pés Agora](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.)

A voz de quem viveu

## Mais de 2.000 pacientes.  
207 avaliações. Uma consistência.

★★★★★ 4.9 · média Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

🩺 Especialista em pé diabético · Campo Grande-MS

# Seu pé não sente a dor.  
Mas o estrago acontece  
do mesmo jeito.

A neuropatia diabética silencia os sinais de alerta. Feridas evoluem sem dor. Infecções se aprofundam sem aviso. O acompanhamento especializado não é sobre conforto — é sobre manter seus dois pés.

🚨

**85% das amputações em diabéticos começam com uma lesão pequena e ignorada.** Não porque era inevitável — mas porque não houve acompanhamento especializado a tempo. Esse é exatamente o ciclo que quebramos aqui.

[📲 Agendar Consulta pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.) [Entender os riscos ↓](#pd-riscos)

15 anosde Especialização

2.000+Pacientes Tratados

3 Pós-gradsincl. Diabetes e Feridas

4.9 ★207 Avaliações Google

Entenda o risco

## Por que o Pé do Diabético  
Exige Cuidado Especializado

O diabetes não avisa quando está destruindo os nervos e os vasos dos seus pés. Ele age em silêncio — por meses, por anos. É por isso que o problema chega avançado na maioria das vezes: não faltou atenção, faltou informação sobre o que olhar.

⚡

### Mecanismo 1Neuropatia Diabética

O excesso de glicose danifica os nervos periféricos dos pés ao longo do tempo. O resultado: **perda progressiva da sensibilidade** — dor, calor, pressão e lesões deixam de ser sentidos normalmente.

**Consequência:** Feridas, bolhas, unhas encravadas e calos passam despercebidos e evoluem silenciosamente por dias ou semanas sem que o paciente perceba.

🩸

### Mecanismo 2Doença Vascular Periférica

O diabetes também compromete os vasos sanguíneos, reduzindo o fluxo de sangue para os pés. Com menos circulação, **a capacidade de cicatrização fica gravemente comprometida**.

**Consequência:** Uma ferida que em uma pessoa saudável cicatrizaria em dias, em um diabético pode levar semanas — e facilmente se infectar e se transformar em úlcera.

### Classificação de Risco — Quanto maior o risco, mais intenso o protocolo. Mas o acompanhamento mensal é para todos.

0

#### Sem complicações

Sem neuropatia ou doença vascular. Acompanhamento mensal preventivo para manter esse quadro.

1

#### Neuropatia presente

Sensibilidade já comprometida. Acompanhamento mensal para monitorar progressão e proteger a pele.

2

#### Risco alto

Neuropatia com deformidades ou doença vascular. Protocolo mensal intensivo com avaliação estruturada.

3

#### Risco muito alto

Histórico de úlcera ou amputação. Acompanhamento mensal obrigatório — sem exceção.

⚠️

### Não sabe qual é o seu risco? Você não está sozinho — e tem como descobrir hoje.

A maioria dos pacientes que chega à clínica nunca recebeu uma avaliação formal do risco do pé diabético. Na consulta inicial, Liana realiza a semiologia completa — neurológica, vascular, biomecânica — e você sai sabendo exatamente em que categoria está e o que fazer a partir de agora.

🚨 Não ignore esses sinais

## Sinais de Alerta que  
Todo Diabético Deve Conhecer

O perigo do pé diabético é que muitos sinais graves aparecem **sem dor** — justamente por causa da neuropatia. Se você tem diabetes, esses sinais exigem avaliação imediata.

⚡ Procure hoje

🩹

### Ferida que não cicatriza

Qualquer ferida no pé de um diabético que não fechar em 2 semanas é sinal de comprometimento vascular sério.

⚡ Procure hoje

🔴

### Vermelhidão com calor local

Pode indicar infecção profunda ou Charcot agudo — condição grave que destrói os ossos do pé se não tratada rapidamente.

⚡ Procure hoje

💧

### Secreção ou mau cheiro

Indica infecção ativa. Em diabéticos, infecções se aprofundam rapidamente e podem atingir tendões e ossos.

😶

### Dormência ou formigamento

Sinais clássicos de neuropatia periférica — indicam que a sensibilidade protetora está comprometida.

🦶

### Calos espessos e recorrentes

Em diabéticos, calos aumentam a pressão local e podem gerar úlceras por baixo deles — sem que o paciente sinta.

🌡️

### Pés sempre frios ou quentes

Assimetria de temperatura entre os pés pode indicar doença arterial periférica com redução de fluxo sanguíneo.

O que fazemos

## Condições Tratadas na  
Clínica para Pacientes Diabéticos

🔬

### Avaliação completa

Avaliação completa e biomecânica dos pés — com classificação de risco e protocolo personalizado.

🩹

### Tratamento de úlceras e feridas

Curativos especializados, desbridamento e acompanhamento da cicatrização com laser DMC.

💉

### Unha encravada em diabéticos

Protocolo específico para desencravamento sem risco de infecção — com atenção redobrada à cicatrização.

🦶

### Calos e hiperqueratoses

Remoção especializada de calosidades com identificação e alívio dos pontos de pressão.

✨

### Podoprofilaxia preventiva

Manutenção periódica dos pés para previnir e/ou identificar e tratar problemas antes que virem complicações.

📋

### Orientação e educação em saúde

Ensino de autocuidado: como inspecionar os pés, higiene correta, calçados adequados e quando buscar ajuda.

Como funciona

## Acompanhamento do  
Pé Diabético na Clínica

1

1ª Consulta · R$ 150,00

### Semiologia completa do pé diabético

Avaliação neurológica (sensibilidade, reflexos), vascular (pulsos, temperatura), biomecânica (deformidades, pontos de pressão) e dermatológica (feridas, calos, micoses, unhas). Classificação do risco e definição do protocolo de acompanhamento ideal para o seu caso.

2

Tratamento

### Tudo identificado pode ser tratado na mesma visita

Unhas encravadas, calos, feridas e micoses recebem tratamento imediato com protocolo específico para diabéticos — técnica adaptada, maior cautela na cicatrização e uso de laser DMC quando indicado. Nenhum procedimento é feito sem considerar o quadro sistêmico do paciente.

3

Educação em saúde

### Você aprende a inspecionar os seus pés

Liana ensina o autocuidado correto: como examinar os pés diariamente, o que observar, higiene adequada, como cortar as unhas com segurança, quais calçados usar e em que situações buscar atendimento imediato.

4

Acompanhamento mensal

### Todo diabético merece — e precisa de — um olhar profissional todo mês

Independentemente do grau de risco, recomendamos acompanhamento mensal para todos os nossos pacientes diabéticos. O pé diabético muda mais rápido do que parece: uma calosidade que não existia no mês passado pode estar gerando pressão perigosa agora. A visita mensal é o que permite agir antes — não depois.

Consulta inicial

R$ 150,00

O valor de uma consulta. O peso de uma decisão que protege seus pés para o resto da vida.

-   Semiologia completa do pé diabético
-   Classificação de risco (0 a 3)
-   Tratamento das condições identificadas
-   Plano de acompanhamento personalizado
-   Orientações de autocuidado detalhadas

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.)

### Por que recomendamos acompanhamento mensal para todos?

📅

#### Mudanças acontecem em semanas

Calos, pressões, fissuras e alterações de sensibilidade surgem rapidamente — o intervalo mensal garante que nada passe despercebido

🔬

#### Risco baixo hoje não é risco baixo para sempre

A neuropatia e a doença vascular progressam — o acompanhamento mensal detecta essa evolução e ajusta o protocolo antes que o quadro piore

🛡️

#### Prevenção custa menos do que tratamento

Uma consulta mensal de manutenção evita procedimentos mais complexos — e protege a qualidade de vida a longo prazo

💬

#### Você tem quem perguntar todo mês

Qualquer mudança nos pés que acontecer no intervalo — dúvida, sintoma novo, calçado diferente — tem resposta profissional garantida na próxima visita

**Formas de pagamento:** Pix, débito e crédito em até 10 vezes (sujeito à taxa da operadora). A clínica trabalha somente como particular. Nosso foco é oferecer a melhor qualidade de atendimento, equipamentos e protocolo — sem limitações impostas por convênios.

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20720%20980'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

A especialista responsável

## Formação Específica em  
Diabetes e Pé Diabético

Liana Gonçalves acumulou três pós-graduações diretamente relacionadas ao paciente diabético: Diabetes e Complicações Crônicas, Enfermagem em Dermatologia e Tratamento de Feridas, e Geriatria e Gerontologia — perfil de paciente que concentra os casos mais graves de pé diabético. Além disso, tem especialização em Semiologia do Pé Diabético, que é a avaliação diagnóstica completa que orienta todo o protocolo de cuidados.

Isso significa que ela não trata o pé como um problema isolado. Cada decisão considera o quadro completo do paciente: nível de controle glicêmico, tempo de doença, uso de medicamentos, risco vascular. É o que diferencia o atendimento clínico especializado do cuidado genérico.

### 🎓 Formação específica para pacientes diabéticos

Pós-graduação em Diabetes e Complicações Crônicas · Especialização em Semiologia do Pé Diabético · Participação no CIAP Internacional 2023, 2024 e 2025 — congresso com forte foco em pé diabético e feridas complexas.

✓ Graduação em PodologiaUnicesumar · Nível Superior

✓ Pós-Grad. Dermatologiae Tratamento de Feridas

✓ Laser DMC TherapyiLib e XT — cicatrização avançada

✓ Pós-Grad. Geriatriae Gerontologia

🩺

**Indicada por médicos endocrinologistas e clínicos gerais de Campo Grande** para o acompanhamento especializado dos pés de seus pacientes diabéticos.

Quem já foi atendido

## O Que Nossos Pacientes  
Dizem Sobre o Atendimento

★★★★★ 4.9 · 207 avaliações no Google

★★★★★

"Excelente atendimento, a atenção e o carinho começa na recepção, sou grata por ter a oportunidade de conhecê-las."

T

Telma Miria Pereira Da Silva

Verificado no Google · Out - 2023

★★★★★

"Equipe extremamente cuidadosa, profissionais ótimos, fazem questão de falar cada detalhe do procedimento e te deixar segura"

L

Laura Paniago

Verificado no Google · Jan - 2025

★★★★★

"Alto profissionalismo no atendimento, passando confiança ao cliente, muito cuidado com cada detalhe da sessão. Recepção agradável ."

L

Lucidio Naveira

Verificado no Google · Dez - 2023

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

Dúvidas frequentes

## Perguntas sobre  
Pé do Diabético

Todo diabético precisa de acompanhamento com podóloga? +

Sim — e a frequência ideal é mensal, independentemente do tempo de diagnóstico ou do controle glicêmico. O pé diabético é dinâmico: calosidades surgem, a sensibilidade muda, pontos de pressão aparecem sem aviso. **O acompanhamento mensal é o que garante que qualquer alteração seja identificada e tratada antes de se tornar um problema sério.** Não existe "diabético controlado demais para precisar de acompanhamento" — existe diabético protegido e diabético exposto ao risco.

Tenho uma ferida no pé que não está cicatrizando. É urgente? +

**Sim. Não espere.** Feridas que não cicatrizam em diabéticos são sinal de comprometimento vascular — e podem evoluir para úlceras profundas e infecções graves em questão de dias. Quanto mais cedo for avaliada e tratada, menor o risco de complicações sérias. Entre em contato pelo WhatsApp agora mesmo.

Posso cortar as unhas dos pés em casa sendo diabético? +

Com cuidado e técnica correta, sim — mas há regras importantes. As unhas devem ser cortadas reto, nunca em curva, e nunca muito rente. Nunca use tesoura de ponta fina. Boa iluminação é essencial — muitos diabéticos com neuropatia não percebem quando se machucam. **Liana ensina a técnica correta na consulta.** Para quem tem dificuldade de visão ou mobilidade, a podoprofilaxia periódica é a opção mais segura.

Que tipo de calçado o diabético deve usar? +

Calçados fechados, com bico arredondado e espaço suficiente para os dedos, solado antiderrapante e interior sem costuras salientes. **Nunca andar descalço** — nem em casa. Evitar sandálias abertas que exponham os dedos. Para quem tem deformidades, calçados ortopédicos ou palmilhas personalizadas podem ser indicados. Cada caso é avaliado individualmente na consulta.

A podóloga pode trabalhar em conjunto com meu endocrinologista? +

Sim — e é o modelo ideal de cuidado. Liana trabalha de forma integrada com a equipe médica do paciente, podendo emitir relatórios e encaminhar comunicações ao médico responsável quando necessário. Vários endocrinologistas e clínicos gerais de Campo Grande já indicam a clínica especificamente para esse acompanhamento integrado.

É possível prevenir a amputação com acompanhamento regular? +

**Sim — e essa é exatamente a função do acompanhamento especializado.** Estudos mostram que programas de cuidado preventivo do pé diabético reduzem em até 85% o risco de amputação. A grande maioria das amputações começa com uma pequena lesão ignorada que evolui por falta de tratamento adequado. Identificar e tratar precocemente é o que faz toda a diferença.

🩺 Uma consulta. Um plano. Seus dois pés.

## Você não precisa esperar  
aparecer uma ferida para agir.

Quem tem diabetes sabe que o risco é real. O que muitos ainda não sabem é que com acompanhamento especializado ele é amplamente controlável. Agende agora — saia da consulta sabendo exatamente qual é o seu grau de risco e o que fazer a partir de hoje.

🚨 Ferida no pé que não fecha? Entre em contato hoje — não amanhã.

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.) [📞 (67) 3305-0219](tel:6733050219)

Seg–Sex · 8h às 12h e 13h às 17h  
Rua Doutor Arthur Jorge, 2523 · Campo Grande-MS

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD

---

## [Página 8] Podopediatria (Podologia kids) - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/podologia-infantil-podopediatria-especialista-em-criancas
- **Profundidade:** 2
- **Descrição:** Especialista no atendimento a crianças. Qualidade tem nome, quem ama seu filho só aceita clínica de podologia Liana Gonçalves!
- **Palavras:** 1707 | **Imagens:** 18 | **Links:** 26

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #1 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #2 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #3 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #4 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #5 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #6 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #7 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #8 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #9 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-768x768.png" class="attachment-medium_large size-me"
> *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades • Seção: Conteúdo da Página • Sob: H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
![Imagem extraída](images/img_046_Design-sem-768x768.png)

> **[Imagem 11]** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-768x768.png" class="attachment-medium_large size-me"
> *Posição:* Posição #11 na página • Seção: Conteúdo da Página • Sob H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades • Seção: Conteúdo da Página • Sob: H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
![Imagem extraída](images/img_047_Design-sem-300x300.png)

> **[Imagem 12]** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-768x768.png" class="attachment-medium_large size-me"
> *Posição:* Posição #12 na página • Seção: Conteúdo da Página • Sob H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades • Seção: Conteúdo da Página • Sob: H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
![Imagem extraída](images/img_048_Design-sem-1024x1024.png)

> **[Imagem 13]** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-768x768.png" class="attachment-medium_large size-me"
> *Posição:* Posição #13 na página • Seção: Conteúdo da Página • Sob H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades • Seção: Conteúdo da Página • Sob: H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
![Imagem extraída](images/img_049_Design-sem-150x150.png)

> **[Imagem 14]** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-768x768.png" class="attachment-medium_large size-me"
> *Posição:* Posição #14 na página • Seção: Conteúdo da Página • Sob H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades • Seção: Conteúdo da Página • Sob: H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
![Imagem extraída](images/img_050_Design-sem.png)

> **[Imagem 15]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
> *Posição:* Posição #15 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 16]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #16 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 17]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #17 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 18]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #18 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20meu%20filho%20na%20podopediatria.)

👶 Podologia Especializada para Crianças e Bebês

# Seu filho está com dor  
ou problema nos pés?  
Existe tratamento seguro  
desde o nascimento.

Unhas encravadas em bebês, verrugas, fungos, alterações da marcha — tratamos tudo com técnica especializada, sem anestesia injetável e com os pais presentes durante todo o atendimento.

✅

**Não é preciso esperar a criança crescer para tratar.** Quanto mais cedo o problema é identificado e corrigido, mais simples é o tratamento — e menor o impacto no desenvolvimento dos pés.

[📲 Agendar Consulta Infantil](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20meu%20filho%20na%20podopediatria.) [O que tratamos ↓](#pp-tratamentos)

Do RN Atendemos desde  
recém-nascidos

Sem agulha Anestesia tópica  
e laser

15 anos de experiência  
especializada

4.9 ★ 207 avaliações  
no Google

🦶 Atenção especializada

## Por que o Pé Infantil Precisa de  
Cuidado Especializado

O pé da criança está em desenvolvimento constante — ossos, ligamentos e tendões ainda em formação respondem de forma completamente diferente do adulto. Um problema ignorado hoje pode virar uma alteração permanente na marcha, na postura ou na estrutura do pé adulto.

🦴

### Ossos ainda em formação

Até os 18 anos os ossos do pé ainda se consolidam. Pressões incorretas, calçados inadequados ou alterações não tratadas nessa fase moldam o pé definitivo do adulto.

😶

### A criança não sabe descrever a dor

Bebês choram. Crianças pequenas param de andar, ficam irritadas ou evitam certas atividades. Os sinais estão lá — precisam de um olhar especializado para serem interpretados.

⚡

### Tratamento mais simples quanto antes iniciar

Uma unha encravada em bebê resolve em menos de 1 minuto. Uma verruga tratada cedo é eliminada antes de se multiplicar. A precocidade define a complexidade do tratamento.

👟

**Calçado correto é parte do tratamento.** Em cada consulta pediátrica, a podóloga avalia o calçado que a criança usa e orienta sobre o tipo ideal para cada fase do desenvolvimento — da marcha inicial ao calçado escolar.

O que tratamos

## Condições Tratadas na  
Podopediatria

🩹

### Unha Encravada

Inclusive em recém-nascidos. Tratamento rápido com anestesia tópica — os pais ficam ao lado durante todo o procedimento.

🦠

### Fungos nas Unhas

Diagnóstico laboratorial para identificar o fungo exato e definir o protocolo correto para a idade da criança.

🎯

### Verruga Plantar

Muito comum em crianças. Tratada com laser DMC antes que se multiplique — sem cortes e sem cicatrizes.

🦶

### Calos e Calosidades

Remoção especializada com identificação do ponto de pressão causador — especialmente importante em crianças com alterações de marcha.

🚶

### Alterações da Marcha

Pé chato, pé cavo, marcha na ponta dos pés — avaliação postural e orientação para correção precoce.

🐛

### Bicho de Pé e Micoses

Tunguíase e micoses de pele são comuns em crianças. Tratamento específico e seguro para cada faixa etária.

⚠️

**Seu bebê chora muito, tem vermelhidão no dedo do pé ou febre sem causa aparente?** Pode ser unha encravada — é mais comum em recém-nascidos do que se imagina. Leve ao podólogo antes de tentar resolver em casa.

Como funciona

## Atendimento Infantil:  
Seguro, Rápido e Sem Trauma

1

Consulta · R$ 150,00

### Avaliação clínica completa

A podóloga examina os pés da criança com atenção à faixa etária — unhas, pele, marcha, postura e calçados. Identifica a condição, explica tudo para os pais com clareza e define o protocolo adequado para a idade. **Se o tratamento iniciar no mesmo dia, a consulta é isenta.**

2

Preparação

### Analgesia com laser e anestésico tópico

Nenhum procedimento é feito sem analgesia adequada. Usamos laser DMC e anestésico tópico — **sem agulha, sem anestesia injetável**. Isso é possível porque somos éticos: atuamos apenas dentro do que a regulamentação da podologia permite, e dentro disso entregamos o máximo de conforto para a criança.

3

Procedimento

### Tratamento rápido — os pais ficam ao lado

Em cerca de 95% dos casos o procedimento dura menos de 1 minuto. Os pais acompanham tudo presencialmente — isso reduz a ansiedade da criança e dá segurança à família. Para bebês, o procedimento é feito com a criança no colo do responsável quando possível.

4

Orientações

### Guia completo para os pais

A podóloga orienta como cuidar em casa, como cortar as unhas corretamente, quais calçados usar em cada fase e quando retornar. O acompanhamento não termina na saída da clínica — continuamos disponíveis pelo WhatsApp para dúvidas.

Consulta inicial

R$ 150,00

Isenta se o tratamento iniciar no mesmo dia

-   Avaliação clínica completa adaptada à idade
-   Diagnóstico e plano de tratamento
-   Orientações detalhadas para os pais
-   Avaliação do calçado e da marcha

Procedimentos mais comuns

Unha encravada A partir de R$ 300,00

Verruga plantar Após avaliação

Fungos (consulta completa) R$ 370,00

Calos e calosidades A partir de R$ 150,00

Valor exato definido na consulta conforme grau e complexidade do caso.

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20de%20podopediatria%20para%20meu%20filho.)

### O que garantimos aos pais

👁️

#### Você acompanha tudo

Os pais ficam presentes durante toda a consulta e o procedimento — sem exceção

💉

#### Sem agulha

Anestesia apenas tópica e laser — nenhuma anestesia injetável no pé da criança

⚡

#### Procedimento rápido

Menos de 1 minuto na grande maioria dos casos — respeitando o tempo de atenção e a tolerância de cada criança

📋

#### Explicação total

Tudo é explicado antes de começar — diagnóstico, procedimento, cuidados e expectativa

**Formas de pagamento:** Pix, débito e crédito em até 10 vezes (taxa operadora). Clínica particular — não atendemos convênios.

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20768%20768'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

Quem vai atender seu filho

## Especialista com 15 Anos  
Cuidando de Pés de Todas as Idades

Liana Gonçalves atende crianças desde bebês recém-nascidos com o mesmo cuidado técnico que aplica em adultos — adaptando cada abordagem à faixa etária, ao nível de compreensão e à tolerância de cada paciente. **A podopediatria exige paciência, técnica e sensibilidade que só vêm com experiência real.**

Participante anual do CIAP — maior congresso internacional de podologia, com programação dedicada à podopediatria — e formadora de outros profissionais no Mato Grosso do Sul, Liana traz para cada atendimento infantil o que há de mais atual em técnica pediátrica. Sua formação abrangente em diversas áreas clínicas garante que cada criança seja avaliada no contexto completo da sua saúde — não apenas o sintoma isolado.

✓ Graduação em PodologiaUnicesumar · Nível Superior

✓ Laser DMC TherapyiLib e XT — analgesia infantil

✓ CIAP Internacional2023 · 2024 · 2025

✓ Pós-grad. Dermatologiae Tratamento de Feridas

✓ Tutora de cursos técnicosde Podologia pelo Senac MS

✓ 50+ especializaçõese cursos livres

🩺

**Indicada por pediatras e médicos de Campo Grande** para o acompanhamento podológico de crianças — especialmente em casos de alterações de marcha e unhas encravadas de repetição.

Dúvidas frequentes

## Perguntas sobre  
Podopediatria

Atende bebês recém-nascidos? +

Sim — inclusive recém-nascidos de dias. Casos de unha encravada em bebês são mais comuns do que a maioria imagina, e os sinais são choro excessivo sem causa aparente, vermelhidão e febre. **Quanto mais cedo for tratado, mais simples e rápido é o procedimento.**

O procedimento vai machucar meu filho? +

Essa é a preocupação de todos os pais — e ela é completamente compreensível. Usamos anestésico tópico e laser DMC antes de qualquer procedimento para minimizar ao máximo o desconforto. **Sem agulha, sem anestesia injetável.** Em crianças muito pequenas, quando possível, o procedimento é feito com a criança no colo do responsável. A grande maioria dos pais nos diz que a criança ficou muito mais tranquila do que esperavam.

Posso ficar junto durante o atendimento? +

Sim — e incentivamos isso. Os pais ficam presentes durante toda a consulta e o procedimento, sem exceção. A presença do responsável reduz significativamente a ansiedade da criança e facilita o atendimento. Também aproveitamos para orientar os pais diretamente sobre como cuidar em casa.

A partir de que idade posso levar meu filho? +

Desde o nascimento. Não há idade mínima para a podopediatria — atendemos recém-nascidos, bebês, crianças e adolescentes. Cada faixa etária tem uma abordagem específica adaptada ao desenvolvimento dos pés naquela fase.

Meu filho tem fungo na unha. Tem tratamento para crianças? +

Sim. Fazemos diagnóstico com exame micológico laboratorial para identificar o fungo exato — o mesmo rigor do adulto. O protocolo de tratamento é adaptado à faixa etária, com medicação e técnicas seguras para crianças. **Não use produtos adultos nos pés de criança sem orientação especializada.**

Como saber se meu filho tem problema nos pés? +

Fique atento a: choro ao calçar sapato, recusa de andar, pé avermelhado ou inchado, marcha diferente do esperado, tropeços frequentes, queixa de dor ao caminhar ou correr. Em bebês, choro sem causa aparente associado a vermelhidão no dedo do pé é sinal de alarme. **Em caso de dúvida, traga para avaliação — uma consulta preventiva vale mais do que esperar o problema agravar.**

O que os pais dizem

## Famílias que confiam  
os pés dos filhos à Liana

★★★★★ 4.9 · 207 avaliações no Google

★★★★★

"Acolhedor, ótimo atendimento, passa segurança e confiança. Obrigada!"

L

Luzia Petricio

Verificado no Google

★★★★★

"Atendimento excelente, desde a recepcionista até o procedimento realizado pela doutora Liana. Indico o consultório com certeza!"

A

Avaliação Google

Verificado no Google

★★★★★

"Gostei muito, trabalho sensacional, atenciosos e explicam bem o tratamento para os pés, muito bom mesmo!"

J

Avaliação Google

Verificado no Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

Também atendemos

## Outros Tratamentos para Crianças e a Família

Muitas famílias que chegam pela criança descobrem que outros membros também precisam de cuidado. Aqui na Clínica a família inteira encontra o que precisa.

[🦠

### Fungos nas Unhas

Diagnóstico laboratorial e protocolo especializado. Tratamento disponível para todas as idades.

Saiba mais →](/fungos-micose-onicomicose/) [🩹

### Unha Encravada

Tratamento rápido com alívio imediato. Atendemos adultos, bebês e casos com infecção.

Saiba mais →](/unha-encravada/) [🩺

### Pé do Diabético

Para os pais ou avós diabéticos. Acompanhamento mensal especializado e preventivo.

Saiba mais →](/pe-do-diabetico/) [✨

### Podoprofilaxia

Manutenção preventiva para toda a família — crianças, adultos e idosos.

Saiba mais →](/podoprofilaxia/)

👶 Cuidado que começa cedo

## Seu filho não precisa  
conviver com dor nos pés.

Traga ele para ser examinado — identificamos o problema na primeira consulta e, na maioria dos casos, já iniciamos o tratamento no mesmo dia. Sem agulha, sem trauma, com os pais ao lado.

[📲 Agendar Consulta Infantil](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20de%20podopediatria%20para%20meu%20filho.) [📞 (67) 3305-0219](tel:6733050219)

Seg–Sex · 8h às 12h e 13h às 17h  
Rua Doutor Arthur Jorge, 2523 · Campo Grande-MS

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD

---

## [Página 9] Podogeriatria - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/podogeriatria
- **Profundidade:** 2
- **Descrição:** Ligue agora! Agendar Consulta 👴 Cuidado especializado para a melhor idade Pés que carregaram uma vida inteira merecem cuidado especializado. Na terceira idade, os pés mudam — pele mais fina, unhas mais espessas, circulação reduzida e maior risco de complicações. A podogeriatria é o cuidado clínico adaptado para essas necessidades específicas. ✅ Não é só […]
- **Palavras:** 1891 | **Imagens:** 17 | **Links:** 25

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #1 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #2 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #3 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #4 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #5 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #6 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #7 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #8 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #9 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n-768x768.jpg" c"
> *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Formação específica em Geriatria e Gerontologia • Seção: Conteúdo da Página • Sob: H2: Formação específica em Geriatria e Gerontologia
![Imagem extraída](images/img_051_282207662_441098077826309_4659220234443228409_n-768x768.jpg)

> **[Imagem 11]** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n-768x768.jpg" c"
> *Posição:* Posição #11 na página • Seção: Conteúdo da Página • Sob H2: Formação específica em Geriatria e Gerontologia • Seção: Conteúdo da Página • Sob: H2: Formação específica em Geriatria e Gerontologia
![Imagem extraída](images/img_052_282207662_441098077826309_4659220234443228409_n-300x300.jpg)

> **[Imagem 12]** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n-768x768.jpg" c"
> *Posição:* Posição #12 na página • Seção: Conteúdo da Página • Sob H2: Formação específica em Geriatria e Gerontologia • Seção: Conteúdo da Página • Sob: H2: Formação específica em Geriatria e Gerontologia
![Imagem extraída](images/img_053_282207662_441098077826309_4659220234443228409_n-150x150.jpg)

> **[Imagem 13]** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n-768x768.jpg" c"
> *Posição:* Posição #13 na página • Seção: Conteúdo da Página • Sob H2: Formação específica em Geriatria e Gerontologia • Seção: Conteúdo da Página • Sob: H2: Formação específica em Geriatria e Gerontologia
![Imagem extraída](images/img_054_282207662_441098077826309_4659220234443228409_n.jpg)

> **[Imagem 14]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
> *Posição:* Posição #14 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 15]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #15 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 16]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #16 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 17]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #17 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20de%20podogeriatria.)

👴 Cuidado especializado para a melhor idade

# Pés que carregaram  
uma vida inteira  
merecem cuidado especializado.

Na terceira idade, os pés mudam — pele mais fina, unhas mais espessas, circulação reduzida e maior risco de complicações. A podogeriatria é o cuidado clínico adaptado para essas necessidades específicas.

✅

**Não é só limpeza.** O atendimento geriátrico envolve avaliação de circulação, sensibilidade, risco de queda, adequação do calçado e identificação precoce de condições que, sem tratamento, podem comprometer seriamente a mobilidade e a qualidade de vida.

[📲 Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20de%20podogeriatria.) [O que avaliamos ↓](#pg-cuidados)

Pós-grad. Geriatria e  
Gerontologia

Consulta R$ 150,00 isenta se  
contratar algum tratamento no mesmo dia

15 anos de experiência  
especializada

4.9 ★ 207 avaliações  
no Google

Entenda o problema

## O pé idoso é clinicamente diferente —  
e precisa de abordagem diferente

Com o envelhecimento, o pé passa por mudanças fisiológicas profundas que alteram sua resposta ao cuidado. O que funciona num adulto jovem pode ser inadequado ou até perigoso em um idoso. Reconhecer essas diferenças é o que define a qualidade do atendimento geriátrico.

🩸🫀❄️🦶

### Circulação reduzida

O fluxo sanguíneo para os membros inferiores diminui progressivamente. Cicatrização mais lenta, maior risco de infecção e menor tolerância a procedimentos mais invasivos.

🧓🧬🩹⚠️

### Pele mais fina e frágil

A perda de elasticidade e hidratação natural torna a pele suscetível a fissuras, bolhas e lesões que num adulto jovem seriam triviais — e num idoso podem complicar rapidamente.

😬💅🩹⚠️

### Unhas mais espessas e quebradiças

O crescimento das unhas diminui e a placa fica mais espessa, densa e difícil de cortar. Corte incorreto causa dor, encravamento e lesões na pele ao redor.

🩺🦶️🫥⚡

### Sensibilidade reduzida

Neuropatia periférica — mesmo sem diabetes — é comum na terceira idade. O pé deixa de avisar quando está sendo machucado, permitindo que feridas evoluam sem dor.

🦶😣⚠️🩺

### Deformidades acumuladas

Décadas de uso incorreto de calçados, alterações posturais e doenças como artrite resultam em deformidades que redistribuem pressão e criam pontos de atrito crônicos.

🧓🦵⬇️🏥

### Risco de queda aumentado

Dor nos pés, calosidades espessas e calçado inadequado comprometem o equilíbrio e a segurança da marcha — um dos principais fatores de risco de quedas em idosos.

⚠️

### Por que problemas nos pés são mais sérios na terceira idade

Uma calosidade espessa num idoso pode esconder uma úlcera se formando por baixo. Uma unha espessada mal cortada pode causar lesão que não cicatriza por semanas. Um fungo não tratado pode disseminar para a pele. **Na terceira idade, problemas nos pés não são pequenos — merecem atenção clínica regular, não esporádica.**

Condições frequentes

## O que tratamos na podogeriatria

Todas as condições podológicas podem afetar idosos — mas algumas são especialmente prevalentes e exigem protocolo adaptado à faixa etária.

✂️

#### Unhas espessadas e de difícil corte

A principal queixa da podogeriatria. Unhas que a pessoa não consegue mais cortar sozinha com segurança — especialmente após os 70 anos. O corte incorreto em casa é a principal causa de lesões em idosos.

🦠

#### Fungos nas unhas (onicomicose)

Prevalência muito alta em idosos — a circulação reduzida favorece a instalação e progressão do fungo. Diagnóstico laboratorial e protocolo adaptado à faixa etária e ao uso de medicamentos.

🦶

#### Calosidades e fissuras no calcanhar

A pele ressecada da terceira idade forma calosidades com mais facilidade e fissuras profundas no calcanhar — que podem sangrar e infectar. Tratamento e hidratação clínica fazem diferença real.

🩹

#### Unha encravada

Comum em idosos que cortam as próprias unhas com dificuldade de visão ou mobilidade reduzida. O protocolo de tratamento considera a fragilidade vascular e cicatricial da faixa etária.

🔴

#### Heloma mole entre os dedos

Calo úmido entre os dedos que pode se tornar porta de entrada para infecção bacteriana. Em idosos, a progressão é mais rápida e o tratamento precisa ser mais cuidadoso.

🩺

#### Pé do diabético idoso

A combinação de diabetes e envelhecimento é o cenário de maior risco em toda a podologia. Acompanhamento mensal obrigatório com protocolo específico — prevenção de úlceras e amputações.

**A frequência ideal para idosos é mensal** — mesmo sem sintomas aparentes. A avaliação regular é o que evita que pequenos problemas se tornem grandes complicações.

[📲 Agendar avaliação](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20de%20podogeriatria.)

Como funciona

## Atendimento Adaptado:  
Técnica e Cuidado para a Terceira Idade

1

Avaliação clínica

### Avaliação geriátrica completa dos pés

A podóloga avalia circulação, sensibilidade, integridade da pele, estado das unhas, deformidades e pontos de pressão. **Para idosos diabéticos, a avaliação de risco é parte central da consulta** — classificação de risco, orientações e plano de acompanhamento são definidos aqui.

2

Procedimento adaptado

### Técnica específica para pele e unhas geriátricas

Instrumental específico para unhas espessas, técnica de corte adaptada à mobilidade e visão do paciente, pressão e velocidade ajustadas para pele mais fina. **Nenhum procedimento é feito sem o cuidado que a fragilidade da faixa etária exige.**

3

Hidratação e laser

### Cuidado completo da pele + laser quando indicado

Hidratação clínica profissional para pele ressecada e fissuras. Laser DMC para cicatrização acelerada de áreas com lesão, inflamação ou infecção fúngica. O laser é especialmente útil em idosos pela sua capacidade de estimular tecidos com circulação comprometida.

4

Orientações completas

### Orientações para família e cuidadores

Quando o idoso tem cuidador ou familiar presente, a podóloga orienta sobre como monitorar os pés em casa, sinais de alerta, como hidratar corretamente, qual calçado usar e quando retornar. **A família é parte do protocolo de cuidado.**

Investimento

Consulta R$ 150,00

Quando necessário tratamento a consulta é isenta se o tratamento for iniciado no mesmo dia · valor conforme condições identificadas

-   Avaliação clínica geriátrica completa
-   Corte e cuidado das unhas com técnica adaptada
-   Remoção de calosidades e tratamento de fissuras
-   Hidratação clínica profissional
-   Laser DMC quando indicado
-   Orientações para família e cuidadores

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20de%20podogeriatria.)

### Frequência recomendada

👴

#### Idoso saudável

A cada 30 dias — unhas crescem mais devagar mas ficam mais espessas; pele precisa de hidratação regular

🩺

#### Idoso diabético

Mensalmente — obrigatório. Combinação de diabetes e envelhecimento é o maior fator de risco em podologia

🦽

#### Mobilidade reduzida

Conforme necessidade — idosos acamados ou com dificuldade de locomoção podem precisar de atenção mais frequente

💊

#### Uso de anticoagulantes

Protocolo específico — medicamentos como warfarina e AAS exigem atenção redobrada durante qualquer procedimento

**Formas de pagamento:** Pix, débito e crédito em até 10 vezes (taxa operadora). Clínica particular — não atendemos convênios.

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20768%20768'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

Especialista responsável

## Formação específica em  
Geriatria e Gerontologia

Liana Gonçalves é pós-graduada em Geriatria e Gerontologia — formação específica para entender as mudanças fisiológicas do envelhecimento e adaptar cada protocolo clínico às necessidades reais do paciente idoso. **Não é o mesmo tratamento de um adulto jovem feito com mais cuidado — é um protocolo genuinamente diferente.**

Combinada com sua pós-graduação em Diabetes e Complicações Crônicas, Liana está entre as podólogas mais bem preparadas de Campo Grande para o atendimento geriátrico — especialmente para o perfil mais crítico: o idoso diabético.

### 👴 Idoso diabético — o perfil de maior risco

A combinação de envelhecimento, diabetes e neuropatia periférica cria o cenário de maior risco em toda a podologia. Liana tem pós-graduação em ambas as áreas e protocolo específico para esse perfil — com avaliação de risco estruturada, acompanhamento mensal e orientação para a família.

✓ Graduação em PodologiaUnicesumar · Nível Superior

✓ Pós-grad. Geriatriae Gerontologia

✓ Pós-grad. Diabetese Complicações Crônicas

✓ Laser DMC TherapyiLib e XT

✓ CIAP Internacional2023 · 2024 · 2025

✓ 15 anos de experiênciaem podologia clínica

🩺

**Indicada por médicos geriátras e clínicos gerais de Campo Grande** para acompanhamento podológico de idosos — especialmente casos com diabetes, neuropatia ou histórico de úlceras.

Dúvidas frequentes

## Perguntas sobre  
Podogeriatria

A partir de que idade é considerado atendimento geriátrico? +

Geralmente a partir dos 60 anos — que é a definição legal de idoso no Brasil. Mas o que define a necessidade de protocolo geriátrico não é só a idade: é a presença de condições associadas ao envelhecimento como circulação reduzida, neuropatia, pele frágil, dificuldade de mobilidade ou uso de múltiplos medicamentos. **Se o paciente tem essas características, o protocolo é adaptado independentemente da idade.**

Meu pai/mãe tem dificuldade de locomoção. Pode ser atendido assim mesmo? +

Sim. A clínica está preparada para receber pacientes com mobilidade reduzida. Acompanhantes e cuidadores são bem-vindos e fazem parte do atendimento — orientamos a família sobre como monitorar os pés em casa. Se tiver alguma necessidade especial de acessibilidade, entre em contato pelo WhatsApp antes de vir para nos prepararmos adequadamente e disponibilizarmos o estacionamento no interior do prédio para maior comodidade do paciente.

Com que frequência o idoso deve fazer podogeriatria? +

Para idosos saudáveis, a cada 30 dias. Para idosos diabéticos, mensalmente — sem exceção. Quanto mais fatores de risco presentes (diabetes, neuropatia, anticoagulantes, mobilidade reduzida), mais importante é a regularidade do acompanhamento. **O atendimento mensal é o que permite identificar problemas antes que se tornem complicações sérias.**

Meu pai usa anticoagulante (warfarina, AAS). Pode fazer o procedimento? +

Sim, com protocolo adaptado. O uso de anticoagulantes exige técnica mais cuidadosa e atenção ao risco de sangramento durante qualquer procedimento. **Informe o uso de medicamentos no agendamento** para que a podóloga se prepare adequadamente. Nunca suspenda medicamentos antes da consulta sem orientação do médico responsável.

O idoso pode fazer o tratamento de fungo nas unhas? +

Sim — e é especialmente importante tratar, pois fungos em idosos tendem a progredir mais rapidamente pela circulação reduzida. O protocolo considera a faixa etária, os medicamentos em uso e o estado geral da pele e da unha. O laser DMC é especialmente indicado para idosos por não exigir medicação sistêmica.

Posso ir como filho/a em nome do meu pai ou mãe para agendar? +

Sim. Filhos e cuidadores podem agendar pelo WhatsApp informando que é para um familiar idoso. Se possível, mencione as principais condições de saúde (diabetes, uso de anticoagulantes, mobilidade reduzida) para que possamos reservar o tempo adequado e nos preparar para o atendimento.

Quem já foi atendido

## O que nossos pacientes  
dizem sobre o atendimento

★★★★★ 4.9 · 207 avaliações no Google

★★★★★

"Acolhedor, ótimo atendimento, passa segurança e confiança. Obrigada!"

L

Luzia Petricio

Verificado no Google

★★★★★

"Atendimento excelente, desde a recepcionista até o procedimento realizado pela doutora Liana. Indico o consultório com certeza!"

A

Avaliação Google

Verificado no Google

★★★★★

"Gostei muito, trabalho sensacional, atenciosos e explicam bem o tratamento para os pés, muito bom mesmo!"

J

Avaliação Google

Verificado no Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

Também atendemos

## Outros Tratamentos na Clínica

Todos os tratamentos com o mesmo cuidado clínico — adaptado para cada faixa etária.

[🦠

### Fungos nas Unhas

Diagnóstico laboratorial e protocolo especializado para todas as idades.

Saiba mais →](/fungos-micose-onicomicose/) [🩺

### Pé do Diabético

Acompanhamento mensal especializado. Prevenção de úlceras e amputações.

Saiba mais →](/pe-do-diabetico/) [🦶

### Calos e Calosidades

Remoção completa com protocolo específico para pele geriátrica.

Saiba mais →](/calos-e-calosidades/) [✨

### Podoprofilaxia

Manutenção clínica mensal — a base do cuidado preventivo na terceira idade.

Saiba mais →](/podoprofilaxia/)

👴 Cuidado que respeita a idade

## Seus pés merecem cuidado  
na medida certa para esta fase.

Agende a consulta — na primeira avaliação identificamos todas as condições presentes, definimos o protocolo adequado e orientamos a família sobre como monitorar em casa.

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20de%20podogeriatria.) [📞 (67) 3305-0219](tel:6733050219)

Seg–Sex · 8h às 12h e 13h às 17h  
Rua Doutor Arthur Jorge, 2523 · Campo Grande-MS

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD

---

## [Página 10] Calos e calosidades - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/calos-e-calosidades
- **Profundidade:** 2
- **Descrição:** Ligue agora! Agendar Consulta 🦶 Remoção especializada e alívio definitivo Dor ao caminhar, pele grossa no calcanhar? Não é frescura —é calo e tem solução. Calos, calosidades e calos com núcleo causam dor real a cada passo. Com avaliação clínica especializada, removemos a causa — não só a pele — para que o problema não […]
- **Palavras:** 1806 | **Imagens:** 15 | **Links:** 25

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #1 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #2 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #3 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #4 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #5 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #6 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #7 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #8 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #9 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-remove"
> *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Tratamento que Identificaa Causa — Não Só o Sintoma • Seção: Conteúdo da Página • Sob: H2: Tratamento que Identificaa Causa — Não Só o Sintoma
![Imagem extraída](images/img_012_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png)

> **[Imagem 11]** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-remove"
> *Posição:* Posição #11 na página • Seção: Conteúdo da Página • Sob H2: Tratamento que Identificaa Causa — Não Só o Sintoma • Seção: Conteúdo da Página • Sob: H2: Tratamento que Identificaa Causa — Não Só o Sintoma
![Imagem extraída](images/img_013_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png)

> **[Imagem 12]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
> *Posição:* Posição #12 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 13]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #13 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 14]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #14 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 15]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #15 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20calos%20e%20calosidades.)

🦶 Remoção especializada e alívio definitivo

# Dor ao caminhar,  
pele grossa no calcanhar?  
Não é frescura —  
é calo e tem solução.

Calos, calosidades e calos com núcleo causam dor real a cada passo. Com avaliação clínica especializada, removemos a causa — não só a pele — para que o problema não volte.

⚠️

**Lixar em casa só remove a superfície.** A causa do calo — o ponto de pressão — continua ativa. Em dias ou semanas ele volta, geralmente mais espesso. Em diabéticos, qualquer manipulação sem supervisão é de alto risco.

[📲 Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20calos%20e%20calosidades.) [Como funciona ↓](#cc-tratamento)

Consulta R$ 150,00 isenta  
se tratar no mesmo dia

Causa identificada e  
tratada

15 anos de experiência  
especializada

4.9 ★ 207 avaliações  
no Google

Entenda o problema

## Tipos de Calosidades —  
cada um tem um protocolo diferente

Nem toda pele grossa é igual. O tipo certo de tratamento depende do diagnóstico correto — e o protocolo errado pode piorar o quadro ou acelerar o retorno do problema.

🦶

### Calosidade difusa

Pele espessada em áreas amplas — calcanhar, planta do pé, lateral dos dedos. Geralmente causada por pressão distribuída, calçado inadequado ou alteração biomecânica da marcha.

⚙️

### Calo com núcleo (heloma)

Tem um ponto central duro e profundo — o núcleo — que pressiona terminações nervosas causando dor aguda ao pisar. Precisa de remoção especializada do núcleo completo para não voltar.

⚠️ Mais doloroso

🔴

### Heloma mole

Calo entre os dedos, mantido úmido pelo suor. Pode macerar a pele e evoluir para fissura ou infecção. Muito comum em quem usa calçado fechado por longos períodos.

⚠️ Risco de infecção

### Principais causas — o que cria o ponto de pressão

👟

#### Calçado inadequado

Bico fino, salto alto, tamanho errado ou solado rígido criam pressão crônica em pontos específicos do pé.

🚶

#### Alteração da marcha

Pé chato, supinação ou hiperpronação redistribuem o peso de forma irregular, sobrecarregando áreas específicas.

🦴

#### Deformidades ósseas

Joanete, dedo em garra ou em martelo criam proeminências que roçam no calçado e geram calosidades de repetição.

⚖️

#### Sobrepeso

Aumenta a carga sobre a planta do pé, acelerando a formação de calosidades especialmente no calcanhar e na região metatarsal.

🧦

#### Atividade física intensa

Corrida, futebol e esportes de impacto geram atrito repetitivo que estimula o espessamento da pele como resposta protetora.

👴

#### Envelhecimento da pele

A pele perde elasticidade e resseca com a idade, tornando-se mais propensa a calosidades e fissuras — especialmente no calcanhar.

⚠️ O erro mais comum

## Por que o Calo  
Sempre Volta em Casa

Lixar, usar pedra-pomes ou espalhar creme hidratante não resolve o problema — alivia temporariamente. O calo é uma resposta de proteção do organismo ao ponto de pressão. Enquanto a pressão existir, ele volta.

❌

### Tratamento em casa

-   Remove só a camada superficial — a base do calo permanece
-   Não identifica nem elimina o ponto de pressão causador
-   Lixar em excesso pode criar ferida aberta e risco de infecção
-   O calo volta em dias ou semanas, geralmente mais espesso
-   Em diabéticos, qualquer abrasão sem supervisão é de alto risco

✅

### Tratamento em nossa Clínica

-   Remoção completa do calo e do núcleo com instrumental especializado
-   Identificação e orientação sobre o ponto de pressão causador
-   Avaliação do calçado e da marcha para reduzir a recidiva
-   Laser DMC para acelerar a regeneração da pele após a remoção
-   Protocolo específico e seguro para diabéticos e idosos

**Calo com núcleo que dói muito ao pisar?** Esse é o tipo que mais limita a qualidade de vida — e que resolve mais rápido com o tratamento correto.

[📲 Agendar consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20calos%20e%20calosidades.)

Como funciona

## Tratamento de Calos:  
Remoção Completa e Prevenção da Recidiva

1

Consulta · R$ 150,00

### Avaliação clínica e diagnóstico do tipo

A podóloga examina o tipo de calosidade, a localização, profundidade e — principalmente — **identifica o ponto de pressão causador**. Avalia também o calçado, a marcha e histórico do paciente. Essa etapa define o protocolo correto e o que precisa ser feito para reduzir a chance de retorno.

2

Procedimento

### Remoção especializada com instrumental clínico

A remoção é feita com instrumental específico de podologia clínica, com técnica que retira o calo ou o núcleo por completo — sem agredir o tecido saudável ao redor. No caso do heloma mole (entre os dedos), o protocolo inclui cuidados extras com a pele macerada.

3

Pós-remoção

### Laser DMC para regeneração + orientações

Quando indicado, aplicamos laser DMC Therapy para acelerar a regeneração da pele e reduzir a inflamação local. A podóloga orienta sobre **calçado adequado, palmilhas, cuidados em casa** e sinais de recidiva para que você identifique cedo se o ponto de pressão está voltando a agir.

4

Manutenção

### Podoprofilaxia periódica para quem tem tendência

Para pacientes com predisposição a calosidades — por deformidade óssea, alteração de marcha ou atividade física intensa — o acompanhamento periódico com podoprofilaxia é o que mantém os pés saudáveis e previne o retorno antes que o calo cause dor novamente.

Investimento

A partir de R$ 180,00

Valor do tratamento conforme tipo, quantidade e complexidade das lesões definido na consulta que tem o valor de R$ 150,00 e fica isenta se fechado tratamento no mesmo dia da consulta.

-   Avaliação clínica completa
-   Remoção do calo e/ou núcleo
-   Laser DMC quando indicado
-   Orientações de calçado e prevenção
-   Protocolo específico para diabéticos

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20calos%20e%20calosidades.)

### O que nos diferencia no tratamento

🔍

#### Identificamos a causa, não só o sintoma

A maioria dos tratamentos remove o calo. Aqui identificamos por que ele formou — e orientamos para reduzir a recidiva

⚡

#### Laser DMC para regeneração

Equipamento de referência nacional para acelerar a cicatrização e reduzir a inflamação pós-remoção

🩺

#### Protocolo seguro para diabéticos

Técnica e cuidados específicos para pacientes de alto risco — onde qualquer lesão exige atenção redobrada

👟

#### Orientação de calçado incluída

Avaliamos o calçado que você usa e orientamos o tipo ideal para reduzir os pontos de pressão causadores

**Formas de pagamento:** Pix, débito e crédito em até 10 vezes (taxa operadora). Clínica particular — não atendemos convênios.

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20433%20577'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

Especialista responsável

## Tratamento que Identifica  
a Causa — Não Só o Sintoma

Nossas podólogas tratam calosidades com o mesmo rigor clínico que aplicam a qualquer condição podológica — avaliando biomecânica, calçado, marcha e histórico do paciente antes de qualquer procedimento. **Remover o calo sem entender por que ele formou é garantir que ele volte.**

Com pós-graduação em Geriatria e Gerontologia e formação específica em pé diabético, Liana atende com protocolos diferenciados os perfis de maior risco — idosos e diabéticos, onde uma calosidade mal tratada pode ter consequências sérias.

### 🦴 Avaliação biomecânica incluída

Em cada consulta, Liana avalia a distribuição de pressão no pé, possíveis deformidades e o padrão de marcha — identificando o que está gerando o ponto de pressão e orientando sobre calçado, palmilhas e correções posturais quando necessário.

✓ Graduação em PodologiaUnicesumar · Nível Superior

✓ Pós-grad. Geriatriae Gerontologia

✓ Pós-grad. Diabetese Complicações Crônicas

✓ Laser DMC TherapyiLib e XT

✓ CIAP Internacional2023 · 2024 · 2025

✓ 50+ especializaçõese cursos livres

🩺

**Indicada por médicos e dermatologistas de Campo Grande** para tratamento de calosidades em pacientes diabéticos, idosos e com deformidades ósseas.

Dúvidas frequentes

## Perguntas sobre  
Calos e Calosidades

O calo vai voltar depois do tratamento? +

Depende. Se a causa — o ponto de pressão — for eliminada ou reduzida (com calçado correto, palmilha ou correção postural), o calo demora muito mais para voltar ou não volta. Se a causa permanecer ativa, ele vai retornar. **Por isso identificamos e orientamos sobre a causa em cada consulta** — não apenas removemos o sintoma. Para quem tem predisposição, a podoprofilaxia periódica é a melhor estratégia.

O tratamento dói? +

A remoção de calosidade simples não causa dor — pelo contrário, a maioria dos pacientes sente alívio imediato após o procedimento. No caso de calo com núcleo profundo, pode haver leve desconforto durante a remoção do núcleo, mas nada que impeça a continuidade do procedimento na mesma sessão.

Posso caminhar normalmente após a sessão? +

Sim, após o atendimento você sai caminhando normalmente. Em casos de remoção de calo com núcleo profundo, pode haver leve sensibilidade na área, porém sem a dor que era causada pelo calo que foi retirado, o alívio da dor é imediato após o procedimento. Orientamos sobre o calçado ideal para usar nos primeiros dias e como proteger a área tratada.

Tenho diabetes. Posso tratar calo normalmente? +

**Sim — e para diabéticos o tratamento especializado é ainda mais importante.** Calosidades em diabéticos aumentam a pressão local e podem gerar úlceras por baixo delas — sem que o paciente sinta, por causa da neuropatia. Liana tem pós-graduação em Diabetes e protocolo específico para esses pacientes, com técnica e cuidados adaptados ao risco.

Qual a diferença entre calo e verruga plantar? +

O calo é uma resposta mecânica à pressão — pele espessada sem estrutura viral. A verruga plantar é causada pelo HPV e tem pontinhos escuros no centro (capilares). **O calo (na maioria dos casos) dói com pressão lateral; a verruga dói com pressão direta.** O tratamento é completamente diferente — confundir os dois significa tratar a condição errada por meses. O diagnóstico correto é feito na avaliação clínica.

Quantas sessões são necessárias? +

Calosidades simples geralmente resolvem em 1 atendimento. Calos com núcleo profundo ou múltiplas lesões podem exigir retornos. Para quem tem predisposição por alteração de marcha ou deformidade óssea, o acompanhamento periódico mensal é recomendado para manter os pés saudáveis e evitar que o problema avance antes da próxima consulta.

Quem já foi atendido

## O que nossos pacientes  
dizem sobre o atendimento

★★★★★ 4.9 · 207 avaliações no Google

★★★★★

"Acolhedor, ótimo atendimento, passa segurança e confiança. Obrigada!"

L

Luzia Petricio

Verificado no Google

★★★★★

"Atendimento excelente, desde a recepcionista até o procedimento realizado pela doutora Liana. Indico o consultório com certeza!"

A

Avaliação Google

Verificado no Google

★★★★★

"Gostei muito, trabalho sensacional, atenciosos e explicam bem o tratamento para os pés, muito bom mesmo!"

J

Avaliação Google

Verificado no Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

Também tratamos

## Outros Tratamentos na Clínica

Resolva tudo em um só lugar — com o mesmo nível de cuidado e especialização.

[🦠

### Fungos nas Unhas

Diagnóstico laboratorial e protocolo clínico especializado.

Saiba mais →](/fungos-micose-onicomicose/) [🩹

### Unha Encravada

Alívio imediato da dor com tratamento especializado.

Saiba mais →](/unha-encravada/) [🎯

### Verruga Plantar

Remoção definitiva com laser DMC — protocolo comprovado.

Saiba mais →](/verruga-plantar/) [✨

### Podoprofilaxia

Manutenção preventiva para manter os pés saudáveis.

Saiba mais →](/podoprofilaxia/)

🦶 Alívio real começa aqui

## Cansado de sentir  
aquela pedra no sapato que nunca sai?

Agende sua consulta — na maioria dos casos tratamos na mesma consulta e você já sai com os pés aliviados. Sem precisar voltar na semana que vem.

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20calos%20e%20calosidades.) [📞 (67) 3305-0219](tel:6733050219)

Seg–Sex · 8h às 12h e 13h às 17h  
Rua Doutor Arthur Jorge, 2523 · Campo Grande-MS

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD

---

## [Página 11] Podoprofilaxia - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/podoprofilaxia
- **Profundidade:** 2
- **Descrição:** Ligue agora! Agendar Consulta ✨ Cuidado preventivo profissional Pés saudáveis não são sorte — são resultadode cuidado regular. A podoprofilaxia é o tratamento completo de manutenção dos pés — limpeza, corte correto de unhas, remoção de calosidades e avaliação preventiva. Tudo isso em uma sessão, com a qualidade clínica que protege sua saúde a longo […]
- **Palavras:** 1643 | **Imagens:** 14 | **Links:** 25

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #1 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #2 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #3 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #4 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #5 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #6 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #7 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #8 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #9 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Contexto: "<img decoding="async" width="694" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175206114-694x1024"
> *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H2: O Serviço Mais Procurado da Clínica — com Razão • Seção: Conteúdo da Página • Sob: H2: O Serviço Mais Procurado da Clínica — com Razão
![Imagem extraída](images/img_030_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175206114-694x102.jpg)

> **[Imagem 11]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
> *Posição:* Posição #11 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 12]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #12 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 13]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #13 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 14]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #14 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20sess%C3%A3o%20de%20podoprofilaxia.)

✨ Cuidado preventivo profissional

# Pés saudáveis não são  
sorte — são resultado  
de cuidado regular.

A podoprofilaxia é o tratamento completo de manutenção dos pés — limpeza, corte correto de unhas, remoção de calosidades e avaliação preventiva. Tudo isso em uma sessão, com a qualidade clínica que protege sua saúde a longo prazo.

✅

**Não é pedicure.** É um procedimento clínico realizado por podóloga especializada, com instrumental estéril, técnica correta e avaliação de sinais que o paciente não perceberia sozinho — como início de fungo, pressões inadequadas ou alterações de pele.

[📲 Agendar consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20sess%C3%A3o%20de%20podoprofilaxia.) [O que inclui ↓](#pro-inclui)

Consulta R$ 150,00 insenta se fizer  
procedimento no mesmo dia da consulta

2.000+ pacientes  
atendidos

15 anos de experiência  
especializada

4.9 ★ 207 avaliações  
no Google

O que é a podoprofilaxia

## Tudo que seus pés precisam  
em uma única sessão

A podoprofilaxia é o tratamento completo de manutenção e prevenção dos pés. Vai muito além de uma limpeza estética — é uma avaliação clínica completa integrada ao cuidado, realizada por podóloga especializada com instrumental certificado e técnica correta.

✂️

### Corte e modelagem das unhas

Corte técnico correto — reto, na altura adequada, respeitando a anatomia de cada dedo para evitar encravamento e lesões.

🦶

### Remoção de calosidades

Remoção técnica das calosidades e calos leves com instrumental especializado — sem exagero que cause ferida.

👩🏻‍⚕️

### Saúde e qualidade de vida

Sensação de alívio e bem estar após o procedimento que é realizado com técnica clínica — sem agredir a pele ou abrir porta para infecção.

💧

### Hidratação profissional

Aplicação de produtos profissionais para hidratação e proteção da pele dos pés — especialmente do calcanhar.

🔍

### Avaliação preventiva

A podóloga avalia sinais de fungo, alterações de pele, pontos de pressão e condições que o paciente geralmente não percebe sozinho.

⚡

### Laser DMC quando indicado

Quando identificada área com inflamação, calosidade mais intensa ou início de fungo, o laser pode ser aplicado na mesma sessão.

Entenda a diferença

## Podoprofilaxia não é pedicure —  
e a diferença importa

Muita gente trata os dois como sinônimos. Não são. A diferença está na formação de quem faz, no instrumental usado, na técnica aplicada e — principalmente — no que é avaliado durante o procedimento.

💅

### Pedicure convencional

-   Foco estético — aparência das unhas e dos pés
-   Sem formação clínica para identificar patologias
-   Instrumental que pode não ser adequadamente esterilizado
-   Corte incorreto pode causar encravamento
-   Sem avaliação preventiva de fungos, pressões ou alterações
-   Não indicado para diabéticos e pacientes de risco

🩺

### Podoprofilaxia clínica

-   Realizada por podóloga com formação técnica e superior
-   Instrumental clínico certificado e esterilizado em autoclave
-   Técnica correta de corte que previne encravamento
-   Avaliação preventiva de fungos, calos e alterações de pele
-   Laser DMC disponível quando identificada necessidade
-   Protocolo específico e seguro para diabéticos, idosos e crianças

### Para quem é a podoprofilaxia

🧑

#### Adultos saudáveis

Manutenção regular a cada 30-45 dias para manter os pés saudáveis e prevenir problemas.

🩺

#### Diabéticos

Acompanhamento mensal obrigatório — com protocolo específico e seguro para pacientes de alto risco.

👴

#### Idosos

Cuidado regular com técnica adaptada para a pele mais frágil e unhas mais espessas da terceira idade.

🏃

#### Atletas e esportistas

Prevenção de calosidades, bolhas e danos ungueais causados pelo atrito e impacto repetitivo.

Como funciona

## A Sessão de Podoprofilaxia:  
Do Início ao Fim

1

Início

### Avaliação e preparação dos pés

A sessão começa com a avaliação clínica dos pés — A podóloga examina unhas, pele, calosidades e identifica qualquer alteração que precise de atenção. **Antes de qualquer procedimento, os pés são higienizados e preparados adequadamente.**

2

Unhas

### Corte técnico das unhas

Corte técnico correto — reto, respeitando a anatomia de cada dedo — para prevenir encravamento. Tudo feito com instrumental específico, gerando segurança para sua saúde e qualidade de vida.

3

Pele

### Remoção de calosidades e tratamento da pele

Remoção técnica de calosidades e calos leves presentes. Tratamento que eleva a sensação de de alívio e bem estar. **Hidratação profissional finaliza o cuidado com a pele**, protegendo e nutrindo o tecido tratado.

4

Orientações

### Feedback e cuidados em casa

A podóloga compartilha o que foi observado no atendimento, o que precisa de atenção e como cuidar em casa até o próximo atendimento. Se for identificada alguma condição que precise de tratamento específico, você sai com o plano definido.

Investimento

A partir de R$ 200,00

Sessão completa de podoprofilaxia clínica, se fizer no mesmo dia da consulta o valor da consulta não é cobrado

-   Avaliação clínica preventiva completa
-   Corte e modelagem técnica das unhas
-   Tratamento premium
-   Remoção de calosidades leves
-   Hidratação profissional
-   Laser DMC quando indicado

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20sess%C3%A3o%20de%20podoprofilaxia.)

### Com que frequência fazer

🧑

#### Adulto saudável

A cada 30 a 45 dias — mantém os pés em dia e previne problemas antes que apareçam

🩺

#### Diabético

Mensalmente — acompanhamento obrigatório para prevenção de complicações sérias

👴

#### Idoso

A cada 30 dias — a pele e as unhas na terceira idade exigem cuidado mais frequente

🏃

#### Atleta

A cada 30 dias ou conforme intensidade do treino — prevenção de calosidades e lesões ungueais

**Formas de pagamento:** Pix, débito e crédito em até 10 vezes (taxa operadora). Clínica particular — não atendemos convênios.

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20694%201024'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

Especialista responsável

## O Serviço Mais Procurado  
da Clínica — com Razão

A podoprofilaxia é o serviço de maior volume da nossa Clínica — e não é à toa. Pacientes que fazem a manutenção regular chegam à consulta com problemas identificados cedo, tratados quando ainda são simples, e raramente precisam de procedimentos mais complexos.

Nossas podólogas realizam cada sessão com o mesmo cuidado clínico que aplicam a qualquer tratamento especializado. **Para elas, a podoprofilaxia não é rotina — é a principal oportunidade de prevenção.** É nessa sessão que sinais precoces de fungo, pontos de pressão problemáticos e alterações de pele são identificados antes de virarem problema.

### ✨ O tratamento preventivo mais importante da podologia

Manter a podoprofilaxia em dia é o que separa quem cuida dos pés de quem trata os pés. A diferença entre prevenir e remediar — em custo, tempo e desconforto — é enorme.

✓ Graduação em PodologiaUnicesumar · Nível Superior

✓ Pós-grad. Geriatriae Gerontologia

✓ Pós-grad. Diabetese Complicações Crônicas

✓ Laser DMC TherapyiLib e XT

✓ CIAP Internacional2023 · 2024 · 2025

✓ 15 anos de experiênciaem podologia clínica

🩺

**Indicada por médicos e dermatologistas de Campo Grande** para acompanhamento preventivo regular — especialmente para diabéticos, idosos e pacientes com histórico de problemas nos pés.

Dúvidas frequentes

## Perguntas sobre  
Podoprofilaxia

Qual a diferença entre podoprofilaxia e pedicure? +

A pedicure tem foco estético. A podoprofilaxia é um procedimento clínico realizado por podóloga formada, com instrumental esterilizado em autoclave, técnica correta de corte que previne encravamento e avaliação preventiva de patologias. **A maior diferença prática: na podoprofilaxia, você sai sabendo se tem algum problema começando nos seus pés.** Na pedicure, não.

De quanto em quanto tempo devo fazer? +

Para adultos saudáveis, a cada 30 a 45 dias. Para diabéticos e idosos, mensalmente. Para atletas, conforme a intensidade do treino — geralmente mensal também. **A regularidade é o que torna a podoprofilaxia preventiva** — fazer só quando o problema aparece é tratar, não prevenir.

Quanto tempo dura a sessão? +

Em média 40 a 60 minutos, dependendo do estado dos pés e se houver necessidade de procedimentos adicionais como remoção de calosidades mais espessas ou aplicação de laser. O agendamento já prevê o tempo adequado para que não haja pressa.

Diabético pode fazer podoprofilaxia? +

**Sim — e é obrigatório.** O diabético não pode fazer pedicure convencional — o risco de lesão, infecção e complicações é alto demais. A podoprofilaxia clínica com protocolo específico para diabéticos é a forma segura e correta de manter os pés em dia. Liana tem pós-graduação em Diabetes e formação em pé diabético.

Posso fazer podoprofilaxia mesmo sem ter nenhum problema nos pés? +

Esse é exatamente o perfil ideal — **fazer antes do problema aparecer, não depois.** A maioria dos problemas que chegam à clínica em estágio avançado — fungos, calos dolorosos, unhas encravadas — teriam sido identificados e tratados muito mais facilmente numa podoprofilaxia de rotina alguns meses antes.

O que acontece se a podóloga identificar algo na sessão? +

Depende do que for identificado. Condições simples como início de fungo, calosidade mais espessa ou área com pressão inadequada já podem ser tratadas na mesma sessão. Condições que exigem protocolo específico — podem ser necessário agendamento separado. **Você nunca sai da consulta sem saber o que foi encontrado e o que fazer.**

Quem já foi atendido

## O que nossos pacientes  
dizem sobre o atendimento

★★★★★ 4.9 · 207 avaliações no Google

★★★★★

"Acolhedor, ótimo atendimento, passa segurança e confiança. Obrigada!"

L

Luzia Petricio

Verificado no Google

★★★★★

"Atendimento excelente, desde a recepcionista até o procedimento realizado pela doutora Liana. Indico o consultório com certeza!"

A

Avaliação Google

Verificado no Google

★★★★★

"Gostei muito, trabalho sensacional, atenciosos e explicam bem o tratamento para os pés, muito bom mesmo!"

J

Avaliação Google

Verificado no Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

Também tratamos

## Outros Tratamentos na Clínica

Na podoprofilaxia identificamos — nos tratamentos especializados resolvemos. Tudo na mesma clínica.

[🦠

### Fungos nas Unhas

Diagnóstico laboratorial e protocolo clínico especializado.

Saiba mais →](/fungos-micose-onicomicose/) [🩹

### Unha Encravada

Alívio imediato com tratamento especializado e retornos inclusos.

Saiba mais →](/unha-encravada/) [🦶

### Calos e Calosidades

Remoção completa com identificação e tratamento da causa.

Saiba mais →](/calos-e-calosidades/) [🩺

### Pé do Diabético

Acompanhamento mensal especializado e seguro.

Saiba mais →](/pe-do-diabetico/)

✨ Comece a cuidar hoje

## Seus pés carregam você  
todos os dias. Cuide deles.

Agende sua sessão de podoprofilaxia — a primeira consulta inclui avaliação completa dos seus pés e você sai sabendo exatamente como está a saúde deles.

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20sess%C3%A3o%20de%20podoprofilaxia.) [📞 (67) 3305-0219](tel:6733050219)

Seg–Sex · 8h às 12h e 13h às 17h  
Rua Doutor Arthur Jorge, 2523 · Campo Grande-MS

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD

---

## [Página 12] Ozonioterapia - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/ozonioterapia
- **Profundidade:** 2
- **Descrição:** Ligue agora! Agendar Consulta 🎁 PRESENTE: Consulta grátis ao fechar seu tratamento! Recupere sua saúde e livre-se das dores crônicas com Ozonioterapia Tratamento natural e científico para Lipedema, Fibromialgia e Inflamações. Cuidado especializado com 15 anos de experiência em saúde. Quero falar com uma especialista Ver como funciona ✓ 15 Anos de Experiência ✓ Equipamentos […]
- **Palavras:** 489 | **Imagens:** 18 | **Links:** 24

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #1 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #2 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #3 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #4 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #5 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #6 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #7 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #8 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #9 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Contexto: "<img decoding="async" width="576" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome-576x1024.png" class="attachment-large size-la"
> *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Cuidado Especializado com quem entende de Saúde • Seção: Conteúdo da Página • Sob: H2: Cuidado Especializado com quem entende de Saúde
![Imagem extraída](images/img_055_Design-sem-nome-576x1024.png)

> **[Imagem 11]** Contexto: "<img decoding="async" width="576" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome-576x1024.png" class="attachment-large size-la"
> *Posição:* Posição #11 na página • Seção: Conteúdo da Página • Sob H2: Cuidado Especializado com quem entende de Saúde • Seção: Conteúdo da Página • Sob: H2: Cuidado Especializado com quem entende de Saúde
![Imagem extraída](images/img_056_Design-sem-nome-169x300.png)

> **[Imagem 12]** Contexto: "<img decoding="async" width="576" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome-576x1024.png" class="attachment-large size-la"
> *Posição:* Posição #12 na página • Seção: Conteúdo da Página • Sob H2: Cuidado Especializado com quem entende de Saúde • Seção: Conteúdo da Página • Sob: H2: Cuidado Especializado com quem entende de Saúde
![Imagem extraída](images/img_057_Design-sem-nome-768x1365.png)

> **[Imagem 13]** Contexto: "<img decoding="async" width="576" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome-576x1024.png" class="attachment-large size-la"
> *Posição:* Posição #13 na página • Seção: Conteúdo da Página • Sob H2: Cuidado Especializado com quem entende de Saúde • Seção: Conteúdo da Página • Sob: H2: Cuidado Especializado com quem entende de Saúde
![Imagem extraída](images/img_058_Design-sem-nome-864x1536.png)

> **[Imagem 14]** Contexto: "<img decoding="async" width="576" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome-576x1024.png" class="attachment-large size-la"
> *Posição:* Posição #14 na página • Seção: Conteúdo da Página • Sob H2: Cuidado Especializado com quem entende de Saúde • Seção: Conteúdo da Página • Sob: H2: Cuidado Especializado com quem entende de Saúde
![Imagem extraída](images/img_059_Design-sem-nome.png)

> **[Imagem 15]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
> *Posição:* Posição #15 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 16]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #16 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 17]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #17 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 18]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #18 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Olá!%20Gostaria%20de%20agendar%20uma%20consulta%20de%20ozonioterapia.)

🎁 PRESENTE: Consulta grátis ao fechar seu tratamento!

# Recupere sua saúde e livre-se das dores crônicas com Ozonioterapia

Tratamento natural e científico para Lipedema, Fibromialgia e Inflamações.  
Cuidado especializado com **15 anos de experiência em saúde.**

[Quero falar com uma especialista](https://api.whatsapp.com/send?phone=5567999160929&text=Olá!%20Gostaria%20de%20agendar%20uma%20consulta%20de%20ozonioterapia.) [Ver como funciona](#como-funciona)

✓ 15 Anos de Experiência

✓ Equipamentos Certificados

✓ Protocolos Personalizados

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20576%201024'%3E%3C/svg%3E)

Experiência que Gera Confiança

## Cuidado Especializado com quem entende de Saúde

Com **15 anos de trajetória na enfermagem**, Marciana Silva traz para a Ozonioterapia o rigor clínico e o olhar humano necessários para um tratamento seguro. Aqui, você não recebe apenas uma aplicação, mas um protocolo planejado por uma profissional experiente.

### 🎁 Oportunidade Especial

Sabemos que o primeiro passo é o mais importante. Por isso, **se você iniciar seu tratamento no dia da consulta, o valor da avaliação é por nossa conta.** Você investe apenas na sua saúde e nos resultados que deseja alcançar.

[Consultar disponibilidade de horário](https://api.whatsapp.com/send?phone=5567999160929&text=Olá!%20Gostaria%20de%20agendar%20uma%20consulta%20de%20ozonioterapia.)

## Como a Ozonioterapia pode te ajudar?

Mais do que uma técnica, uma solução natural para diversas condições que afetam seu bem-estar diário.

🦵

### Tratamento de Lipedema

Redução profunda da inflamação, melhora da circulação linfática e alívio do peso nas pernas.

💪

### Dores e Fibromialgia

Ação analgésica e anti-inflamatória que ajuda a reduzir o uso de medicamentos e devolve a mobilidade.

🦠

### Saúde Íntima e Imunidade

Combate eficaz contra candidíase de repetição e fortalecimento do sistema imunológico.

🦶

### Fascite e Dores nos Pés

Aceleração da cicatrização e redução de processos inflamatórios localizados com alta precisão.

☕

### Detox e Saúde Intestinal

Protocolos exclusivos de Enema de Café e Ozônio para desintoxicação hepática e regulação intestinal.

🩹

### Cicatrização de Feridas

Poderoso efeito bactericida que acelera a regeneração de tecidos em feridas de difícil cicatrização.

## Dúvidas Frequentes

### ❓ A Ozonioterapia é segura?

Sim, totalmente segura. É um procedimento reconhecido pelo CFM e aplicado com equipamentos certificados. Além disso, na nossa clínica, o procedimento é realizado por enfermeira com 15 anos de experiência clínica.

### ❓ O tratamento causa dor?

A maioria das técnicas é indolor ou causa apenas um leve desconforto momentâneo. Utilizamos agulhas extremamente finas e protocolos que priorizam o conforto do paciente.

### ❓ Como funciona a consulta bonificada?

Nós valorizamos quem decide cuidar da saúde. Se após a avaliação inicial você optar por fechar o seu protocolo de tratamento no mesmo dia, o valor da consulta é integralmente revertido como crédito para o seu tratamento. Ou seja, a consulta sai de presente!

Oferta por tempo limitado!

## Pronta para viver sem dor?

Não deixe sua saúde para depois. Agende sua avaliação hoje e aproveite nossa condição especial de consulta bonificada.

[Agendar Minha Avaliação Agora](https://api.whatsapp.com/send?phone=5567999160929&text=Olá!%20Gostaria%20de%20agendar%20uma%20consulta%20de%20ozonioterapia.)

## Fale Conosco

[📱

WhatsApp

(67) 99916-0929  
Resposta rápida

](https://api.whatsapp.com/send?phone=5567999160929&text=Olá!%20Gostaria%20de%20agendar%20minha%20primeira%20consulta%20de%20ozonioterapia.)[☎️

Telefone

(67) 3305-0219

](tel:6733050219)[📍

Endereço

Rua Doutor Arthur Jorge, 2523  
Campo Grande - MS

](https://www.google.com/maps/search/?api=1&query=Rua+Doutor+Arthur+Jorge,+2523,+Campo+Grande,+MS)

🕐

Horário

Segunda a Sexta  
8h às 11h | 13h às 17h

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD

---

## [Página 13] Blog - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/blog
- **Profundidade:** 2
- **Descrição:** Ligue agora! Agendar Consulta 📚 Conteúdo clínico de podologia Informação que cuida — antes da consulta Artigos escritos por Liana Gonçalves sobre saúde dos pés, tratamentos, prevenção e tudo que você precisa saber para cuidar melhor dos seus pés. Todos Fungos nas Unhas Unha Encravada Pé do Diabético Calos e Calosidades Verruga Plantar Podopediatria Prevenção […]
- **Palavras:** 604 | **Imagens:** 38 | **Links:** 29

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #1 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #2 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #3 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #4 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #5 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #6 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #7 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #8 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #9 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Contexto: "<img decoding="async" width="800" height="600" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem-do-WhatsApp-de-2023-10-24-as-11.37.07_33072c7a-1024x768"
> *Posição:* Posição #10 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Podologia Clínica • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Podologia Clínica
![Imagem extraída](images/img_060_Imagem-do-WhatsApp-de-2023-10-24-as-11_37_07_33072c7a-1024x7.jpg)

> **[Imagem 11]** Contexto: "<img decoding="async" width="800" height="600" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem-do-WhatsApp-de-2023-10-24-as-11.37.07_33072c7a-1024x768"
> *Posição:* Posição #11 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Podologia Clínica • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Podologia Clínica
![Imagem extraída](images/img_061_Imagem-do-WhatsApp-de-2023-10-24-as-11_37_07_33072c7a-300x22.jpg)

> **[Imagem 12]** Contexto: "<img decoding="async" width="800" height="600" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem-do-WhatsApp-de-2023-10-24-as-11.37.07_33072c7a-1024x768"
> *Posição:* Posição #12 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Podologia Clínica • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Podologia Clínica
![Imagem extraída](images/img_062_Imagem-do-WhatsApp-de-2023-10-24-as-11_37_07_33072c7a-768x57.jpg)

> **[Imagem 13]** Contexto: "<img decoding="async" width="800" height="600" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem-do-WhatsApp-de-2023-10-24-as-11.37.07_33072c7a-1024x768"
> *Posição:* Posição #13 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Podologia Clínica • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Podologia Clínica
![Imagem extraída](images/img_063_Imagem-do-WhatsApp-de-2023-10-24-as-11_37_07_33072c7a.jpg)

> **[Imagem 14]** Contexto: "<img decoding="async" width="576" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/02/IMG-20190207-WA0086-576x1024.webp" class="attachment-large si"
> *Posição:* Posição #14 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Calo ou verruga plantar? Como diferenciar — e por que importa • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Calo ou verruga plantar? Como diferenciar — e por que importa
![Imagem extraída](images/img_064_IMG-20190207-WA0086-576x1024.webp)

> **[Imagem 15]** Contexto: "<img decoding="async" width="576" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/02/IMG-20190207-WA0086-576x1024.webp" class="attachment-large si"
> *Posição:* Posição #15 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Calo ou verruga plantar? Como diferenciar — e por que importa • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Calo ou verruga plantar? Como diferenciar — e por que importa
![Imagem extraída](images/img_065_IMG-20190207-WA0086-169x300.webp)

> **[Imagem 16]** Contexto: "<img decoding="async" width="576" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/02/IMG-20190207-WA0086-576x1024.webp" class="attachment-large si"
> *Posição:* Posição #16 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Calo ou verruga plantar? Como diferenciar — e por que importa • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Calo ou verruga plantar? Como diferenciar — e por que importa
![Imagem extraída](images/img_066_IMG-20190207-WA0086.webp)

> **[Imagem 17]** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1-1024x1024.png" class="attachm"
> *Posição:* Posição #17 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Podoprofilaxia vs. pedicure: qual a diferença real? • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Podoprofilaxia vs. pedicure: qual a diferença real?
![Imagem extraída](images/img_067_Design-sem-nome-1-1024x1024.png)

> **[Imagem 18]** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1-1024x1024.png" class="attachm"
> *Posição:* Posição #18 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Podoprofilaxia vs. pedicure: qual a diferença real? • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Podoprofilaxia vs. pedicure: qual a diferença real?
![Imagem extraída](images/img_068_Design-sem-nome-1-300x300.png)

> **[Imagem 19]** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1-1024x1024.png" class="attachm"
> *Posição:* Posição #19 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Podoprofilaxia vs. pedicure: qual a diferença real? • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Podoprofilaxia vs. pedicure: qual a diferença real?
![Imagem extraída](images/img_069_Design-sem-nome-1-150x150.png)

> **[Imagem 20]** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1-1024x1024.png" class="attachm"
> *Posição:* Posição #20 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Podoprofilaxia vs. pedicure: qual a diferença real? • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Podoprofilaxia vs. pedicure: qual a diferença real?
![Imagem extraída](images/img_070_Design-sem-nome-1-768x768.png)

> **[Imagem 21]** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1-1024x1024.png" class="attachm"
> *Posição:* Posição #21 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Podoprofilaxia vs. pedicure: qual a diferença real? • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Podoprofilaxia vs. pedicure: qual a diferença real?
![Imagem extraída](images/img_071_Design-sem-nome-1.png)

> **[Imagem 22]** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n"
> *Posição:* Posição #22 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: O calçado certo pode evitar 70% dos problemas nos pés • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: O calçado certo pode evitar 70% dos problemas nos pés
![Imagem extraída](images/img_054_282207662_441098077826309_4659220234443228409_n.jpg)

> **[Imagem 23]** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n"
> *Posição:* Posição #23 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: O calçado certo pode evitar 70% dos problemas nos pés • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: O calçado certo pode evitar 70% dos problemas nos pés
![Imagem extraída](images/img_052_282207662_441098077826309_4659220234443228409_n-300x300.jpg)

> **[Imagem 24]** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n"
> *Posição:* Posição #24 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: O calçado certo pode evitar 70% dos problemas nos pés • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: O calçado certo pode evitar 70% dos problemas nos pés
![Imagem extraída](images/img_053_282207662_441098077826309_4659220234443228409_n-150x150.jpg)

> **[Imagem 25]** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n"
> *Posição:* Posição #25 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: O calçado certo pode evitar 70% dos problemas nos pés • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: O calçado certo pode evitar 70% dos problemas nos pés
![Imagem extraída](images/img_051_282207662_441098077826309_4659220234443228409_n-768x768.jpg)

> **[Imagem 26]** Contexto: "<img loading="lazy" decoding="async" width="800" height="531" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-10-24-as-11.27.44_81"
> *Posição:* Posição #26 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Pé diabético: os 5 sinais que pedem atenção imediata • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Pé diabético: os 5 sinais que pedem atenção imediata
![Imagem extraída](images/img_072_Imagem-do-WhatsApp-de-2023-10-24-as-11_27_44_8181cf23-e16982.jpg)

> **[Imagem 27]** Contexto: "<img loading="lazy" decoding="async" width="800" height="531" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-10-24-as-11.27.44_81"
> *Posição:* Posição #27 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Pé diabético: os 5 sinais que pedem atenção imediata • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Pé diabético: os 5 sinais que pedem atenção imediata
![Imagem extraída](images/img_073_Imagem-do-WhatsApp-de-2023-10-24-as-11_27_44_8181cf23-e16982.jpg)

> **[Imagem 28]** Contexto: "<img loading="lazy" decoding="async" width="800" height="531" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-10-24-as-11.27.44_81"
> *Posição:* Posição #28 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Pé diabético: os 5 sinais que pedem atenção imediata • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Pé diabético: os 5 sinais que pedem atenção imediata
![Imagem extraída](images/img_074_Imagem-do-WhatsApp-de-2023-10-24-as-11_27_44_8181cf23-e16982.jpg)

> **[Imagem 29]** Contexto: "<img loading="lazy" decoding="async" width="800" height="531" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-10-24-as-11.27.44_81"
> *Posição:* Posição #29 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Pé diabético: os 5 sinais que pedem atenção imediata • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Pé diabético: os 5 sinais que pedem atenção imediata
![Imagem extraída](images/img_075_Imagem-do-WhatsApp-de-2023-10-24-as-11_27_44_8181cf23-e16982.jpg)

> **[Imagem 30]** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-1024x1024.png" class="attachment-lar"
> *Posição:* Posição #30 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Unha encravada em bebê • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Unha encravada em bebê
![Imagem extraída](images/img_048_Design-sem-1024x1024.png)

> **[Imagem 31]** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-1024x1024.png" class="attachment-lar"
> *Posição:* Posição #31 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Unha encravada em bebê • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Unha encravada em bebê
![Imagem extraída](images/img_047_Design-sem-300x300.png)

> **[Imagem 32]** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-1024x1024.png" class="attachment-lar"
> *Posição:* Posição #32 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Unha encravada em bebê • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Unha encravada em bebê
![Imagem extraída](images/img_049_Design-sem-150x150.png)

> **[Imagem 33]** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-1024x1024.png" class="attachment-lar"
> *Posição:* Posição #33 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Unha encravada em bebê • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Unha encravada em bebê
![Imagem extraída](images/img_046_Design-sem-768x768.png)

> **[Imagem 34]** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-1024x1024.png" class="attachment-lar"
> *Posição:* Posição #34 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Unha encravada em bebê • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob: H1: Unha encravada em bebê
![Imagem extraída](images/img_050_Design-sem.png)

> **[Imagem 35]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
> *Posição:* Posição #35 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 36]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #36 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 37]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #37 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 38]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #38 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

[

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20600'%3E%3C/svg%3E)

](https://podologialianagoncalves.com.br/podologia-clinica/)

# [Podologia Clínica](https://podologialianagoncalves.com.br/podologia-clinica/)

16/04/2026 Nenhum comentário

Ela achava que o bebê tinha cólica. A dor vinha de outro lugar. Quando a causa mais improvável é a que ninguém pensa em checar — e a que mais

[Leia mais »](https://podologialianagoncalves.com.br/podologia-clinica/)

---

## [Página 14] Contato - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/contato-podologa
- **Profundidade:** 2
- **Descrição:** Precisa de podóloga confiável? Somos a clinica de podologia mais conceituada e bem avaliada de Campo Grande, entre em contato agora mesmo!
- **Palavras:** 582 | **Imagens:** 17 | **Links:** 22

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #1 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #2 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #3 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #4 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #5 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #6 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #7 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #8 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #9 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
> *Posição:* Posição #10 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 11]** Texto Alt: "Social Meta Image (og:image)" | Título: "og:image" | Contexto: "Meta tag og:image"
> *Posição:* Posição #11 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image)](images/img_076_Social_Meta_Image_og_image.png)

> **[Imagem 12]** Texto Alt: "Social Meta Image (og:image:width)" | Título: "og:image:width" | Contexto: "Meta tag og:image:width"
> *Posição:* Posição #12 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:width)](7081)

> **[Imagem 13]** Texto Alt: "Social Meta Image (og:image:height)" | Título: "og:image:height" | Contexto: "Meta tag og:image:height"
> *Posição:* Posição #13 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:height)](3133)

> **[Imagem 14]** Texto Alt: "Social Meta Image (og:image:type)" | Título: "og:image:type" | Contexto: "Meta tag og:image:type"
> *Posição:* Posição #14 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:type)](image/png)

> **[Imagem 15]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #15 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 16]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #16 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 17]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #17 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

[![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)](https://podologialianagoncalves.com.br/)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

📍 Campo Grande-MS

# Agende sua Consulta —  
estamos prontos  
para te atender

O primeiro passo é simples: mande uma mensagem pelo WhatsApp ou ligue. Emily vai encontrar o melhor horário para você.

## Como nos  
encontrar

[

WhatsApp — mais rápido

(67) 99916-0929

Resposta rápida · Seg–Sex · 8h às 12h e 13h às 17h

→

](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)[

☎️

Telefone fixo

(67) 3305-0219

Seg–Sex · 8h às 12h e 13h às 17h

→

](tel:6733050219)[

📱

Celular

(67) 99916-0929

Seg–Sex · 8h às 12h e 13h às 17h

→

](tel:67999160929)[

📍

Endereço

Rua Doutor Arthur Jorge, 2523

Monte Castelo · Campo Grande-MS · CEP 79010-210

→

](https://maps.google.com/?q=Rua+Doutor+Arthur+Jorge+2523+Campo+Grande+MS)

🕐

Horário de Atendimento

Segunda a Sexta

8h às 12h · 13h às 17h

💳

### Formas de pagamento

Pix · Débito · Crédito em até 10x (taxa operadora) · Dinheiro  
Clínica particular — não atendemos convênios

### 📌 Como chegar

A clínica fica na Rua Doutor Arthur Jorge, 2523, no bairro Monte Castelo. Próximo à Av. Afonso Pena. Há estacionamento na rua.

Antes de entrar em contato

## Dúvidas frequentes  
sobre agendamento

Como faço para agendar uma consulta? +

O jeito mais rápido é pelo WhatsApp — mande uma mensagem para **(67) 99916-0929** e Emily vai confirmar o horário disponível. Você também pode ligar para **(67) 3305-0219**. O agendamento é feito de Segunda a Sexta feira · Das 8h às 12h e das 13h às 17h.

Preciso levar algum documento ou exame? +

Não é obrigatório mas facilita o cadastro em nosso sistema para a primeira consulta. Se você tiver exames anteriores relacionados ao problema — como exame micológico para fungo, ou histórico de tratamentos — traga para que a podóloga possa avaliar o histórico completo. Diabéticos devem trazer resultados recentes de glicemia quando disponíveis.

Vocês atendem por convênio ou plano de saúde? +

A clínica é particular. Aceitamos Pix, débito e crédito em até 10 vezes (sujeito à taxa da operadora). Se você tiver plano de saúde com cobertura para podologia, pode solicitar reembolso diretamente à sua operadora — **emitimos nota fiscal de todos os serviços prestados.**

Qual o valor da consulta? +

A consulta inicial custa **R$ 150** e é isenta quando o tratamento é iniciado na mesma sessão. A podoprofilaxia tem valor **a partir de R$ 200,00**. Tratamentos específicos como fungos, verruga plantar e calosidades têm valores definidos na avaliação conforme a complexidade do caso. Não há cobrança surpresa — você recebe o plano completo com valores antes de iniciar qualquer procedimento.

Tem estacionamento próximo? +

Sim. Há vagas de estacionamento na própria Rua Doutor Arthur Jorge e nas ruas adjacentes. Temos uma vaga no interior do prédio disponível para pessoas com dificuldade de locomoção. A clínica fica no bairro Monte Castelo, entre as rua Alegrete e Dolor Ferreira de Andrade, de fácil acesso pela região central de Campo Grande.

Posso levar acompanhante na consulta? +

Sim. No atendimento infantil os pais ficam presentes durante toda a consulta — isso é parte do protocolo da clínica. Para adultos, acompanhantes são bem-vindos, especialmente idosos que precisam de suporte para locomoção.

📲 Fale com a gente agora

## Pronto para cuidar  
dos seus pés de verdade?

Mande uma mensagem pelo WhatsApp — Emily responde rápido e encontra o melhor horário para você. Primeira consulta com avaliação completa.

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.) [📞 (67) 3305-0219](tel:6733050219)

Seg–Sex · 8h às 12h e 13h às 17h  
Rua Doutor Arthur Jorge, 2523 · Monte Castelo · Campo Grande-MS

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD

---

## [Página 15] Sobre nós - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/sobre-nos/
- **Profundidade:** 2
- **Descrição:** Ligue agora! Agendar Consulta Nossa história · Campo Grande-MS Nascemos do amor à podologia. Crescemos pela confiança de quem cuidamos. Desde 2019, a Clínica de Podologia Liana Gonçalves atende Campo Grande com um propósito claro: elevar o nível da podologia clínica no Mato Grosso do Sul — com rigor técnico, atualização constante e cuidado verdadeiramente […]
- **Palavras:** 1661 | **Imagens:** 23 | **Links:** 22

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #1 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #2 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #3 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #4 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #5 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #6 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #7 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #8 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #9 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-remove"
> *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Uma paixão que começouem 2011 e nunca parou • Seção: Conteúdo da Página • Sob: H2: Uma paixão que começouem 2011 e nunca parou
![Imagem extraída](images/img_012_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png)

> **[Imagem 11]** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-remove"
> *Posição:* Posição #11 na página • Seção: Conteúdo da Página • Sob H2: Uma paixão que começouem 2011 e nunca parou • Seção: Conteúdo da Página • Sob: H2: Uma paixão que começouem 2011 e nunca parou
![Imagem extraída](images/img_013_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png)

> **[Imagem 12]** Contexto: "<img decoding="async" width="720" height="980" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175282399.jpeg" cla"
> *Posição:* Posição #12 na página • Seção: Conteúdo da Página • Sob H2: Liana Gonçalves • Seção: Conteúdo da Página • Sob: H2: Liana Gonçalves
![Imagem extraída](images/img_010_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399.jpg)

> **[Imagem 13]** Contexto: "<img decoding="async" width="720" height="980" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175282399.jpeg" cla"
> *Posição:* Posição #13 na página • Seção: Conteúdo da Página • Sob H2: Liana Gonçalves • Seção: Conteúdo da Página • Sob: H2: Liana Gonçalves
![Imagem extraída](images/img_011_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399-220x300.jpg)

> **[Imagem 14]** Contexto: "<img loading="lazy" decoding="async" width="400" height="548" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-09-at-10.41.27-1-e177367"
> *Posição:* Posição #14 na página • Seção: Conteúdo da Página • Sob H3: Marciana Soares • Seção: Conteúdo da Página • Sob: H3: Marciana Soares
![Imagem extraída](images/img_018_WhatsApp-Image-2026-03-09-at-10_41_27-1-e1773675928249.jpg)

> **[Imagem 15]** Contexto: "<img loading="lazy" decoding="async" width="400" height="548" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.13-e17736753"
> *Posição:* Posição #15 na página • Seção: Conteúdo da Página • Sob H3: Jocineia • Seção: Conteúdo da Página • Sob: H3: Jocineia
![Imagem extraída](images/img_019_WhatsApp-Image-2026-03-16-at-10_59_13-e1773675323462.jpg)

> **[Imagem 16]** Contexto: "<img loading="lazy" decoding="async" width="400" height="548" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.13-e17736753"
> *Posição:* Posição #16 na página • Seção: Conteúdo da Página • Sob H3: Jocineia • Seção: Conteúdo da Página • Sob: H3: Jocineia
![Imagem extraída](images/img_020_WhatsApp-Image-2026-03-16-at-10_59_13-e1773675323462-219x300.jpg)

> **[Imagem 17]** Contexto: "<img loading="lazy" decoding="async" width="768" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.11-2-768x10"
> *Posição:* Posição #17 na página • Seção: Conteúdo da Página • Sob H2: Emily Regis • Seção: Conteúdo da Página • Sob: H2: Emily Regis
![Imagem extraída](images/img_021_WhatsApp-Image-2026-03-16-at-10_59_11-2-768x1024.jpg)

> **[Imagem 18]** Contexto: "<img loading="lazy" decoding="async" width="768" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.11-2-768x10"
> *Posição:* Posição #18 na página • Seção: Conteúdo da Página • Sob H2: Emily Regis • Seção: Conteúdo da Página • Sob: H2: Emily Regis
![Imagem extraída](images/img_022_WhatsApp-Image-2026-03-16-at-10_59_11-2-225x300.jpg)

> **[Imagem 19]** Contexto: "<img loading="lazy" decoding="async" width="768" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.11-2-768x10"
> *Posição:* Posição #19 na página • Seção: Conteúdo da Página • Sob H2: Emily Regis • Seção: Conteúdo da Página • Sob: H2: Emily Regis
![Imagem extraída](images/img_023_WhatsApp-Image-2026-03-16-at-10_59_11-2.jpg)

> **[Imagem 20]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
> *Posição:* Posição #20 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 21]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #21 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 22]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #22 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 23]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #23 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

[![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)](https://podologialianagoncalves.com.br/)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

Nossa história · Campo Grande-MS

# Nascemos do amor à podologia.  
Crescemos pela _confiança_  
de quem cuidamos.

Desde 2019, a Clínica de Podologia Liana Gonçalves atende Campo Grande com um propósito claro: elevar o nível da podologia clínica no Mato Grosso do Sul — com rigor técnico, atualização constante e cuidado verdadeiramente personalizado.

2011 início da trajetória  
de Liana

2.000+ pacientes  
atendidos

4.9 ★ 207 avaliações  
no Google

50+ cursos e  
especializações

90% taxa de  
sucesso

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20433%20577'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

A origem

## Uma paixão que começou  
em 2011 e nunca parou

2011

### Amor à primeira vista com a podologia

Cursando Recursos Humanos, Alveliana Gonçalves teve seu primeiro contato com a podologia como auxiliar. Foi imediato: **ela abandonou o curso de RH e se dedicou completamente à podologia**. Não foi uma escolha de carreira — foi uma vocação.

2018

### O sonho começa a tomar forma

Depois de 7 anos acumulando experiência, especializações e o olhar clínico que só o tempo constrói, Liana decidiu que Campo Grande merecia **uma podologia em outro nível**. Nasceu o projeto da clínica.

2019

### A Clínica abre as portas

Com equipamentos de última geração — incluindo o laser DMC Therapy iLib e XT, referência do mercado — a Clínica de Podologia Liana Gonçalves começa a atender com um padrão que até então não existia em Campo Grande-MS.

Hoje

### Referência em Mato Grosso do Sul

Mais de 2.000 pacientes atendidos, 207 avaliações 4.9★ no Google, indicada por médicos e dermatologistas da cidade — e formando outros profissionais de podologia no estado. **O sonho virou legado.**

"Focada exclusivamente na saúde dos pés, pois ter pés sem dores é muito importante para o seu bem-estar — e eu cuido de tudo pessoalmente para garantir o nível máximo de qualidade."

— Liana Gonçalves, podóloga responsável

As pessoas por trás do cuidado

## Nossa Equipe

😊

Clínica de podologia Liana Gonçalves

Nossa equipe

Todos os profissionais que atuam em nossa clínica são treinados para estarem sempre prontos para te atender da melhor forma possível sempre que precisar, conheça um pouco mais de cada uma das pessoas que amam cuidar da saúde dos seus pés e melhorar a sua qualidade de vida.

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20720%20980'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

Podóloga Responsável · Fundadora

Podóloga · 15 anos de experiência

## Liana Gonçalves

Graduada em Podologia · Unicesumar · Nível Superior

Liana começou na podologia em 2011 por vocação pura — largou o curso de Recursos Humanos no meio para se dedicar completamente à área. Depois de 7 anos acumulando experiência e especializações, fundou em 2019 a clínica com um propósito claro: **elevar o padrão da podologia clínica em Campo Grande**.

Hoje, além de atender mais de 2.000 pacientes com 90% de taxa de sucesso, **forma outros profissionais de podologia no Mato Grosso do Sul** e participa anualmente do CIAP — o maior congresso internacional de podologia do mundo.

✓ Pós-grad. Diabetese Complicações Crônicas

✓ Pós-grad. Dermatologiae Tratamento de Feridas

✓ Pós-grad. Geriatriae Gerontologia

✓ Laser DMC TherapyiLib e XT

✓ SemiologiaPé Diabético

✓ CIAP Internacional2023 · 2024 · 2025

🩺

**Indicada por médicos e dermatologistas de Campo Grande** — e referência no MS para formação de novos profissionais de podologia.

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20400%20548'%3E%3C/svg%3E)

Marciana da Silva Soares

Enfermeira certificada Ozonioterapeuta · 15 anos

★★★★★

Enfermeira · Ozonioterapeuta

### Marciana Soares

COREN 296.442 · 15 anos de experiência

Marciana traz a visão da enfermagem clínica para potencializar os resultados dos tratamentos podológicos. Responsável pelo serviço de **ozonioterapia da clínica**, é especialista Master O3 e uma das profissionais de referência no tema em Campo Grande-MS.

Graduação em Enfermagem

Especialização Master O3 em Ozonioterapia

15 anos de experiência clínica

Responsável técnica pela ozonioterapia

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20400%20548'%3E%3C/svg%3E)

Jocineia Lima

Podóloga Clínica · Seus pés em boas mãos

★★★★★

Podóloga Clínica

### Jocineia

Podóloga · equipe clínica

Jocineia integra a equipe clínica da Liana Gonçalves atuando com os mesmos protocolos e padrão de excelência que definem cada atendimento da clínica. **Cada paciente recebe o mesmo nível de cuidado, independentemente de qual profissional esteja atendendo** — isso é uma escolha deliberada de cultura, não coincidência.

Podologia clínica

Atendimento com protocolos padronizados da clínica

Tratamentos: onicomicose, unha encravada, calos, podoprofilaxia

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20768%201024'%3E%3C/svg%3E)

O primeiro contato com a clínica

Recepção e Agendamento

## Emily Regis

Recepcionista · atendimento presencial e WhatsApp

Antes de qualquer procedimento, existe um primeiro contato — e ele importa. Emily é a pessoa que recebe cada paciente na porta, responde pelo WhatsApp, organiza a agenda e garante que a experiência na clínica comece da forma certa: **com atenção, clareza e acolhimento genuíno**.

📲

**Agendamentos pelo WhatsApp e telefone** — tira dúvidas sobre valores, horários e como funciona cada tratamento antes da consulta

😊

**Recepção presencial** — recebe cada paciente com o nome e o cuidado que cada pessoa merece desde o momento em que entra

🗂️

**Organização da agenda** — garante que os atendimentos fluam sem atrasos e que cada paciente tenha o tempo necessário para seu caso

"Cuidado começa **antes** do consultório. A experiência que queremos entregar começa já no primeiro 'olá' — seja pelo WhatsApp ou na porta da clínica."

O que nos move

## Os valores que guiam  
cada atendimento

🔬

### Rigor Clínico

Podologia é saúde, não estética. Cada protocolo é baseado em evidência científica e atualizado constantemente — por isso participamos dos principais congressos internacionais da área todo ano.

🎯

### Personalização Real

Não existe protocolo genérico aqui. Cada paciente tem um histórico, um perfil de risco, um ritmo. O plano de tratamento é construído especificamente para você — não para "a condição".

🤝

### Transparência Total

Explicamos o diagnóstico, as opções de tratamento e os custos com clareza. Você toma decisões informado — não porque "a especialista disse". Respeito à autonomia do paciente é inegociável.

📚

### Atualização Permanente

Mais de 50 especializações e cursos acumulados. CIAP Internacional 2023, 2024 e 2025. A podologia avança — e nossa equipe avança junto. O que você recebe hoje é o que há de mais atual na área.

⚡

### Tecnologia de Ponta

Laser DMC Therapy iLib e XT — referência do mercado nacional em laserterapia podológica. Equipamentos de última geração não são diferencial de luxo: são parte do resultado que entregamos.

🏆

### Resultado, Não Aparência

Nosso trabalho é medido em dor zero, mobilidade recuperada, infecções resolvidas, amputações prevenidas. Métricas de saúde — não de estética. Isso é podologia clínica de verdade.

Credenciais e reconhecimento

### Formação que vai além do básico

Cada pós-graduação e especialização foi escolhida para atender melhor os perfis mais complexos — diabéticos, idosos, pacientes com feridas crônicas.

-   Pós-grad. em Diabetes e Complicações Crônicas
-   Pós-grad. em Enfermagem em Dermatologia e Tratamento de Feridas
-   Pós-grad. em Geriatria e Gerontologia
-   Pós-grad. em Nutrição com Ênfase em Obesidade
-   Especialização Master O3 em Ozonioterapia
-   Especialização em Semiologia do Pé Diabético
-   Especialização em Laser — Descomplicando Laserterapia
-   CIAP Internacional 2023 · 2024 · 2025
-   1º Congresso de Podologia MS · XIX Jornada Internacional
-   Forma outros profissionais de podologia no MS

2.000+ Pacientes atendidos

4.9 ★ 207 avaliações no Google

90% Taxa de sucesso nos tratamentos

50+ Cursos e especializações

15 anos de trajetória na podologia

3x CIAP Internacional consecutivo

A voz de quem viveu

## Mais de 2.000 pacientes.  
207 avaliações. Uma consistência.

★★★★★ 4.9 · média Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

🔒 LGPD · Lei nº 13.709/2018

## Nosso compromisso com  
a privacidade dos seus dados

Em nossa clínica, tratamos dados pessoais e de saúde com o mesmo rigor que aplicamos aos nossos procedimentos clínicos. Seus dados são coletados apenas para o que é necessário ao seu atendimento — e protegidos em conformidade com a Lei Geral de Proteção de Dados.

🔒 LGPD Lei nº 13.709/2018  
Em conformidade

🩺

### Dados de saúde protegidos

Informações clínicas são dados sensíveis pela LGPD. Coletamos apenas o necessário para o seu tratamento, com acesso restrito à equipe clínica.

🎯

### Finalidade específica

Seus dados são usados exclusivamente para agendamento, atendimento clínico e comunicação relacionada à sua saúde. Não vendemos nem compartilhamos para fins comerciais.

✅

### Consentimento explícito

Dados sensíveis de saúde são coletados apenas com seu consentimento. Você pode revogar a qualquer momento sem prejuízo do atendimento já realizado.

🛡️

### Armazenamento seguro

Site com SSL, prontuário com acesso restrito e parceiros de tecnologia com obrigações contratuais de proteção. Seus dados não ficam expostos.

👤

### Seus direitos garantidos

Acesso, correção, portabilidade e exclusão dos seus dados. Respondemos solicitações em até 15 dias úteis pelo WhatsApp ou e-mail da clínica.

👶

### Proteção reforçada para menores

Dados de crianças e adolescentes são coletados apenas com consentimento dos responsáveis legais, presentes durante todo o atendimento.

### Política de Privacidade completa

Acesse nossa política unificada — LGPD, cookies, dados de saúde e todos os seus direitos explicados de forma clara e transparente.

[🔒 Ler política completa →](/politica-de-privacidade/)

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD

---

## [Página 16] Contato - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/contato-podologa/
- **Profundidade:** 2
- **Descrição:** Precisa de podóloga confiável? Somos a clinica de podologia mais conceituada e bem avaliada de Campo Grande, entre em contato agora mesmo!
- **Palavras:** 582 | **Imagens:** 17 | **Links:** 22

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #1 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #2 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #3 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #4 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #5 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #6 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #7 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #8 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #9 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
> *Posição:* Posição #10 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 11]** Texto Alt: "Social Meta Image (og:image)" | Título: "og:image" | Contexto: "Meta tag og:image"
> *Posição:* Posição #11 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image)](images/img_076_Social_Meta_Image_og_image.png)

> **[Imagem 12]** Texto Alt: "Social Meta Image (og:image:width)" | Título: "og:image:width" | Contexto: "Meta tag og:image:width"
> *Posição:* Posição #12 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:width)](7081)

> **[Imagem 13]** Texto Alt: "Social Meta Image (og:image:height)" | Título: "og:image:height" | Contexto: "Meta tag og:image:height"
> *Posição:* Posição #13 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:height)](3133)

> **[Imagem 14]** Texto Alt: "Social Meta Image (og:image:type)" | Título: "og:image:type" | Contexto: "Meta tag og:image:type"
> *Posição:* Posição #14 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:type)](image/png)

> **[Imagem 15]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #15 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 16]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #16 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 17]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #17 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

[![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)](https://podologialianagoncalves.com.br/)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

📍 Campo Grande-MS

# Agende sua Consulta —  
estamos prontos  
para te atender

O primeiro passo é simples: mande uma mensagem pelo WhatsApp ou ligue. Emily vai encontrar o melhor horário para você.

## Como nos  
encontrar

[

WhatsApp — mais rápido

(67) 99916-0929

Resposta rápida · Seg–Sex · 8h às 12h e 13h às 17h

→

](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)[

☎️

Telefone fixo

(67) 3305-0219

Seg–Sex · 8h às 12h e 13h às 17h

→

](tel:6733050219)[

📱

Celular

(67) 99916-0929

Seg–Sex · 8h às 12h e 13h às 17h

→

](tel:67999160929)[

📍

Endereço

Rua Doutor Arthur Jorge, 2523

Monte Castelo · Campo Grande-MS · CEP 79010-210

→

](https://maps.google.com/?q=Rua+Doutor+Arthur+Jorge+2523+Campo+Grande+MS)

🕐

Horário de Atendimento

Segunda a Sexta

8h às 12h · 13h às 17h

💳

### Formas de pagamento

Pix · Débito · Crédito em até 10x (taxa operadora) · Dinheiro  
Clínica particular — não atendemos convênios

### 📌 Como chegar

A clínica fica na Rua Doutor Arthur Jorge, 2523, no bairro Monte Castelo. Próximo à Av. Afonso Pena. Há estacionamento na rua.

Antes de entrar em contato

## Dúvidas frequentes  
sobre agendamento

Como faço para agendar uma consulta? +

O jeito mais rápido é pelo WhatsApp — mande uma mensagem para **(67) 99916-0929** e Emily vai confirmar o horário disponível. Você também pode ligar para **(67) 3305-0219**. O agendamento é feito de Segunda a Sexta feira · Das 8h às 12h e das 13h às 17h.

Preciso levar algum documento ou exame? +

Não é obrigatório mas facilita o cadastro em nosso sistema para a primeira consulta. Se você tiver exames anteriores relacionados ao problema — como exame micológico para fungo, ou histórico de tratamentos — traga para que a podóloga possa avaliar o histórico completo. Diabéticos devem trazer resultados recentes de glicemia quando disponíveis.

Vocês atendem por convênio ou plano de saúde? +

A clínica é particular. Aceitamos Pix, débito e crédito em até 10 vezes (sujeito à taxa da operadora). Se você tiver plano de saúde com cobertura para podologia, pode solicitar reembolso diretamente à sua operadora — **emitimos nota fiscal de todos os serviços prestados.**

Qual o valor da consulta? +

A consulta inicial custa **R$ 150** e é isenta quando o tratamento é iniciado na mesma sessão. A podoprofilaxia tem valor **a partir de R$ 200,00**. Tratamentos específicos como fungos, verruga plantar e calosidades têm valores definidos na avaliação conforme a complexidade do caso. Não há cobrança surpresa — você recebe o plano completo com valores antes de iniciar qualquer procedimento.

Tem estacionamento próximo? +

Sim. Há vagas de estacionamento na própria Rua Doutor Arthur Jorge e nas ruas adjacentes. Temos uma vaga no interior do prédio disponível para pessoas com dificuldade de locomoção. A clínica fica no bairro Monte Castelo, entre as rua Alegrete e Dolor Ferreira de Andrade, de fácil acesso pela região central de Campo Grande.

Posso levar acompanhante na consulta? +

Sim. No atendimento infantil os pais ficam presentes durante toda a consulta — isso é parte do protocolo da clínica. Para adultos, acompanhantes são bem-vindos, especialmente idosos que precisam de suporte para locomoção.

📲 Fale com a gente agora

## Pronto para cuidar  
dos seus pés de verdade?

Mande uma mensagem pelo WhatsApp — Emily responde rápido e encontra o melhor horário para você. Primeira consulta com avaliação completa.

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.) [📞 (67) 3305-0219](tel:6733050219)

Seg–Sex · 8h às 12h e 13h às 17h  
Rua Doutor Arthur Jorge, 2523 · Monte Castelo · Campo Grande-MS

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD

---

## [Página 17] Política de privacidade - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/politica-de-privacidade
- **Profundidade:** 2
- **Descrição:** Ligue agora! Agendar Consulta 🔒 LGPD · Lei nº 13.709/2018 Política de Privacidade Clínica de Podologia Liana Gonçalves · Última atualização: abril de 2025 Esta política unificada cobre privacidade, cookies, dados de saúde e direitos do titular. Índice 1. Quem somos 2. Dados que coletamos 3. Como usamos os dados 4. Base legal (LGPD) 5. […]
- **Palavras:** 1623 | **Imagens:** 13 | **Links:** 26

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #1 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #2 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #3 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #4 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #5 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #6 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #7 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #8 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
> *Posição:* Posição #9 na página • Seção: Conteúdo da Página • Seção: Conteúdo da Página
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
> *Posição:* Posição #10 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 11]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #11 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 12]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #12 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 13]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #13 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

🔒 LGPD · Lei nº 13.709/2018

# Política de Privacidade

Clínica de Podologia Liana Gonçalves · Última atualização: abril de 2025  
Esta política unificada cobre privacidade, cookies, dados de saúde e direitos do titular.

## Índice

[1\. Quem somos](#pp-01) [2\. Dados que coletamos](#pp-02) [3\. Como usamos os dados](#pp-03) [4\. Base legal (LGPD)](#pp-04) [5\. Dados de saúde](#pp-05) [6\. Compartilhamento](#pp-06) [7\. Cookies e rastreamento](#pp-07) [8\. Retenção dos dados](#pp-08) [9\. Seus direitos](#pp-09) [10\. Segurança](#pp-10) [11\. Menores de idade](#pp-11) [12\. Alterações](#pp-12) [13\. Contato e DPO](#pp-13)

Seção 01

## Quem somos — Controlador dos dados

**Razão social:** HOSPITAL DO PÉ LTDA  
**Responsável:** Liana Gonçalves — Podóloga  
**Endereço:** Rua Doutor Arthur Jorge, 2523 · Monte Castelo · Campo Grande-MS · CEP 79010-210  
**Telefone:** (67) 3305-0219  
**WhatsApp:** (67) 99916-0929  
**Site:** www.podologialiana.com.br

Esta Política de Privacidade se aplica a todos os canais de atendimento da clínica: site, WhatsApp, formulários, atendimento presencial e qualquer outro meio pelo qual você compartilhe dados conosco.

Seção 02

## Quais dados coletamos

Coletamos dados em diferentes momentos do relacionamento com você:

-   **Dados de identificação:** nome completo, CPF (quando necessário para nota fiscal), data de nascimento.
-   **Dados de contato:** número de telefone/WhatsApp, endereço de e-mail.
-   **Dados de saúde (sensíveis):** histórico médico relevante para o tratamento, condições como diabetes, uso de medicamentos, alergias, resultados de exames — coletados exclusivamente para fins clínicos. Veja a Seção 5 para mais detalhes.
-   **Dados de navegação:** endereço IP, tipo de navegador, páginas visitadas, tempo de permanência — coletados automaticamente via cookies e ferramentas de análise. Veja a Seção 7.
-   **Dados de comunicação:** mensagens enviadas pelo WhatsApp, formulários de contato ou e-mail.
-   **Dados financeiros:** forma de pagamento utilizada. Não armazenamos dados de cartão de crédito — as transações são processadas diretamente pelas operadoras.

Seção 03

## Como e para que usamos seus dados

-   Agendamento, confirmação e gestão de consultas e procedimentos
-   Elaboração e manutenção do prontuário clínico
-   Comunicação sobre seu atendimento, retornos e orientações pós-procedimento
-   Envio de lembretes de consulta pelo WhatsApp (quando autorizado)
-   Emissão de nota fiscal e registro financeiro da clínica
-   Cumprimento de obrigações legais e regulatórias
-   Melhoria contínua dos serviços prestados
-   Análise de desempenho do site e campanhas de marketing digital (dados anonimizados ou pseudonimizados)

**Não utilizamos seus dados para fins comerciais não relacionados à sua saúde ou ao atendimento da clínica.** Não vendemos, alugamos ou cedemos dados a terceiros para fins de marketing.

Seção 04

## Base legal para o tratamento (LGPD)

Nos termos da Lei Geral de Proteção de Dados (Lei nº 13.709/2018), tratamos seus dados com base nas seguintes hipóteses legais:

-   **Execução de contrato (art. 7º, V):** para realizar o atendimento, procedimentos e serviços contratados por você.
-   **Consentimento (art. 7º, I e art. 11, I):** para dados sensíveis de saúde coletados no atendimento clínico, mediante consentimento expresso. Para comunicações de marketing, mediante opt-in.
-   **Obrigação legal (art. 7º, II):** para cumprimento de obrigações fiscais, trabalhistas e regulatórias aplicáveis à atividade clínica.
-   **Legítimo interesse (art. 7º, IX):** para análise de desempenho do site e melhoria dos serviços, desde que não prevaleça sobre seus direitos e liberdades fundamentais.
-   **Tutela da saúde (art. 11, II, f):** para dados de saúde necessários ao diagnóstico e tratamento, nos limites do exercício profissional regulamentado.

Seção 05

## Dados de saúde — tratamento especial

### 🩺 Dados sensíveis — proteção reforçada

Dados de saúde são classificados pela LGPD como dados pessoais sensíveis (art. 5º, II) e recebem proteção reforçada. Somente são coletados, armazenados e utilizados para fins estritamente clínicos, por profissional habilitado, mediante consentimento expresso do titular ou de seu responsável legal.

As informações de saúde coletadas durante o atendimento — histórico clínico, diagnósticos, procedimentos realizados, resultados de exames e evoluções — são registradas no prontuário do paciente e tratadas com sigilo profissional, nos termos da ética podológica e da legislação aplicável.

O prontuário do paciente é mantido pelo prazo mínimo de **5 anos** após o último atendimento, conforme orientações do Conselho Regional de Enfermagem e boas práticas da área de saúde. Após esse período, os dados são eliminados de forma segura.

O acesso ao prontuário é restrito à equipe clínica da clínica e, quando aplicável, a terceiros autorizados por você ou por obrigação legal.

Seção 06

## Compartilhamento de dados

Seus dados podem ser compartilhados nas seguintes situações:

-   **Parceiros de tecnologia:** ferramentas de agendamento, prontuário eletrônico, plataforma de site, Google Analytics e Google Ads — todos operando como operadores sob nossas instruções, com obrigações contratuais de proteção de dados.
-   **Autoridades públicas:** quando exigido por lei, decisão judicial ou regulatória.
-   **Outros profissionais de saúde:** apenas com sua autorização expressa, para fins de continuidade do tratamento (encaminhamentos, laudos).
-   **Laboratórios de análise:** para exames como o micológico, com os dados mínimos necessários para a realização do exame.

**Não compartilhamos seus dados com terceiros para fins comerciais ou de marketing sem seu consentimento explícito.**

Seção 07

## Cookies e tecnologias de rastreamento

Nosso site utiliza cookies — pequenos arquivos de texto armazenados no seu navegador — para melhorar sua experiência e analisar o desempenho do site. Abaixo estão os tipos de cookies utilizados:

Tipo

Finalidade

Exemplos

Duração

**Essenciais**

Funcionamento básico do site. Não podem ser desativados.

Sessão WordPress, segurança

Sessão

**Analíticos**

Análise de desempenho e comportamento de navegação (dados anonimizados)

Google Analytics (\_ga, \_gid)

Até 2 anos

**Marketing**

Mensuração de conversões de campanhas Google Ads e remarketing

Google Ads (\_gcl\_au, \_gcl\_aw)

Até 90 dias

**Funcionais**

Preferências do usuário e funcionalidades como chat

Plugin WhatsApp (joinchat)

Variável

**Como gerenciar cookies:** você pode configurar seu navegador para bloquear ou excluir cookies a qualquer momento. Isso pode afetar algumas funcionalidades do site. Nas configurações do Chrome, Firefox, Safari ou Edge, procure por "Cookies e dados do site" para gerenciar suas preferências.

Para optar por não ser rastreado pelo Google Analytics, instale o [complemento de desativação do Google Analytics](https://tools.google.com/dlpage/gaoptout).

Seção 08

## Por quanto tempo guardamos seus dados

-   **Prontuário clínico:** mínimo de 5 anos após o último atendimento, conforme boas práticas da área de saúde.
-   **Dados financeiros e fiscais:** 5 anos, conforme Código Tributário Nacional.
-   **Dados de navegação (cookies analíticos):** até 26 meses conforme política do Google Analytics.
-   **Comunicações por WhatsApp:** mantidas enquanto necessário para o relacionamento e atendimento.
-   **Dados de marketing (Google Ads):** até 90 dias conforme configuração padrão da plataforma.

Ao término do prazo aplicável, os dados são eliminados ou anonimizados, salvo obrigação legal de retenção.

Seção 09

## Seus direitos como titular de dados

A LGPD garante a você os seguintes direitos, que podem ser exercidos a qualquer momento mediante solicitação à clínica:

-   **Confirmação e acesso (art. 18, I e II):** confirmar se tratamos seus dados e acessar uma cópia deles.
-   **Correção (art. 18, III):** solicitar a correção de dados incompletos, inexatos ou desatualizados.
-   **Anonimização, bloqueio ou eliminação (art. 18, IV):** de dados desnecessários, excessivos ou tratados em desconformidade com a LGPD.
-   **Portabilidade (art. 18, V):** receber seus dados em formato estruturado para transferência a outro prestador, quando aplicável.
-   **Eliminação (art. 18, VI):** dos dados tratados com base no consentimento, salvo obrigação legal de retenção.
-   **Informação sobre compartilhamento (art. 18, VII):** saber com quais entidades compartilhamos seus dados.
-   **Revogação do consentimento (art. 18, IX):** retirar seu consentimento a qualquer momento, sem prejuízo do tratamento realizado anteriormente.
-   **Oposição (art. 18, § 2º):** se discordar de algum tratamento realizado com base em legítimo interesse.
-   **Reclamação à ANPD:** você tem o direito de apresentar reclamação à Autoridade Nacional de Proteção de Dados (www.gov.br/anpd).

Para exercer qualquer direito, entre em contato pelo WhatsApp **(67) 99916-0929** ou pelo e-mail da clínica. Responderemos em até **15 dias úteis**.

Seção 10

## Segurança dos dados

Adotamos medidas técnicas e organizacionais adequadas para proteger seus dados contra acesso não autorizado, perda, alteração ou divulgação indevida:

-   Acesso restrito ao prontuário — apenas equipe clínica autorizada
-   Site com certificado SSL (protocolo HTTPS) para criptografia de dados em trânsito
-   Hospedagem em servidor com backups regulares
-   Comunicações por WhatsApp com criptografia de ponta a ponta
-   Senhas de sistemas internos gerenciadas com controle de acesso

Em caso de incidente de segurança que possa acarretar risco ou dano relevante aos titulares, comunicaremos a ANPD e os afetados nos prazos previstos pela LGPD.

Seção 11

## Menores de idade

Atendemos crianças e adolescentes mediante consentimento expresso dos pais ou responsáveis legais. Os dados de saúde de menores são tratados com o mesmo rigor aplicado aos adultos, com proteção reforçada prevista no art. 14 da LGPD e no Estatuto da Criança e do Adolescente.

Não coletamos dados de menores de 18 anos de forma autônoma — qualquer dado é coletado com ciência e autorização do responsável legal, presente durante o atendimento.

Seção 12

## Alterações nesta política

Esta política pode ser atualizada periodicamente para refletir mudanças na legislação, nas práticas da clínica ou nos serviços prestados. A data da última atualização sempre será indicada no topo desta página.

Alterações relevantes serão comunicadas por WhatsApp ou e-mail aos pacientes ativos. O uso continuado dos nossos serviços após a publicação de alterações implica aceitação da nova versão.

**Versão atual:** 2.1 · Publicada em abril de 2025.

Seção 13

## Contato e Encarregado de Dados (DPO)

Para exercer seus direitos, esclarecer dúvidas sobre esta política ou reportar qualquer preocupação sobre privacidade, entre em contato:

📋

### Clínica de Podologia Liana Gonçalves

📍 Rua Doutor Arthur Jorge, 2523 · Monte Castelo · Campo Grande-MS · CEP 79010-210

📞 [(67) 3305-0219](tel:+556733050219)

📲 [(67) 99916-0929](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Tenho%20uma%20d%C3%BAvida%20sobre%20a%20Pol%C3%ADtica%20de%20Privacidade.)

Atendemos solicitações de titulares em até 15 dias úteis · Seg–Sex · 8h às 12h e das 13h às 17h

### 🏛️ Autoridade Nacional de Proteção de Dados (ANPD)

Se considerar que seus direitos não foram atendidos adequadamente, você pode registrar reclamação na ANPD: **www.gov.br/anpd**

**Última atualização:** abril de 2025 · **Versão:** 2.1  
Esta política foi elaborada em conformidade com a Lei Geral de Proteção de Dados Pessoais (Lei nº 13.709/2018) e o Marco Civil da Internet (Lei nº 12.965/2014).

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD

---

## [Página 18] Página não encontrada - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/fungos-nas-unhas
- **Profundidade:** 3
- **Palavras:** 196 | **Imagens:** 13 | **Links:** 22

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Imagem do site
> *Posição:* Posição #1 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Imagem do site
> *Posição:* Posição #2 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Imagem do site
> *Posição:* Posição #3 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Imagem do site
> *Posição:* Posição #4 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Imagem do site
> *Posição:* Posição #5 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Imagem do site
> *Posição:* Posição #6 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Imagem do site
> *Posição:* Posição #7 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Imagem do site
> *Posição:* Posição #8 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Imagem do site
> *Posição:* Posição #9 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Texto Alt: "Clínica de Podologia Liana Gonçalves"
> *Posição:* Posição #10 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 11]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #11 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 12]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #12 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 13]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #13 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

# A página não pode ser encontrada.

Parece que nada foi encontrado neste local.

---

## [Página 19] Página não encontrada - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/pe-do-diabetico
- **Profundidade:** 3
- **Palavras:** 196 | **Imagens:** 13 | **Links:** 22

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Imagem do site
> *Posição:* Posição #1 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Imagem do site
> *Posição:* Posição #2 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Imagem do site
> *Posição:* Posição #3 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Imagem do site
> *Posição:* Posição #4 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Imagem do site
> *Posição:* Posição #5 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Imagem do site
> *Posição:* Posição #6 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Imagem do site
> *Posição:* Posição #7 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Imagem do site
> *Posição:* Posição #8 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Imagem do site
> *Posição:* Posição #9 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Texto Alt: "Clínica de Podologia Liana Gonçalves"
> *Posição:* Posição #10 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 11]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #11 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 12]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #12 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 13]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #13 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

# A página não pode ser encontrada.

Parece que nada foi encontrado neste local.

---

## [Página 20] Página não encontrada - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/verruga-plantar
- **Profundidade:** 3
- **Palavras:** 196 | **Imagens:** 13 | **Links:** 22

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Imagem do site
> *Posição:* Posição #1 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Imagem do site
> *Posição:* Posição #2 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Imagem do site
> *Posição:* Posição #3 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Imagem do site
> *Posição:* Posição #4 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Imagem do site
> *Posição:* Posição #5 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Imagem do site
> *Posição:* Posição #6 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Imagem do site
> *Posição:* Posição #7 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Imagem do site
> *Posição:* Posição #8 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Imagem do site
> *Posição:* Posição #9 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Texto Alt: "Clínica de Podologia Liana Gonçalves"
> *Posição:* Posição #10 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 11]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #11 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 12]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #12 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 13]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #13 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

# A página não pode ser encontrada.

Parece que nada foi encontrado neste local.

---

## [Página 21] Página não encontrada - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/podopediatria
- **Profundidade:** 3
- **Palavras:** 196 | **Imagens:** 13 | **Links:** 22

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Imagem do site
> *Posição:* Posição #1 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Imagem do site
> *Posição:* Posição #2 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Imagem do site
> *Posição:* Posição #3 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Imagem do site
> *Posição:* Posição #4 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Imagem do site
> *Posição:* Posição #5 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Imagem do site
> *Posição:* Posição #6 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Imagem do site
> *Posição:* Posição #7 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Imagem do site
> *Posição:* Posição #8 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Imagem do site
> *Posição:* Posição #9 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Texto Alt: "Clínica de Podologia Liana Gonçalves"
> *Posição:* Posição #10 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 11]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #11 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 12]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #12 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 13]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #13 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

# A página não pode ser encontrada.

Parece que nada foi encontrado neste local.

---

## [Página 22] Página não encontrada - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/whatsapp-float
- **Profundidade:** 3
- **Palavras:** 196 | **Imagens:** 13 | **Links:** 22

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Imagem do site
> *Posição:* Posição #1 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Imagem do site
> *Posição:* Posição #2 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Imagem do site
> *Posição:* Posição #3 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Imagem do site
> *Posição:* Posição #4 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Imagem do site
> *Posição:* Posição #5 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Imagem do site
> *Posição:* Posição #6 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Imagem do site
> *Posição:* Posição #7 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Imagem do site
> *Posição:* Posição #8 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Imagem do site
> *Posição:* Posição #9 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Texto Alt: "Clínica de Podologia Liana Gonçalves"
> *Posição:* Posição #10 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 11]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #11 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 12]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #12 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 13]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #13 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

# A página não pode ser encontrada.

Parece que nada foi encontrado neste local.

---

## [Página 23] Podologia Clínica - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/podologia-clinica
- **Profundidade:** 3
- **Descrição:** Ela achava que o bebê tinha cólica. A dor vinha de outro lugar. Quando a causa mais improvável é a que ninguém pensa em checar — e a que mais alivia quando finalmente é tratada. Categoria: PodopediatriaTempo de leitura: 6 min Eram três da manhã quando a Juliana chegou no consultório com o celular cheio […]
- **Autor:** maklen
- **Palavras:** 1188 | **Imagens:** 17 | **Links:** 23

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #1 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #2 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #3 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #4 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #5 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #6 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #7 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #8 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #9 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podologia Liana Gonçalve"
> *Posição:* Posição #10 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 11]** Texto Alt: "Social Meta Image (og:image)" | Título: "og:image" | Contexto: "Meta tag og:image"
> *Posição:* Posição #11 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image)](images/img_063_Imagem-do-WhatsApp-de-2023-10-24-as-11_37_07_33072c7a.jpg)

> **[Imagem 12]** Texto Alt: "Social Meta Image (og:image:width)" | Título: "og:image:width" | Contexto: "Meta tag og:image:width"
> *Posição:* Posição #12 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:width)](1040)

> **[Imagem 13]** Texto Alt: "Social Meta Image (og:image:height)" | Título: "og:image:height" | Contexto: "Meta tag og:image:height"
> *Posição:* Posição #13 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:height)](780)

> **[Imagem 14]** Texto Alt: "Social Meta Image (og:image:type)" | Título: "og:image:type" | Contexto: "Meta tag og:image:type"
> *Posição:* Posição #14 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:type)](image/jpeg)

> **[Imagem 15]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #15 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 16]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #16 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 17]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #17 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

# Podologia Clínica

# Ela achava que o bebê tinha cólica. A dor vinha de outro lugar.

Quando a causa mais improvável é a que ninguém pensa em checar — e a que mais alivia quando finalmente é tratada.

Categoria: PodopediatriaTempo de leitura: 6 min

---

Eram três da manhã quando a Juliana chegou no consultório com o celular cheio de anotações. Horário das mamadas, horário do choro, duração de cada crise. Duas semanas de choro. Ela tinha certeza: era cólica.

O bebê tinha 23 dias. Chorava em momentos que pareciam aleatórios, mas com uma intensidade que ia além do desconforto digestivo normal. O pediatra já tinha descartado infecção. A gastroenterologista havia passado seis tipos de fórmulas diferentes. Nada resolvia.

Quando examinei o pé direito do bebê, encontrei em trinta segundos o que duas semanas de consultas não haviam identificado: a borda da unha do dedão estava encravada no tecido lateral. A pele ao redor estava vermelha, levemente inchada. Sem secreção — ainda era cedo. Mas dolorosa o suficiente para despertar qualquer recém-nascido.

Juliana olhou para mim e perguntou: “Isso pode causar todo esse choro?”

Pode. E causa com mais frequência do que qualquer um imagina.

A dor de uma unha encravada em bebê é real, intensa — e completamente invisível para quem não sabe onde procurar.

## Por que o dedão do seu bebê pode estar doendo agora

Quando pensamos em unha encravada, pensamos em adulto, calçado apertado, corte errado. Em bebês, a lógica é completamente diferente — e mais difícil de suspeitar justamente por isso.

As unhas dos recém-nascidos são finas, maleáveis, e crescem numa velocidade surpreendente. Em alguns bebês, especialmente nas primeiras semanas de vida, a pele ao redor do dedão se forma mais espessa, mais “envolvente” do que a unha consegue empurrar. O resultado: a borda lateral da unha começa a pressionar o tecido sem que nenhum adulto tenha feito nada de errado.

Não é culpa de como você cortou a unha. Não é culpa do tamanho da meia. É anatomia — e acontece em bebês perfeitamente saudáveis, de famílias que cuidam muito bem dos seus filhos.

O problema é que ninguém ensina os pais a procurar isso. E o bebê não consegue apontar onde dói.

## O que você está vendo — e interpretando errado

O choro de um bebê com unha encravada tem uma característica: piora nos momentos de contato com o pé. Quando você coloca a meia, quando veste o macacão, quando segura o pezinho para trocar a fralda. Mas como esses momentos acontecem junto com outras atividades — a troca geralmente antecede a mamada, a mamada antecede o sono — a conexão raramente é feita.

Os sinais que merecem atenção:

-   Choro intenso e desproporcional ao manusear ou vestir o pé
-   Vermelhidão na lateral do dedão — especialmente do lado interno
-   Inchaço pequeno ao redor da unha
-   Bebê que afasta o pé quando você toca a região
-   Febre sem outro foco identificado (sinal de que a infecção já começou)

**Atenção imediata** Se você observar secreção amarelada ou esverdeada ao redor da unha, a infecção já está instalada. Não espere — procure atendimento no mesmo dia.

## O instinto de resolver em casa — e por que ele pode piorar tudo

Entendo o impulso. Ver seu filho chorando e ter nas mãos uma tesoura, uma pomada, um YouTube cheio de tutoriais — a tentação é real.

Mas em bebês, a margem de erro é pequena demais.

Empurrar a pele para liberar a unha sem técnica adequada pode aprofundar o encravamento. Cortar a ponta da unha em ângulo errado cria uma espícula que vai encavar novamente em dias. Aplicar pomada sem resolver a causa é tratar o sintoma enquanto o problema avança.

E existe um risco que os pais raramente consideram: qualquer microlesão na pele de um recém-nascido é uma porta de entrada. A infecção que começa na lateral de uma unhinha pode progredir mais rápido do que em adultos, porque o sistema imune ainda está se calibrando.

Não é falta de habilidade — é que esse procedimento foi desenvolvido para ser feito por mãos treinadas, com instrumental adequado, em menos tempo do que você imagina.

## Como é o tratamento — e o que os pais sempre me dizem depois

Quando atendo um bebê com unha encravada, os pais entram tensos, segurando o filho como se qualquer movimento pudesse machucar ainda mais. O procedimento em recém-nascidos geralmente dura menos de um minuto.

Usamos técnica específica para a faixa etária — sem agulha injetável, com analgesia tópica quando necessário, com o bebê no colo de quem trouxe. O encravamento é resolvido, a área é tratada, e os pais recebem orientação detalhada sobre como cuidar em casa nos dias seguintes.

A frase que ouço com mais frequência quando termino é: “Não acredito que era isso.”

Não existe idade mínima para atendimento podológico. Já atendi bebês com dias de vida. O que existe é a crença equivocada de que podologia é coisa de adulto — e enquanto essa crença persiste, bebês continuam chorando por uma causa que tem solução em uma consulta.

## Uma última coisa

A Juliana voltou três dias depois da consulta. O bebê estava dormindo. Ela estava com sono — o tipo de sono que só vem depois que uma angústia que durava semanas finalmente termina.

“Ele dormiu a noite inteira”, ela disse.

Se você está lendo isso às três da manhã com um bebê no colo, verifique os pés antes de tentar mais uma coisa. Pode ser mais simples — e mais próximo — do que você imagina.

Seu bebê está chorando sem causa aparente?

Agende uma avaliação. O atendimento é rápido, os pais ficam presentes durante todo o procedimento, e o alívio geralmente é imediato.[Agendar pelo WhatsApp →](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Li%20o%20artigo%20sobre%20unha%20encravada%20em%20beb%C3%AA%20e%20gostaria%20de%20agendar%20uma%20consulta.)

Liana Gonçalves é podóloga com graduação pela Unicesumar, 15 anos de experiência clínica em Campo Grande-MS, e atendimento pediátrico desde recém-nascidos.

## Deixe um comentário [Cancelar resposta](/podologia-clinica/#respond)

O seu endereço de e-mail não será publicado. Campos obrigatórios são marcados com \*

Comentário \*

Nome \* 

E-mail \* 

Site 

 Salvar meus dados neste navegador para a próxima vez que eu comentar.

---

## [Página 24] Calo ou verruga plantar? Como diferenciar — e por que importa - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/calo-ou-verruga-plantar-como-diferenciar-e-por-que-importa
- **Profundidade:** 3
- **Descrição:** Categoria: DiagnósticoTempo de leitura: 3 min São duas das condições mais comuns dos pés — e duas das mais confundidas. Calo e verruga plantar têm aparência parecida, causam dor semelhante e ficam na mesma região do pé. Mas são condições completamente diferentes, com causas diferentes e tratamentos que não têm nada em comum. Tratar verruga […]
- **Autor:** maklen
- **Palavras:** 686 | **Imagens:** 17 | **Links:** 23

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #1 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #2 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #3 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #4 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #5 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #6 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #7 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #8 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #9 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podologia Liana Gonçalve"
> *Posição:* Posição #10 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 11]** Texto Alt: "Social Meta Image (og:image)" | Título: "og:image" | Contexto: "Meta tag og:image"
> *Posição:* Posição #11 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image)](images/img_066_IMG-20190207-WA0086.webp)

> **[Imagem 12]** Texto Alt: "Social Meta Image (og:image:width)" | Título: "og:image:width" | Contexto: "Meta tag og:image:width"
> *Posição:* Posição #12 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:width)](720)

> **[Imagem 13]** Texto Alt: "Social Meta Image (og:image:height)" | Título: "og:image:height" | Contexto: "Meta tag og:image:height"
> *Posição:* Posição #13 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:height)](1280)

> **[Imagem 14]** Texto Alt: "Social Meta Image (og:image:type)" | Título: "og:image:type" | Contexto: "Meta tag og:image:type"
> *Posição:* Posição #14 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:type)](image/webp)

> **[Imagem 15]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #15 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 16]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #16 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 17]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #17 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

# Calo ou verruga plantar? Como diferenciar — e por que importa

**Categoria:** Diagnóstico  
**Tempo de leitura:** 3 min

---

São duas das condições mais comuns dos pés — e duas das mais confundidas. Calo e verruga plantar têm aparência parecida, causam dor semelhante e ficam na mesma região do pé. Mas são condições completamente diferentes, com causas diferentes e tratamentos que não têm nada em comum.

Tratar verruga como calo — ou calo como verruga — significa meses sem resultado e, no caso da verruga, risco real de multiplicação.

## O que é cada um

**Calo (heloma):** espessamento da pele em resposta à pressão ou atrito repetitivo. É uma reação de proteção do organismo — a pele fica mais grossa numa área que está sendo sobrecarregada. Não tem componente viral.

**Verruga plantar (olho de peixe):** lesão causada pelo HPV (vírus do papiloma humano). O vírus infecta as células da pele e cria uma estrutura com capilares próprios. Por estar na planta do pé — área de pressão — cresce para dentro em vez de para fora.

## Como diferenciar em casa

Existem dois testes simples que ajudam na diferenciação:

### Teste da pressão

Pressione a lesão diretamente com o dedo:

-   **Dói com pressão direta?** Pode ser calo ou verruga
-   **Agora aperte lateralmente** (como se estivesse beliscando os lados da lesão)
-   **Dói mais com pressão lateral?** Provavelmente é calo com núcleo
-   **Dói mais com pressão direta, pressão lateral não muda nada?** Provavelmente é verruga plantar

### Observe a superfície

Com boa iluminação, observe a lesão de perto:

-   **Tem pontinhos escuros no centro** (como grãos de pimenta)? São capilares sanguíneos — sinal forte de verruga plantar
-   **Superfície lisa, sem pontinhos?** Mais provável que seja calo
-   **As linhas da pele passam por cima da lesão de forma contínua?** Calo. **As linhas da pele são interrompidas pela lesão?** Verruga

## Por que a diferença importa tanto

O tratamento do calo é mecânico — remoção da camada espessa e identificação do ponto de pressão causador.

O tratamento da verruga é viral — precisa eliminar as células infectadas pelo HPV, o que exige protocolo completamente diferente.

Se você tratar verruga com as técnicas usadas para calo — não vai eliminar o vírus. Vai irritar a lesão, possivelmente liberar partículas virais e facilitar a multiplicação para outras áreas do pé.

## Não tente diagnosticar sozinho

Os testes acima ajudam, mas não substituem avaliação clínica. Existem condições que imitam tanto calo quanto verruga — como psoríase plantar e outros tipos de ceratodermia. Se você tem dúvida, se a lesão está crescendo ou se você tem diabetes: vá ao podólogo antes de tentar qualquer coisa. O tratamento caseiro geralmente não funciona, procure um profissional competente.

---

_Liana Gonçalves é podóloga com 15 anos de experiência em Campo Grande-MS. Atende condições como calosidades, verrugas plantares, fungos e outras patologias dos pés._

**[Agendar avaliação pelo WhatsApp →](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Li%20o%20artigo%20sobre%20calo%20e%20verruga%20e%20gostaria%20de%20agendar%20uma%20avalia%C3%A7%C3%A3o.)**

## Deixe um comentário [Cancelar resposta](/calo-ou-verruga-plantar-como-diferenciar-e-por-que-importa/#respond)

O seu endereço de e-mail não será publicado. Campos obrigatórios são marcados com \*

Comentário \*

Nome \* 

E-mail \* 

Site 

 Salvar meus dados neste navegador para a próxima vez que eu comentar.

---

## [Página 25] Podoprofilaxia vs. pedicure: qual a diferença real? - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/podoprofilaxia-vs-pedicure-qual-a-diferenca-real
- **Profundidade:** 3
- **Descrição:** Categoria: PrevençãoTempo de leitura: 4 min A pergunta chega quase toda semana no consultório: “É a mesma coisa que pedicure, né?” Não é. E a diferença vai muito além do preço ou do ambiente onde é feito. Entender essa diferença pode proteger sua saúde — especialmente se você tem diabetes, circulação comprometida ou histórico de […]
- **Autor:** maklen
- **Palavras:** 842 | **Imagens:** 16 | **Links:** 23

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #1 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #2 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #3 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #4 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #5 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #6 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #7 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #8 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #9 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podologia Liana Gonçalve"
> *Posição:* Posição #10 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 11]** Texto Alt: "Social Meta Image (og:image)" | Título: "og:image" | Contexto: "Meta tag og:image"
> *Posição:* Posição #11 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image)](images/img_071_Design-sem-nome-1.png)

> **[Imagem 12]** Texto Alt: "Social Meta Image (og:image:width)" | Título: "og:image:width" | Contexto: "Meta tag og:image:width"
> *Posição:* Posição #12 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:width)](1080)

> **[Imagem 13]** Texto Alt: "Social Meta Image (og:image:type)" | Título: "og:image:type" | Contexto: "Meta tag og:image:type"
> *Posição:* Posição #13 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:type)](image/png)

> **[Imagem 14]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #14 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 15]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #15 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 16]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #16 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

# Podoprofilaxia vs. pedicure: qual a diferença real?

**Categoria:** Prevenção  
**Tempo de leitura:** 4 min

---

A pergunta chega quase toda semana no consultório: “É a mesma coisa que pedicure, né?” Não é. E a diferença vai muito além do preço ou do ambiente onde é feito. Entender essa diferença pode proteger sua saúde — especialmente se você tem diabetes, circulação comprometida ou histórico de problemas nos pés.

## O que é cada um

**Pedicure** é um serviço de beleza. O foco é estético: aparência das unhas, remoção de calosidades superficiais, hidratação. Não exige formação em saúde, não pressupõe avaliação clínica e não tem protocolo padronizado de segurança.

**Podoprofilaxia** é um procedimento clínico de saúde realizado por podólogo formado. O foco é preventivo: manutenção da saúde dos pés, identificação de patologias em estágio inicial e aplicação de técnica correta que evita danos.

## As diferenças que importam na prática

### Formação de quem faz

Podólogo tem curso técnico ou superior em Podologia, com disciplinas em anatomia, patologias dos pés, biomecânica, microbiologia e técnicas clínicas. Sabe o que está olhando quando examina um pé.

O profissional de pedicure tem formação em técnicas estéticas. Não tem preparo para identificar início de fungo, avaliar alterações de pele ou reconhecer sinais de comprometimento vascular.

### Instrumental e esterilização

Na podoprofilaxia clínica, todo instrumental é esterilizado em autoclave — o mesmo equipamento usado em clínicas médicas e odontológicas. Isso elimina risco de transmissão de fungos, bactérias e vírus entre pacientes.

Na pedicure convencional, o padrão de esterilização é variável. Muitos estabelecimentos usam desinfecção com álcool ou glutaraldeído — que não eliminam todos os patógenos, especialmente esporos fúngicos.

### Técnica de corte das unhas

O corte correto de unhas é reto, na altura adequada, respeitando a anatomia de cada dedo. Corte arredondado, muito curto ou em ângulo inadequado é uma das principais causas de unha encravada.

Na podoprofilaxia, o corte segue protocolo técnico. Na pedicure, o corte geralmente segue a preferência estética do cliente — que nem sempre é o que protege a saúde da unha.

### Avaliação preventiva

Essa é a diferença mais importante — e a mais invisível.

Durante a podoprofilaxia, a podóloga avalia ativamente cada pé: estado da pele, sinais de início de fungo, pontos de pressão inadequados, alterações de cor ou temperatura, condição das cutículas e região periungual. Muitos problemas são identificados nessa sessão antes que o paciente perceba qualquer sintoma.

Na pedicure, essa avaliação não existe. O profissional trata o que vê — sem o olhar clínico treinado para identificar o que ainda não é visível.

## Para quem a diferença é crítica

Para pessoas saudáveis, a escolha entre pedicure e podoprofilaxia é uma questão de preferência e prioridade entre saúde e estética. Mas para alguns grupos, a diferença pode ser séria:

**Diabéticos:** pedicure convencional não é indicada. O risco de corte inadvertido, infecção e complicações é alto demais. A podoprofilaxia com protocolo específico para diabéticos é a única forma segura de manutenção.

**Idosos:** pele mais fina, circulação reduzida e unhas mais espessas exigem técnica adaptada. O instrumental inadequado pode causar lesões que demoram muito para cicatrizar.

**Imunossuprimidos:** qualquer brecha na pele é porta de entrada para infecção. A esterilização adequada do instrumental não é opcional.

**Pacientes com histórico de fungo nas unhas:** usar o mesmo alicate ou espátula de outra pessoa sem esterilização em autoclave é o caminho mais rápido para reinfecção.

## Com que frequência fazer

Para adultos saudáveis: a cada 30 a 45 dias. Para diabéticos e idosos: mensalmente. A regularidade é o que transforma a podoprofilaxia em prevenção — fazer só quando o problema aparece é tratar, não prevenir.

---

_Liana Gonçalves é podóloga com graduação pela Unicesumar e 15 anos de experiência clínica em Campo Grande-MS. A podoprofilaxia é o serviço de maior volume da clínica._

**[Agendar sessão pelo WhatsApp →](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Li%20o%20artigo%20sobre%20podoprofilaxia%20e%20gostaria%20de%20agendar%20uma%20sess%C3%A3o.)**

## Deixe um comentário [Cancelar resposta](/podoprofilaxia-vs-pedicure-qual-a-diferenca-real/#respond)

O seu endereço de e-mail não será publicado. Campos obrigatórios são marcados com \*

Comentário \*

Nome \* 

E-mail \* 

Site 

 Salvar meus dados neste navegador para a próxima vez que eu comentar.

---

## [Página 26] O calçado certo pode evitar 70% dos problemas nos pés - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/o-calcado-certo-pode-evitar-70-dos-problemas-nos-pes
- **Profundidade:** 3
- **Descrição:** Categoria: PrevençãoTempo de leitura: 5 min A maioria dos problemas que chegam ao consultório de podologia tem uma coisa em comum: o calçado inadequado esteve presente muito antes do sintoma aparecer. Calos, calosidades, unhas encravadas, alterações de marcha em crianças — grande parte dessas condições se desenvolve lentamente, ao longo de meses ou anos de […]
- **Autor:** maklen
- **Palavras:** 818 | **Imagens:** 16 | **Links:** 23

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #1 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #2 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #3 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #4 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #5 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #6 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #7 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #8 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #9 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podologia Liana Gonçalve"
> *Posição:* Posição #10 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 11]** Texto Alt: "Social Meta Image (og:image)" | Título: "og:image" | Contexto: "Meta tag og:image"
> *Posição:* Posição #11 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image)](images/img_054_282207662_441098077826309_4659220234443228409_n.jpg)

> **[Imagem 12]** Texto Alt: "Social Meta Image (og:image:width)" | Título: "og:image:width" | Contexto: "Meta tag og:image:width"
> *Posição:* Posição #12 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:width)](864)

> **[Imagem 13]** Texto Alt: "Social Meta Image (og:image:type)" | Título: "og:image:type" | Contexto: "Meta tag og:image:type"
> *Posição:* Posição #13 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:type)](image/jpeg)

> **[Imagem 14]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #14 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 15]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #15 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 16]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #16 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

# O calçado certo pode evitar 70% dos problemas nos pés

**Categoria:** Prevenção  
**Tempo de leitura:** 5 min

---

A maioria dos problemas que chegam ao consultório de podologia tem uma coisa em comum: o calçado inadequado esteve presente muito antes do sintoma aparecer. Calos, calosidades, unhas encravadas, alterações de marcha em crianças — grande parte dessas condições se desenvolve lentamente, ao longo de meses ou anos de pressão no lugar errado.

A boa notícia é que mudar o calçado é uma das intervenções preventivas mais eficazes que existem. E você não precisa abrir mão de estética para isso.

## O que um calçado adequado precisa ter

### 1\. Espaço suficiente na ponta

A regra básica: deve haver um espaço de aproximadamente 1 cm entre o dedo mais longo e a ponta do calçado. Quando a ponta é muito estreita ou o calçado é curto demais, os dedos ficam comprimidos lateralmente — principal causa de calosidades entre os dedos e de desvio progressivo do hálux (que pode evoluir para joanete).

### 2\. Largura adequada na parte da frente

A parte mais larga do calçado deve corresponder à parte mais larga do pé — a região das cabeças dos metatarsos. Calçados estreitos nessa região comprimem a planta e redistribuem a pressão de forma inadequada, gerando calosidades e dor metatarsal.

### 3\. Solado com amortecimento e alguma flexibilidade

Solas completamente rígidas não absorvem impacto — toda a força da pisada vai para o pé. Solas com algum amortecimento reduzem a carga sobre o calcanhar e a região metatarsal. Atenção: sola muito mole também é problemática — falta de estabilidade força compensações na pisada.

### 4\. Salto de no máximo 3 cm para uso regular

Salto alto desloca o peso do corpo para a região da frente do pé, aumentando drasticamente a pressão sobre os metatarsos. Uso frequente de saltos acima de 5 cm está associado a calosidades, dor metatarsal, encurtamento do tendão de Aquiles e alterações posturais. Salto baixo de 1 a 3 cm é o ponto de equilíbrio para quem usa salto regularmente.

### 5\. Fixação adequada no pé

Calçado que não prende bem — sandálias que escorregam, tênis com cadarço frouxo — obriga os dedos a “agarrar” o chão para estabilizar a pisada. Esse padrão repetitivo pode causar contraturas nos dedos (dedo em garra, dedo em martelo) e calosidades nas pontas.

## Atenção especial: calçado infantil

Os pés das crianças estão em formação até os 18 anos. Calçado inadequado nessa fase pode moldar permanentemente a estrutura do pé adulto.

Pontos críticos para calçado infantil:

-   **Nunca comprar grande “para durar mais”** — o espaço em excesso causa instabilidade e compensações na pisada
-   **Solado flexível** — o pé da criança precisa dobrar naturalmente ao caminhar
-   **Sem salto** — nem aquele pequeno de 1 cm dos tênis de menina com plataforma
-   **Troca regular** — pés de crianças crescem rápido; checar o tamanho a cada 3 meses em crianças pequenas

## Quando o calçado correto não é suficiente

Em alguns casos, a estrutura do pé — deformidades ósseas, alteração de marcha, hiperpronação ou supinação — redistribui a pressão de forma que nenhum calçado de prateleira consegue corrigir adequadamente. Nesses casos, a avaliação podológica pode indicar palmilha personalizada ou orientações posturais específicas.

Se você tem calosidades de repetição no mesmo ponto, dor nos pés no fim do dia ou histórico de problemas recorrentes, o calçado pode ser parte da causa — e a avaliação clínica vai identificar o que precisa mudar.

---

_Liana Gonçalves é podóloga com 15 anos de experiência clínica em Campo Grande-MS. Em cada consulta, avalia o calçado do paciente como parte do protocolo de tratamento e prevenção._

**[Agendar avaliação pelo WhatsApp →](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Li%20o%20artigo%20sobre%20cal%C3%A7ado%20e%20gostaria%20de%20agendar%20uma%20consulta.)**

## Deixe um comentário [Cancelar resposta](/o-calcado-certo-pode-evitar-70-dos-problemas-nos-pes/#respond)

O seu endereço de e-mail não será publicado. Campos obrigatórios são marcados com \*

Comentário \*

Nome \* 

E-mail \* 

Site 

 Salvar meus dados neste navegador para a próxima vez que eu comentar.

---

## [Página 27] Pé diabético: os 5 sinais que pedem atenção imediata - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/pe-diabetico-os-5-sinais-que-pedem-atencao-imediata
- **Profundidade:** 3
- **Descrição:** Categoria: Pé do DiabéticoTempo de leitura: 7 min O pé diabético é uma das complicações mais sérias do diabetes — e uma das mais preveníveis. O problema é que ela avança silenciosamente. A neuropatia diabética compromete a sensibilidade dos pés, o que significa que feridas, pressões e infecções podem se desenvolver sem que o paciente […]
- **Autor:** maklen
- **Palavras:** 849 | **Imagens:** 17 | **Links:** 23

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #1 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #2 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #3 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #4 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #5 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #6 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #7 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #8 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #9 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podologia Liana Gonçalve"
> *Posição:* Posição #10 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 11]** Texto Alt: "Social Meta Image (og:image)" | Título: "og:image" | Contexto: "Meta tag og:image"
> *Posição:* Posição #11 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image)](images/img_075_Imagem-do-WhatsApp-de-2023-10-24-as-11_27_44_8181cf23-e16982.jpg)

> **[Imagem 12]** Texto Alt: "Social Meta Image (og:image:width)" | Título: "og:image:width" | Contexto: "Meta tag og:image:width"
> *Posição:* Posição #12 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:width)](1200)

> **[Imagem 13]** Texto Alt: "Social Meta Image (og:image:height)" | Título: "og:image:height" | Contexto: "Meta tag og:image:height"
> *Posição:* Posição #13 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:height)](797)

> **[Imagem 14]** Texto Alt: "Social Meta Image (og:image:type)" | Título: "og:image:type" | Contexto: "Meta tag og:image:type"
> *Posição:* Posição #14 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:type)](image/jpeg)

> **[Imagem 15]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #15 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 16]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #16 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 17]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #17 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

# Pé diabético: os 5 sinais que pedem atenção imediata

**Categoria:** Pé do Diabético  
**Tempo de leitura:** 7 min

---

O pé diabético é uma das complicações mais sérias do diabetes — e uma das mais preveníveis. O problema é que ela avança silenciosamente. A neuropatia diabética compromete a sensibilidade dos pés, o que significa que feridas, pressões e infecções podem se desenvolver sem que o paciente sinta nada.

Quando a dor aparece, o problema geralmente já está avançado.

É por isso que saber o que observar — mesmo sem sentir dor — é fundamental para qualquer pessoa com diabetes.

## Por que o pé do diabético é diferente

O diabetes afeta os pés de duas formas principais:

**Neuropatia periférica:** dano progressivo aos nervos que reduz ou elimina a sensibilidade. O pé para de avisar quando está sendo machucado.

**Doença arterial periférica:** redução do fluxo sanguíneo para os membros inferiores, o que compromete a cicatrização. Uma pequena ferida que em uma pessoa saudável fecharia em dias pode levar semanas — ou não fechar.

A combinação das duas é perigosa: o paciente não sente a ferida e o organismo tem dificuldade de curá-la.

## Os 5 sinais que pedem atenção imediata

### 1\. Qualquer ferida, corte ou bolha no pé

Em pessoas sem diabetes, um corte pequeno ou bolha é algo trivial. No pé diabético, pode ser o início de uma úlcera. Se você tem diabetes e notou qualquer solução de continuidade na pele dos pés — não importa o tamanho — procure avaliação profissional.

### 2\. Mudança de cor ou temperatura na pele

Pé mais vermelho, mais escuro ou com manchas arroxeadas pode indicar comprometimento circulatório ou processo infeccioso. Pé mais frio que o habitual pode sinalizar redução do fluxo sanguíneo. Compare um pé com o outro — diferenças visíveis pedem atenção.

### 3\. Inchaço sem causa aparente

Edema no pé ou tornozelo sem trauma associado pode indicar infecção, problema circulatório ou, em casos mais graves, fratura de Charcot — uma condição em que os ossos do pé se fragmentam sem dor perceptível.

### 4\. Calosidades espessas — especialmente no calcanhar e na planta

Calosidades em diabéticos aumentam a pressão sobre o tecido subjacente e podem esconder úlceras que estão se formando por baixo. Uma calosidade que parece inofensiva num leigo pode ser ponto crítico num diabético. **Nunca tente remover em casa.**

### 5\. Qualquer sinal de infecção

Vermelhidão que avança, calor local, secreção, odor e febre são sinais de infecção instalada. No pé diabético, infecções podem evoluir rapidamente para quadros graves. Se houver qualquer suspeita, não espere — procure atendimento no mesmo dia.

## Por que o acompanhamento mensal é obrigatório

A maioria das complicações graves do pé diabético começa com algo pequeno que passou despercebido. O acompanhamento mensal com podólogo especializado existe para identificar e tratar esses sinais antes que se tornem problemas sérios.

Na consulta mensal, Liana avalia:

-   Sensibilidade e circulação
-   Integridade da pele
-   Unhas e estado periungual
-   Calosidades e pontos de pressão
-   Calçado e adequação para o perfil do paciente

Não é rotina. É prevenção ativa.

## O que diabéticos nunca devem fazer nos próprios pés

-   Cortar as próprias unhas (risco de corte inadvertido na pele)
-   Usar produtos ácidos para calos ou verrugas
-   Andar descalço dentro ou fora de casa
-   Usar bolsa de água quente ou objetos aquecidos nos pés
-   Tratar qualquer condição dos pés sem supervisão profissional

## A classificação de risco importa — mas não define a frequência

Muitos pacientes acham que só precisam de acompanhamento intensivo se estiverem em “alto risco”. Na prática clínica, **todo diabético precisa de acompanhamento mensal** — independente da classificação de risco. A classificação orienta a abordagem, não a necessidade de cuidado.

---

_Liana Gonçalves é podóloga com pós-graduação em Diabetes e Complicações Crônicas e especialização em Semiologia do Pé Diabético. Atende em Campo Grande-MS há 15 anos._

**[Agendar acompanhamento pelo WhatsApp →](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Li%20o%20artigo%20sobre%20p%C3%A9%20diab%C3%A9tico%20e%20gostaria%20de%20agendar%20uma%20consulta.)**

## Deixe um comentário [Cancelar resposta](/pe-diabetico-os-5-sinais-que-pedem-atencao-imediata/#respond)

O seu endereço de e-mail não será publicado. Campos obrigatórios são marcados com \*

Comentário \*

Nome \* 

E-mail \* 

Site 

 Salvar meus dados neste navegador para a próxima vez que eu comentar.

---

## [Página 28] Unha encravada em bebê - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/unha-encravada-em-bebe
- **Profundidade:** 3
- **Descrição:** Unha encravada em bebê: como identificar e o que fazer Categoria: PodopediatriaTempo de leitura: 4 min Bebê chorando sem causa aparente é uma das situações mais angustiantes para qualquer pai ou mãe. Fome, sono, cólica — a lista de suspeitos habituais é sempre a mesma. Mas existe uma causa que raramente entra nessa lista, apesar […]
- **Autor:** maklen
- **Palavras:** 665 | **Imagens:** 16 | **Links:** 23

### 🖼️ Imagens da Página com Descrição e Posição

> **[Imagem 1]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #1 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 2]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #2 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 3]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #3 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 4]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #4 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 5]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #5 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 6]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #6 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 7]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #7 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 8]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #8 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 9]** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
> *Posição:* Posição #9 na página • Seção: Cabeçalho / Navegação (Header) • Seção: Cabeçalho / Navegação (Header)
![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

> **[Imagem 10]** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podologia Liana Gonçalve"
> *Posição:* Posição #10 na página • Seção: Rodapé (Footer) • Seção: Rodapé (Footer)
![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

> **[Imagem 11]** Texto Alt: "Social Meta Image (og:image)" | Título: "og:image" | Contexto: "Meta tag og:image"
> *Posição:* Posição #11 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image)](images/img_050_Design-sem.png)

> **[Imagem 12]** Texto Alt: "Social Meta Image (og:image:width)" | Título: "og:image:width" | Contexto: "Meta tag og:image:width"
> *Posição:* Posição #12 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:width)](1080)

> **[Imagem 13]** Texto Alt: "Social Meta Image (og:image:type)" | Título: "og:image:type" | Contexto: "Meta tag og:image:type"
> *Posição:* Posição #13 na página • Seção: Metadados & Redes Sociais • Seção: Metadados & Redes Sociais
![Social Meta Image (og:image:type)](image/png)

> **[Imagem 14]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #14 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

> **[Imagem 15]** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
> *Posição:* Posição #15 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

> **[Imagem 16]** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
> *Posição:* Posição #16 na página • Seção: Identidade Visual & Ícones • Seção: Identidade Visual & Ícones
![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)


### 📄 Conteúdo da Página

# Unha encravada em bebê

# Unha encravada em bebê: como identificar e o que fazer

**Categoria:** Podopediatria  
**Tempo de leitura:** 4 min

---

Bebê chorando sem causa aparente é uma das situações mais angustiantes para qualquer pai ou mãe. Fome, sono, cólica — a lista de suspeitos habituais é sempre a mesma. Mas existe uma causa que raramente entra nessa lista, apesar de ser surpreendentemente comum: **a unha encravada**.

## Por que bebês têm unha encravada?

A maioria das pessoas associa unha encravada a adultos que cortam a unha errado ou usam calçado apertado. Em bebês, a causa é diferente — e mais simples.

As unhas dos recém-nascidos são muito finas, maleáveis e crescem rapidamente. Em alguns bebês, especialmente nas primeiras semanas de vida, a pele ao redor do dedão do pé fica mais espessa e envolvente do que a unha consegue empurrar — o que faz com que a borda da unha se encrave no tecido lateral espontaneamente, sem nenhuma intervenção externa.

Não é culpa do corte. Não é culpa do calçado. É anatomia.

## Como identificar

O bebê não consegue dizer onde dói. Os sinais que pedem atenção são:

-   **Choro intenso sem causa aparente**, especialmente ao calçar meia ou roupa no pé
-   **Vermelhidão** na lateral do dedão do pé
-   **Inchaço** na região periungual
-   **Febre** sem outro foco identificado — pode indicar infecção instalada
-   O bebê **afasta o pé** quando você toca a região

Se o dedo estiver com secreção amarelada ou esverdeada, a infecção já está presente e o atendimento deve ser ainda mais imediato.

## O que não fazer

A primeira reação de muitos pais é tentar resolver em casa — empurrar a pele, cortar a ponta da unha, aplicar pomada. Esses procedimentos, sem técnica adequada, podem piorar o encravamento, machucar o tecido e transformar um caso simples em um caso com infecção.

**Não tente remover em casa.** Em bebês especialmente, a margem de erro é pequena.

## Como é o tratamento

Em nossa clínica, o tratamento de unha encravada em bebês é rápido, seguro e feito com os pais presentes — sem exceção.

O procedimento em recém-nascidos e bebês pequenos geralmente dura menos de 1 minuto. Usamos técnica específica para a faixa etária, com analgesia tópica quando necessário, sem agulha injetável. Na maioria dos casos, o alívio é imediato.

Os pais recebem orientações detalhadas sobre como cuidar em casa, como fazer o curativo e o que observar nos dias seguintes.

## A partir de que idade é possível tratar?

Desde o nascimento. Não existe idade mínima para o atendimento podológico. Já atendemos bebês com poucos dias de vida.

---

_Liana Gonçalves é podóloga com 15 anos de experiência, atendendo crianças desde recém-nascidos. Atua em Campo Grande-MS._

**[Agendar consulta pelo WhatsApp →](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Li%20o%20artigo%20sobre%20unha%20encravada%20em%20beb%C3%AA%20e%20gostaria%20de%20agendar%20uma%20consulta.)**

## Deixe um comentário [Cancelar resposta](/unha-encravada-em-bebe/#respond)

O seu endereço de e-mail não será publicado. Campos obrigatórios são marcados com \*

Comentário \*

Nome \* 

E-mail \* 

Site 

 Salvar meus dados neste navegador para a próxima vez que eu comentar.

---

