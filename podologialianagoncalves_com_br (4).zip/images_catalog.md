# 🖼️ Catálogo de Imagens Extraídas: podologialianagoncalves_com_br

Total de imagens baixadas e salvas na pasta `images/`: **75**

---

### 1. `img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png`

- **Arquivo:** `images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png`
- **Descrição:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
- **Posição na Página:** Posição #1 na página • Seção: Conteúdo da Página
- **Seção Semântica:** `Conteúdo da Página`
- **Seletor CSS:** `div.elementor-column > div.elementor-widget-wrap > div.elementor-element > a > img.attachment-large`
- **Formato / Tamanho:** PNG (19.8 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.png](https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/](https://podologialianagoncalves.com.br/)

![Imagem extraída](images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

---

### 2. `img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png`

- **Arquivo:** `images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png`
- **Descrição:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
- **Posição na Página:** Posição #2 na página • Seção: Conteúdo da Página
- **Seção Semântica:** `Conteúdo da Página`
- **Seletor CSS:** `div.elementor-column > div.elementor-widget-wrap > div.elementor-element > a > img.attachment-large`
- **Formato / Tamanho:** PNG (5.5 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-300x133.png](https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-300x133.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/](https://podologialianagoncalves.com.br/)

![Imagem extraída](images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

---

### 3. `img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png`

- **Arquivo:** `images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png`
- **Descrição:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
- **Posição na Página:** Posição #3 na página • Seção: Conteúdo da Página
- **Seção Semântica:** `Conteúdo da Página`
- **Seletor CSS:** `div.elementor-column > div.elementor-widget-wrap > div.elementor-element > a > img.attachment-large`
- **Formato / Tamanho:** PNG (14.1 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-768x340.png](https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-768x340.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/](https://podologialianagoncalves.com.br/)

![Imagem extraída](images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

---

### 4. `img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png`

- **Arquivo:** `images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png`
- **Descrição:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
- **Posição na Página:** Posição #4 na página • Seção: Conteúdo da Página
- **Seção Semântica:** `Conteúdo da Página`
- **Seletor CSS:** `div.elementor-column > div.elementor-widget-wrap > div.elementor-element > a > img.attachment-large`
- **Formato / Tamanho:** PNG (30.9 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1536x680.png](https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1536x680.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/](https://podologialianagoncalves.com.br/)

![Imagem extraída](images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

---

### 5. `img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png`

- **Arquivo:** `images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png`
- **Descrição:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
- **Posição na Página:** Posição #5 na página • Seção: Conteúdo da Página
- **Seção Semântica:** `Conteúdo da Página`
- **Seletor CSS:** `div.elementor-column > div.elementor-widget-wrap > div.elementor-element > a > img.attachment-large`
- **Formato / Tamanho:** PNG (40.4 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-2048x906.png](https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-2048x906.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/](https://podologialianagoncalves.com.br/)

![Imagem extraída](images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

---

### 6. `img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png`

- **Arquivo:** `images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png`
- **Descrição:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
- **Posição na Página:** Posição #6 na página • Seção: Conteúdo da Página
- **Seção Semântica:** `Conteúdo da Página`
- **Seletor CSS:** `div.elementor-column > div.elementor-widget-wrap > div.elementor-element > a > img.attachment-large`
- **Formato / Tamanho:** PNG (19.2 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1000x442.png](https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1000x442.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/](https://podologialianagoncalves.com.br/)

![Imagem extraída](images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

---

### 7. `img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png`

- **Arquivo:** `images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png`
- **Descrição:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
- **Posição na Página:** Posição #7 na página • Seção: Conteúdo da Página
- **Seção Semântica:** `Conteúdo da Página`
- **Seletor CSS:** `div.elementor-column > div.elementor-widget-wrap > div.elementor-element > a > img.attachment-large`
- **Formato / Tamanho:** PNG (4.1 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-230x102.png](https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-230x102.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/](https://podologialianagoncalves.com.br/)

![Imagem extraída](images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

---

### 8. `img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png`

- **Arquivo:** `images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png`
- **Descrição:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
- **Posição na Página:** Posição #8 na página • Seção: Conteúdo da Página
- **Seção Semântica:** `Conteúdo da Página`
- **Seletor CSS:** `div.elementor-column > div.elementor-widget-wrap > div.elementor-element > a > img.attachment-large`
- **Formato / Tamanho:** PNG (6.4 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-350x155.png](https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-350x155.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/](https://podologialianagoncalves.com.br/)

![Imagem extraída](images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

---

### 9. `img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png`

- **Arquivo:** `images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png`
- **Descrição:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
- **Posição na Página:** Posição #9 na página • Seção: Conteúdo da Página
- **Seção Semântica:** `Conteúdo da Página`
- **Seletor CSS:** `div.elementor-column > div.elementor-widget-wrap > div.elementor-element > a > img.attachment-large`
- **Formato / Tamanho:** PNG (9.0 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-480x212.png](https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-480x212.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/](https://podologialianagoncalves.com.br/)

![Imagem extraída](images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

---

### 10. `img_010_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399.jpg`

- **Arquivo:** `images/img_010_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399.jpg`
- **Descrição:** Contexto: "<img decoding="async" width="720" height="980" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175282399.jpeg" cla"
- **Posição na Página:** Posição #10 na página • Seção: Conteúdo da Página • Sob H1: Seus Pés Merecem Cuidado Clínico. Não Improvisação.
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H1: Seus Pés Merecem Cuidado Clínico. Não Improvisação.
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** JPG (55.8 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175282399.jpeg](https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175282399.jpeg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/](https://podologialianagoncalves.com.br/)

![Imagem extraída](images/img_010_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399.jpg)

---

### 11. `img_011_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399-220x300.jpg`

- **Arquivo:** `images/img_011_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399-220x300.jpg`
- **Descrição:** Contexto: "<img decoding="async" width="720" height="980" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175282399.jpeg" cla"
- **Posição na Página:** Posição #11 na página • Seção: Conteúdo da Página • Sob H1: Seus Pés Merecem Cuidado Clínico. Não Improvisação.
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H1: Seus Pés Merecem Cuidado Clínico. Não Improvisação.
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** JPG (8.6 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175282399-220x300.jpeg](https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175282399-220x300.jpeg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/](https://podologialianagoncalves.com.br/)

![Imagem extraída](images/img_011_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399-220x300.jpg)

---

### 12. `img_012_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png`

- **Arquivo:** `images/img_012_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png`
- **Descrição:** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-remove"
- **Posição na Página:** Posição #12 na página • Seção: Conteúdo da Página • Sob H2: A Profissional que Cuida dos seus Pés
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: A Profissional que Cuida dos seus Pés
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-large`
- **Formato / Tamanho:** PNG (260.6 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-removebg-preview.png](https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-removebg-preview.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/](https://podologialianagoncalves.com.br/)

![Imagem extraída](images/img_012_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png)

---

### 13. `img_013_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png`

- **Arquivo:** `images/img_013_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png`
- **Descrição:** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-remove"
- **Posição na Página:** Posição #13 na página • Seção: Conteúdo da Página • Sob H2: A Profissional que Cuida dos seus Pés
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: A Profissional que Cuida dos seus Pés
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-large`
- **Formato / Tamanho:** PNG (24.5 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-removebg-preview-225x300.png](https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-removebg-preview-225x300.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/](https://podologialianagoncalves.com.br/)

![Imagem extraída](images/img_013_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png)

---

### 14. `img_014_Clinica_de_Podologia_Liana_Goncalves.png`

- **Arquivo:** `images/img_014_Clinica_de_Podologia_Liana_Goncalves.png`
- **Descrição:** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
- **Posição na Página:** Posição #14 na página • Seção: Rodapé (Footer)
- **Seção Semântica:** `Rodapé (Footer)`
- **Seletor CSS:** `footer.ftr-body > div.ftr-body-inner > div.ftr-brand > a.ftr-logo > img`
- **Formato / Tamanho:** PNG (10.3 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png](https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/](https://podologialianagoncalves.com.br/)

![Clínica de Podologia Liana Gonçalves](images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

---

### 15. `img_015_Icone_Favicon_do_Site_icon.png`

- **Arquivo:** `images/img_015_Icone_Favicon_do_Site_icon.png`
- **Descrição:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
- **Posição na Página:** Posição #15 na página • Seção: Identidade Visual & Ícones
- **Seção Semântica:** `Identidade Visual & Ícones`
- **Seletor CSS:** `link[rel="icon"]`
- **Formato / Tamanho:** PNG (0.4 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2019/05/cropped-LogoMakr_5jhcfw-32x32.png](https://podologialianagoncalves.com.br/wp-content/uploads/2019/05/cropped-LogoMakr_5jhcfw-32x32.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/](https://podologialianagoncalves.com.br/)

![Ícone / Favicon do Site (icon)](images/img_015_Icone_Favicon_do_Site_icon.png)

---

### 16. `img_016_Icone_Favicon_do_Site_icon.png`

- **Arquivo:** `images/img_016_Icone_Favicon_do_Site_icon.png`
- **Descrição:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
- **Posição na Página:** Posição #16 na página • Seção: Identidade Visual & Ícones
- **Seção Semântica:** `Identidade Visual & Ícones`
- **Seletor CSS:** `link[rel="icon"]`
- **Formato / Tamanho:** PNG (3.0 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2019/05/cropped-LogoMakr_5jhcfw-192x192.png](https://podologialianagoncalves.com.br/wp-content/uploads/2019/05/cropped-LogoMakr_5jhcfw-192x192.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/](https://podologialianagoncalves.com.br/)

![Ícone / Favicon do Site (icon)](images/img_016_Icone_Favicon_do_Site_icon.png)

---

### 17. `img_017_Icone_Favicon_do_Site_apple-touch-icon.png`

- **Arquivo:** `images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png`
- **Descrição:** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
- **Posição na Página:** Posição #17 na página • Seção: Identidade Visual & Ícones
- **Seção Semântica:** `Identidade Visual & Ícones`
- **Seletor CSS:** `link[rel="apple-touch-icon"]`
- **Formato / Tamanho:** PNG (2.7 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2019/05/cropped-LogoMakr_5jhcfw-180x180.png](https://podologialianagoncalves.com.br/wp-content/uploads/2019/05/cropped-LogoMakr_5jhcfw-180x180.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/](https://podologialianagoncalves.com.br/)

![Ícone / Favicon do Site (apple-touch-icon)](images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)

---

### 18. `img_018_WhatsApp-Image-2026-03-09-at-10_41_27-1-e1773675928249.jpg`

- **Arquivo:** `images/img_018_WhatsApp-Image-2026-03-09-at-10_41_27-1-e1773675928249.jpg`
- **Descrição:** Contexto: "<img loading="lazy" decoding="async" width="400" height="548" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-09-at-10.41.27-1-e177367"
- **Posição na Página:** Posição #14 na página • Seção: Conteúdo da Página • Sob H3: Marciana Soares
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H3: Marciana Soares
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-2048x2048`
- **Formato / Tamanho:** JPG (28.1 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-09-at-10.41.27-1-e1773675928249.jpeg](https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-09-at-10.41.27-1-e1773675928249.jpeg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/sobre-nos](https://podologialianagoncalves.com.br/sobre-nos)

![Imagem extraída](images/img_018_WhatsApp-Image-2026-03-09-at-10_41_27-1-e1773675928249.jpg)

---

### 19. `img_019_WhatsApp-Image-2026-03-16-at-10_59_13-e1773675323462.jpg`

- **Arquivo:** `images/img_019_WhatsApp-Image-2026-03-16-at-10_59_13-e1773675323462.jpg`
- **Descrição:** Contexto: "<img loading="lazy" decoding="async" width="400" height="548" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.13-e17736753"
- **Posição na Página:** Posição #15 na página • Seção: Conteúdo da Página • Sob H3: Jocineia
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H3: Jocineia
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-2048x2048`
- **Formato / Tamanho:** JPG (24.8 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.13-e1773675323462.jpeg](https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.13-e1773675323462.jpeg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/sobre-nos](https://podologialianagoncalves.com.br/sobre-nos)

![Imagem extraída](images/img_019_WhatsApp-Image-2026-03-16-at-10_59_13-e1773675323462.jpg)

---

### 20. `img_020_WhatsApp-Image-2026-03-16-at-10_59_13-e1773675323462-219x300.jpg`

- **Arquivo:** `images/img_020_WhatsApp-Image-2026-03-16-at-10_59_13-e1773675323462-219x300.jpg`
- **Descrição:** Contexto: "<img loading="lazy" decoding="async" width="400" height="548" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.13-e17736753"
- **Posição na Página:** Posição #16 na página • Seção: Conteúdo da Página • Sob H3: Jocineia
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H3: Jocineia
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-2048x2048`
- **Formato / Tamanho:** JPG (8.9 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.13-e1773675323462-219x300.jpeg](https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.13-e1773675323462-219x300.jpeg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/sobre-nos](https://podologialianagoncalves.com.br/sobre-nos)

![Imagem extraída](images/img_020_WhatsApp-Image-2026-03-16-at-10_59_13-e1773675323462-219x300.jpg)

---

### 21. `img_021_WhatsApp-Image-2026-03-16-at-10_59_11-2-768x1024.jpg`

- **Arquivo:** `images/img_021_WhatsApp-Image-2026-03-16-at-10_59_11-2-768x1024.jpg`
- **Descrição:** Contexto: "<img loading="lazy" decoding="async" width="768" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.11-2-768x10"
- **Posição na Página:** Posição #17 na página • Seção: Conteúdo da Página • Sob H2: Emily Regis
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Emily Regis
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** JPG (76.8 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.11-2-768x1024.jpeg](https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.11-2-768x1024.jpeg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/sobre-nos](https://podologialianagoncalves.com.br/sobre-nos)

![Imagem extraída](images/img_021_WhatsApp-Image-2026-03-16-at-10_59_11-2-768x1024.jpg)

---

### 22. `img_022_WhatsApp-Image-2026-03-16-at-10_59_11-2-225x300.jpg`

- **Arquivo:** `images/img_022_WhatsApp-Image-2026-03-16-at-10_59_11-2-225x300.jpg`
- **Descrição:** Contexto: "<img loading="lazy" decoding="async" width="768" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.11-2-768x10"
- **Posição na Página:** Posição #18 na página • Seção: Conteúdo da Página • Sob H2: Emily Regis
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Emily Regis
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** JPG (11.0 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.11-2-225x300.jpeg](https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.11-2-225x300.jpeg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/sobre-nos](https://podologialianagoncalves.com.br/sobre-nos)

![Imagem extraída](images/img_022_WhatsApp-Image-2026-03-16-at-10_59_11-2-225x300.jpg)

---

### 23. `img_023_WhatsApp-Image-2026-03-16-at-10_59_11-2.jpg`

- **Arquivo:** `images/img_023_WhatsApp-Image-2026-03-16-at-10_59_11-2.jpg`
- **Descrição:** Contexto: "<img loading="lazy" decoding="async" width="768" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.11-2-768x10"
- **Posição na Página:** Posição #19 na página • Seção: Conteúdo da Página • Sob H2: Emily Regis
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Emily Regis
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** JPG (93.8 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.11-2.jpeg](https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.11-2.jpeg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/sobre-nos](https://podologialianagoncalves.com.br/sobre-nos)

![Imagem extraída](images/img_023_WhatsApp-Image-2026-03-16-at-10_59_11-2.jpg)

---

### 24. `img_024_Imagem-do-WhatsApp-de-2023-12-13-as-17_55_34_77b6483f-1.webp`

- **Arquivo:** `images/img_024_Imagem-do-WhatsApp-de-2023-12-13-as-17_55_34_77b6483f-1.webp`
- **Descrição:** Contexto: "<img decoding="async" width="640" height="664" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/12/Imagem-do-WhatsApp-de-2023-12-13-as-17.55.34_77b6483f-1.webp" "
- **Posição na Página:** Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Por que escolher a nossa Podologia Clínica?
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Por que escolher a nossa Podologia Clínica?
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-large`
- **Formato / Tamanho:** WEBP (17.2 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/12/Imagem-do-WhatsApp-de-2023-12-13-as-17.55.34_77b6483f-1.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2023/12/Imagem-do-WhatsApp-de-2023-12-13-as-17.55.34_77b6483f-1.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/a-podologia](https://podologialianagoncalves.com.br/a-podologia)

![Imagem extraída](images/img_024_Imagem-do-WhatsApp-de-2023-12-13-as-17_55_34_77b6483f-1.webp)

---

### 25. `img_025_Imagem-do-WhatsApp-de-2023-12-13-as-17_55_34_77b6483f-1-289x.webp`

- **Arquivo:** `images/img_025_Imagem-do-WhatsApp-de-2023-12-13-as-17_55_34_77b6483f-1-289x.webp`
- **Descrição:** Contexto: "<img decoding="async" width="640" height="664" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/12/Imagem-do-WhatsApp-de-2023-12-13-as-17.55.34_77b6483f-1.webp" "
- **Posição na Página:** Posição #11 na página • Seção: Conteúdo da Página • Sob H2: Por que escolher a nossa Podologia Clínica?
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Por que escolher a nossa Podologia Clínica?
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-large`
- **Formato / Tamanho:** WEBP (7.4 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/12/Imagem-do-WhatsApp-de-2023-12-13-as-17.55.34_77b6483f-1-289x300.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2023/12/Imagem-do-WhatsApp-de-2023-12-13-as-17.55.34_77b6483f-1-289x300.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/a-podologia](https://podologialianagoncalves.com.br/a-podologia)

![Imagem extraída](images/img_025_Imagem-do-WhatsApp-de-2023-12-13-as-17_55_34_77b6483f-1-289x.webp)

---

### 26. `img_026_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp`

- **Arquivo:** `images/img_026_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp`
- **Descrição:** Contexto: "<img decoding="async" width="800" height="1000" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-i"
- **Posição na Página:** Posição #10 na página • Seção: Conteúdo da Página • Sob H2: O perigo de tentar resolver "em casa"
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: O perigo de tentar resolver "em casa"
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-large`
- **Formato / Tamanho:** WEBP (61.9 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-imediato-da-dor-1-819x1024.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-imediato-da-dor-1-819x1024.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/unha-encravada](https://podologialianagoncalves.com.br/unha-encravada)

![Imagem extraída](images/img_026_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

---

### 27. `img_027_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp`

- **Arquivo:** `images/img_027_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp`
- **Descrição:** Contexto: "<img decoding="async" width="800" height="1000" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-i"
- **Posição na Página:** Posição #11 na página • Seção: Conteúdo da Página • Sob H2: O perigo de tentar resolver "em casa"
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: O perigo de tentar resolver "em casa"
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-large`
- **Formato / Tamanho:** WEBP (11.8 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-imediato-da-dor-1-240x300.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-imediato-da-dor-1-240x300.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/unha-encravada](https://podologialianagoncalves.com.br/unha-encravada)

![Imagem extraída](images/img_027_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

---

### 28. `img_028_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp`

- **Arquivo:** `images/img_028_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp`
- **Descrição:** Contexto: "<img decoding="async" width="800" height="1000" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-i"
- **Posição na Página:** Posição #12 na página • Seção: Conteúdo da Página • Sob H2: O perigo de tentar resolver "em casa"
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: O perigo de tentar resolver "em casa"
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-large`
- **Formato / Tamanho:** WEBP (57.5 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-imediato-da-dor-1-768x960.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-imediato-da-dor-1-768x960.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/unha-encravada](https://podologialianagoncalves.com.br/unha-encravada)

![Imagem extraída](images/img_028_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

---

### 29. `img_029_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp`

- **Arquivo:** `images/img_029_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp`
- **Descrição:** Contexto: "<img decoding="async" width="800" height="1000" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-i"
- **Posição na Página:** Posição #13 na página • Seção: Conteúdo da Página • Sob H2: O perigo de tentar resolver "em casa"
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: O perigo de tentar resolver "em casa"
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-large`
- **Formato / Tamanho:** WEBP (85.6 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-imediato-da-dor-1.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-imediato-da-dor-1.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/unha-encravada](https://podologialianagoncalves.com.br/unha-encravada)

![Imagem extraída](images/img_029_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

---

### 30. `img_030_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175206114-694x102.jpg`

- **Arquivo:** `images/img_030_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175206114-694x102.jpg`
- **Descrição:** Contexto: "<img loading="lazy" decoding="async" width="694" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175"
- **Posição na Página:** Posição #16 na página • Seção: Conteúdo da Página • Sob H2: Especialista com 15 Anos Tratando Onicocriptose
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Especialista com 15 Anos Tratando Onicocriptose
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-large`
- **Formato / Tamanho:** JPG (50.3 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175206114-694x1024.jpeg](https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175206114-694x1024.jpeg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/unha-encravada](https://podologialianagoncalves.com.br/unha-encravada)

![Imagem extraída](images/img_030_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175206114-694x102.jpg)

---

### 31. `img_032_2-768x960.webp`

- **Arquivo:** `images/img_032_2-768x960.webp`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2-768x960.webp" class="attachment-medium_large size-medium_lar"
- **Posição na Página:** Posição #11 na página • Seção: Conteúdo da Página • Sob H2: A ciência por trás da sua nova unha
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: A ciência por trás da sua nova unha
- **Seletor CSS:** `div.e-con-inner > div.elementor-element > div.e-con-inner > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** WEBP (54.0 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2-768x960.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2-768x960.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/fungos-micose-onicomicose](https://podologialianagoncalves.com.br/fungos-micose-onicomicose)

![Imagem extraída](images/img_032_2-768x960.webp)

---

### 32. `img_033_2-240x300.webp`

- **Arquivo:** `images/img_033_2-240x300.webp`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2-768x960.webp" class="attachment-medium_large size-medium_lar"
- **Posição na Página:** Posição #12 na página • Seção: Conteúdo da Página • Sob H2: A ciência por trás da sua nova unha
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: A ciência por trás da sua nova unha
- **Seletor CSS:** `div.e-con-inner > div.elementor-element > div.e-con-inner > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** WEBP (10.1 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2-240x300.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2-240x300.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/fungos-micose-onicomicose](https://podologialianagoncalves.com.br/fungos-micose-onicomicose)

![Imagem extraída](images/img_033_2-240x300.webp)

---

### 33. `img_034_2-819x1024.webp`

- **Arquivo:** `images/img_034_2-819x1024.webp`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2-768x960.webp" class="attachment-medium_large size-medium_lar"
- **Posição na Página:** Posição #13 na página • Seção: Conteúdo da Página • Sob H2: A ciência por trás da sua nova unha
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: A ciência por trás da sua nova unha
- **Seletor CSS:** `div.e-con-inner > div.elementor-element > div.e-con-inner > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** WEBP (58.2 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2-819x1024.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2-819x1024.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/fungos-micose-onicomicose](https://podologialianagoncalves.com.br/fungos-micose-onicomicose)

![Imagem extraída](images/img_034_2-819x1024.webp)

---

### 34. `img_035_2.webp`

- **Arquivo:** `images/img_035_2.webp`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2-768x960.webp" class="attachment-medium_large size-medium_lar"
- **Posição na Página:** Posição #14 na página • Seção: Conteúdo da Página • Sob H2: A ciência por trás da sua nova unha
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: A ciência por trás da sua nova unha
- **Seletor CSS:** `div.e-con-inner > div.elementor-element > div.e-con-inner > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** WEBP (82.9 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/fungos-micose-onicomicose](https://podologialianagoncalves.com.br/fungos-micose-onicomicose)

![Imagem extraída](images/img_035_2.webp)

---

### 35. `img_036_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_c5861866-remov.webp`

- **Arquivo:** `images/img_036_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_c5861866-remov.webp`
- **Descrição:** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_c5861866-remove"
- **Posição na Página:** Posição #15 na página • Seção: Conteúdo da Página • Sob H2: Especialista com15 Anos Tratando Onicomicose
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Especialista com15 Anos Tratando Onicomicose
- **Seletor CSS:** `div.e-con-inner > div.elementor-element > div.e-con-inner > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** WEBP (22.0 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_c5861866-removebg-preview.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_c5861866-removebg-preview.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/fungos-micose-onicomicose](https://podologialianagoncalves.com.br/fungos-micose-onicomicose)

![Imagem extraída](images/img_036_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_c5861866-remov.webp)

---

### 36. `img_037_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_c5861866-remov.webp`

- **Arquivo:** `images/img_037_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_c5861866-remov.webp`
- **Descrição:** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_c5861866-remove"
- **Posição na Página:** Posição #16 na página • Seção: Conteúdo da Página • Sob H2: Especialista com15 Anos Tratando Onicomicose
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Especialista com15 Anos Tratando Onicomicose
- **Seletor CSS:** `div.e-con-inner > div.elementor-element > div.e-con-inner > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** WEBP (9.2 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_c5861866-removebg-preview-225x300.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_c5861866-removebg-preview-225x300.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/fungos-micose-onicomicose](https://podologialianagoncalves.com.br/fungos-micose-onicomicose)

![Imagem extraída](images/img_037_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_c5861866-remov.webp)

---

### 37. `img_038_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp`

- **Arquivo:** `images/img_038_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="857" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104-"
- **Posição na Página:** Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real?
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Por que um "cortezinho" é um risco real?
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** WEBP (20.7 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104-768x857.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104-768x857.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/pes-do-diabetico](https://podologialianagoncalves.com.br/pes-do-diabetico)

![Imagem extraída](images/img_038_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp)

---

### 38. `img_039_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp`

- **Arquivo:** `images/img_039_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="857" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104-"
- **Posição na Página:** Posição #11 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real?
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Por que um "cortezinho" é um risco real?
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** WEBP (6.3 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104-269x300.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104-269x300.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/pes-do-diabetico](https://podologialianagoncalves.com.br/pes-do-diabetico)

![Imagem extraída](images/img_039_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp)

---

### 39. `img_040_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp`

- **Arquivo:** `images/img_040_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="857" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104-"
- **Posição na Página:** Posição #12 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real?
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Por que um "cortezinho" é um risco real?
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** WEBP (25.5 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104-917x1024.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104-917x1024.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/pes-do-diabetico](https://podologialianagoncalves.com.br/pes-do-diabetico)

![Imagem extraída](images/img_040_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp)

---

### 40. `img_041_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp`

- **Arquivo:** `images/img_041_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="857" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104-"
- **Posição na Página:** Posição #13 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real?
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Por que um "cortezinho" é um risco real?
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** WEBP (27.5 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/pes-do-diabetico](https://podologialianagoncalves.com.br/pes-do-diabetico)

![Imagem extraída](images/img_041_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp)

---

### 41. `img_042_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp`

- **Arquivo:** `images/img_042_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-im"
- **Posição na Página:** Posição #14 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real?
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Por que um "cortezinho" é um risco real?
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** WEBP (59.9 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-imediato-da-dor-2-768x960.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-imediato-da-dor-2-768x960.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/pes-do-diabetico](https://podologialianagoncalves.com.br/pes-do-diabetico)

![Imagem extraída](images/img_042_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

---

### 42. `img_043_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp`

- **Arquivo:** `images/img_043_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-im"
- **Posição na Página:** Posição #15 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real?
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Por que um "cortezinho" é um risco real?
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** WEBP (12.4 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-imediato-da-dor-2-240x300.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-imediato-da-dor-2-240x300.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/pes-do-diabetico](https://podologialianagoncalves.com.br/pes-do-diabetico)

![Imagem extraída](images/img_043_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

---

### 43. `img_044_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp`

- **Arquivo:** `images/img_044_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-im"
- **Posição na Página:** Posição #16 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real?
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Por que um "cortezinho" é um risco real?
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** WEBP (65.4 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-imediato-da-dor-2-819x1024.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-imediato-da-dor-2-819x1024.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/pes-do-diabetico](https://podologialianagoncalves.com.br/pes-do-diabetico)

![Imagem extraída](images/img_044_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

---

### 44. `img_045_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp`

- **Arquivo:** `images/img_045_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-im"
- **Posição na Página:** Posição #17 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real?
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Por que um "cortezinho" é um risco real?
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** WEBP (93.1 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-imediato-da-dor-2.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-imediato-da-dor-2.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/pes-do-diabetico](https://podologialianagoncalves.com.br/pes-do-diabetico)

![Imagem extraída](images/img_045_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

---

### 45. `img_046_Design-sem-768x768.png`

- **Arquivo:** `images/img_046_Design-sem-768x768.png`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-768x768.png" class="attachment-medium_large size-me"
- **Posição na Página:** Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
- **Seletor CSS:** `div.e-con-inner > div.elementor-element > div.e-con-inner > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** PNG (162.8 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-768x768.png](https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-768x768.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/podologia-infantil-podopediatria-especialista-em-criancas](https://podologialianagoncalves.com.br/podologia-infantil-podopediatria-especialista-em-criancas)

![Imagem extraída](images/img_046_Design-sem-768x768.png)

---

### 46. `img_047_Design-sem-300x300.png`

- **Arquivo:** `images/img_047_Design-sem-300x300.png`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-768x768.png" class="attachment-medium_large size-me"
- **Posição na Página:** Posição #11 na página • Seção: Conteúdo da Página • Sob H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
- **Seletor CSS:** `div.e-con-inner > div.elementor-element > div.e-con-inner > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** PNG (31.9 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-300x300.png](https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-300x300.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/podologia-infantil-podopediatria-especialista-em-criancas](https://podologialianagoncalves.com.br/podologia-infantil-podopediatria-especialista-em-criancas)

![Imagem extraída](images/img_047_Design-sem-300x300.png)

---

### 47. `img_048_Design-sem-1024x1024.png`

- **Arquivo:** `images/img_048_Design-sem-1024x1024.png`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-768x768.png" class="attachment-medium_large size-me"
- **Posição na Página:** Posição #12 na página • Seção: Conteúdo da Página • Sob H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
- **Seletor CSS:** `div.e-con-inner > div.elementor-element > div.e-con-inner > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** PNG (276.3 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-1024x1024.png](https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-1024x1024.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/podologia-infantil-podopediatria-especialista-em-criancas](https://podologialianagoncalves.com.br/podologia-infantil-podopediatria-especialista-em-criancas)

![Imagem extraída](images/img_048_Design-sem-1024x1024.png)

---

### 48. `img_049_Design-sem-150x150.png`

- **Arquivo:** `images/img_049_Design-sem-150x150.png`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-768x768.png" class="attachment-medium_large size-me"
- **Posição na Página:** Posição #13 na página • Seção: Conteúdo da Página • Sob H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
- **Seletor CSS:** `div.e-con-inner > div.elementor-element > div.e-con-inner > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** PNG (10.9 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-150x150.png](https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-150x150.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/podologia-infantil-podopediatria-especialista-em-criancas](https://podologialianagoncalves.com.br/podologia-infantil-podopediatria-especialista-em-criancas)

![Imagem extraída](images/img_049_Design-sem-150x150.png)

---

### 49. `img_050_Design-sem.png`

- **Arquivo:** `images/img_050_Design-sem.png`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-768x768.png" class="attachment-medium_large size-me"
- **Posição na Página:** Posição #14 na página • Seção: Conteúdo da Página • Sob H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
- **Seletor CSS:** `div.e-con-inner > div.elementor-element > div.e-con-inner > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** PNG (309.3 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem.png](https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/podologia-infantil-podopediatria-especialista-em-criancas](https://podologialianagoncalves.com.br/podologia-infantil-podopediatria-especialista-em-criancas)

![Imagem extraída](images/img_050_Design-sem.png)

---

### 50. `img_051_282207662_441098077826309_4659220234443228409_n-768x768.jpg`

- **Arquivo:** `images/img_051_282207662_441098077826309_4659220234443228409_n-768x768.jpg`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n-768x768.jpg" c"
- **Posição na Página:** Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Formação específica em Geriatria e Gerontologia
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Formação específica em Geriatria e Gerontologia
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** JPG (56.9 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n-768x768.jpg](https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n-768x768.jpg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/podogeriatria](https://podologialianagoncalves.com.br/podogeriatria)

![Imagem extraída](images/img_051_282207662_441098077826309_4659220234443228409_n-768x768.jpg)

---

### 51. `img_052_282207662_441098077826309_4659220234443228409_n-300x300.jpg`

- **Arquivo:** `images/img_052_282207662_441098077826309_4659220234443228409_n-300x300.jpg`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n-768x768.jpg" c"
- **Posição na Página:** Posição #11 na página • Seção: Conteúdo da Página • Sob H2: Formação específica em Geriatria e Gerontologia
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Formação específica em Geriatria e Gerontologia
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** JPG (14.2 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n-300x300.jpg](https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n-300x300.jpg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/podogeriatria](https://podologialianagoncalves.com.br/podogeriatria)

![Imagem extraída](images/img_052_282207662_441098077826309_4659220234443228409_n-300x300.jpg)

---

### 52. `img_053_282207662_441098077826309_4659220234443228409_n-150x150.jpg`

- **Arquivo:** `images/img_053_282207662_441098077826309_4659220234443228409_n-150x150.jpg`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n-768x768.jpg" c"
- **Posição na Página:** Posição #12 na página • Seção: Conteúdo da Página • Sob H2: Formação específica em Geriatria e Gerontologia
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Formação específica em Geriatria e Gerontologia
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** JPG (5.0 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n-150x150.jpg](https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n-150x150.jpg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/podogeriatria](https://podologialianagoncalves.com.br/podogeriatria)

![Imagem extraída](images/img_053_282207662_441098077826309_4659220234443228409_n-150x150.jpg)

---

### 53. `img_054_282207662_441098077826309_4659220234443228409_n.jpg`

- **Arquivo:** `images/img_054_282207662_441098077826309_4659220234443228409_n.jpg`
- **Descrição:** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n-768x768.jpg" c"
- **Posição na Página:** Posição #13 na página • Seção: Conteúdo da Página • Sob H2: Formação específica em Geriatria e Gerontologia
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Formação específica em Geriatria e Gerontologia
- **Seletor CSS:** `div.elementor-element > div.e-con-inner > div.elementor-element > div.elementor-element > img.attachment-medium_large`
- **Formato / Tamanho:** JPG (63.2 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n.jpg](https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/282207662_441098077826309_4659220234443228409_n.jpg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/podogeriatria](https://podologialianagoncalves.com.br/podogeriatria)

![Imagem extraída](images/img_054_282207662_441098077826309_4659220234443228409_n.jpg)

---

### 54. `img_055_Design-sem-nome-576x1024.png`

- **Arquivo:** `images/img_055_Design-sem-nome-576x1024.png`
- **Descrição:** Contexto: "<img decoding="async" width="576" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome-576x1024.png" class="attachment-large size-la"
- **Posição na Página:** Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Cuidado Especializado com quem entende de Saúde
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Cuidado Especializado com quem entende de Saúde
- **Seletor CSS:** `div.elementor > div.elementor-element > div.elementor-element > img.attachment-large`
- **Formato / Tamanho:** PNG (138.8 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome-576x1024.png](https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome-576x1024.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/ozonioterapia](https://podologialianagoncalves.com.br/ozonioterapia)

![Imagem extraída](images/img_055_Design-sem-nome-576x1024.png)

---

### 55. `img_056_Design-sem-nome-169x300.png`

- **Arquivo:** `images/img_056_Design-sem-nome-169x300.png`
- **Descrição:** Contexto: "<img decoding="async" width="576" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome-576x1024.png" class="attachment-large size-la"
- **Posição na Página:** Posição #11 na página • Seção: Conteúdo da Página • Sob H2: Cuidado Especializado com quem entende de Saúde
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Cuidado Especializado com quem entende de Saúde
- **Seletor CSS:** `div.elementor > div.elementor-element > div.elementor-element > img.attachment-large`
- **Formato / Tamanho:** PNG (18.0 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome-169x300.png](https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome-169x300.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/ozonioterapia](https://podologialianagoncalves.com.br/ozonioterapia)

![Imagem extraída](images/img_056_Design-sem-nome-169x300.png)

---

### 56. `img_057_Design-sem-nome-768x1365.png`

- **Arquivo:** `images/img_057_Design-sem-nome-768x1365.png`
- **Descrição:** Contexto: "<img decoding="async" width="576" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome-576x1024.png" class="attachment-large size-la"
- **Posição na Página:** Posição #12 na página • Seção: Conteúdo da Página • Sob H2: Cuidado Especializado com quem entende de Saúde
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Cuidado Especializado com quem entende de Saúde
- **Seletor CSS:** `div.elementor > div.elementor-element > div.elementor-element > img.attachment-large`
- **Formato / Tamanho:** PNG (229.3 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome-768x1365.png](https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome-768x1365.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/ozonioterapia](https://podologialianagoncalves.com.br/ozonioterapia)

![Imagem extraída](images/img_057_Design-sem-nome-768x1365.png)

---

### 57. `img_058_Design-sem-nome-864x1536.png`

- **Arquivo:** `images/img_058_Design-sem-nome-864x1536.png`
- **Descrição:** Contexto: "<img decoding="async" width="576" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome-576x1024.png" class="attachment-large size-la"
- **Posição na Página:** Posição #13 na página • Seção: Conteúdo da Página • Sob H2: Cuidado Especializado com quem entende de Saúde
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Cuidado Especializado com quem entende de Saúde
- **Seletor CSS:** `div.elementor > div.elementor-element > div.elementor-element > img.attachment-large`
- **Formato / Tamanho:** PNG (279.9 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome-864x1536.png](https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome-864x1536.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/ozonioterapia](https://podologialianagoncalves.com.br/ozonioterapia)

![Imagem extraída](images/img_058_Design-sem-nome-864x1536.png)

---

### 58. `img_059_Design-sem-nome.png`

- **Arquivo:** `images/img_059_Design-sem-nome.png`
- **Descrição:** Contexto: "<img decoding="async" width="576" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome-576x1024.png" class="attachment-large size-la"
- **Posição na Página:** Posição #14 na página • Seção: Conteúdo da Página • Sob H2: Cuidado Especializado com quem entende de Saúde
- **Seção Semântica:** `Conteúdo da Página`
- **Título Mais Próximo:** H2: Cuidado Especializado com quem entende de Saúde
- **Seletor CSS:** `div.elementor > div.elementor-element > div.elementor-element > img.attachment-large`
- **Formato / Tamanho:** PNG (420.5 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome.png](https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/Design-sem-nome.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/ozonioterapia](https://podologialianagoncalves.com.br/ozonioterapia)

![Imagem extraída](images/img_059_Design-sem-nome.png)

---

### 59. `img_060_Imagem-do-WhatsApp-de-2023-10-24-as-11_37_07_33072c7a-1024x7.jpg`

- **Arquivo:** `images/img_060_Imagem-do-WhatsApp-de-2023-10-24-as-11_37_07_33072c7a-1024x7.jpg`
- **Descrição:** Contexto: "<img decoding="async" width="800" height="600" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem-do-WhatsApp-de-2023-10-24-as-11.37.07_33072c7a-1024x768"
- **Posição na Página:** Posição #10 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Podologia Clínica
- **Seção Semântica:** `Corpo Principal do Conteúdo (Article / Main)`
- **Título Mais Próximo:** H1: Podologia Clínica
- **Seletor CSS:** `div.elementor-posts-container > article.elementor-post > a.elementor-post__thumbnail__link > div.elementor-post__thumbnail > img.attachment-large`
- **Formato / Tamanho:** JPG (41.1 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem-do-WhatsApp-de-2023-10-24-as-11.37.07_33072c7a-1024x768.jpg](https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem-do-WhatsApp-de-2023-10-24-as-11.37.07_33072c7a-1024x768.jpg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/blog](https://podologialianagoncalves.com.br/blog)

![Imagem extraída](images/img_060_Imagem-do-WhatsApp-de-2023-10-24-as-11_37_07_33072c7a-1024x7.jpg)

---

### 60. `img_061_Imagem-do-WhatsApp-de-2023-10-24-as-11_37_07_33072c7a-300x22.jpg`

- **Arquivo:** `images/img_061_Imagem-do-WhatsApp-de-2023-10-24-as-11_37_07_33072c7a-300x22.jpg`
- **Descrição:** Contexto: "<img decoding="async" width="800" height="600" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem-do-WhatsApp-de-2023-10-24-as-11.37.07_33072c7a-1024x768"
- **Posição na Página:** Posição #11 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Podologia Clínica
- **Seção Semântica:** `Corpo Principal do Conteúdo (Article / Main)`
- **Título Mais Próximo:** H1: Podologia Clínica
- **Seletor CSS:** `div.elementor-posts-container > article.elementor-post > a.elementor-post__thumbnail__link > div.elementor-post__thumbnail > img.attachment-large`
- **Formato / Tamanho:** JPG (6.6 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem-do-WhatsApp-de-2023-10-24-as-11.37.07_33072c7a-300x225.jpg](https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem-do-WhatsApp-de-2023-10-24-as-11.37.07_33072c7a-300x225.jpg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/blog](https://podologialianagoncalves.com.br/blog)

![Imagem extraída](images/img_061_Imagem-do-WhatsApp-de-2023-10-24-as-11_37_07_33072c7a-300x22.jpg)

---

### 61. `img_062_Imagem-do-WhatsApp-de-2023-10-24-as-11_37_07_33072c7a-768x57.jpg`

- **Arquivo:** `images/img_062_Imagem-do-WhatsApp-de-2023-10-24-as-11_37_07_33072c7a-768x57.jpg`
- **Descrição:** Contexto: "<img decoding="async" width="800" height="600" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem-do-WhatsApp-de-2023-10-24-as-11.37.07_33072c7a-1024x768"
- **Posição na Página:** Posição #12 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Podologia Clínica
- **Seção Semântica:** `Corpo Principal do Conteúdo (Article / Main)`
- **Título Mais Próximo:** H1: Podologia Clínica
- **Seletor CSS:** `div.elementor-posts-container > article.elementor-post > a.elementor-post__thumbnail__link > div.elementor-post__thumbnail > img.attachment-large`
- **Formato / Tamanho:** JPG (27.0 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem-do-WhatsApp-de-2023-10-24-as-11.37.07_33072c7a-768x576.jpg](https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem-do-WhatsApp-de-2023-10-24-as-11.37.07_33072c7a-768x576.jpg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/blog](https://podologialianagoncalves.com.br/blog)

![Imagem extraída](images/img_062_Imagem-do-WhatsApp-de-2023-10-24-as-11_37_07_33072c7a-768x57.jpg)

---

### 62. `img_063_Imagem-do-WhatsApp-de-2023-10-24-as-11_37_07_33072c7a.jpg`

- **Arquivo:** `images/img_063_Imagem-do-WhatsApp-de-2023-10-24-as-11_37_07_33072c7a.jpg`
- **Descrição:** Contexto: "<img decoding="async" width="800" height="600" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem-do-WhatsApp-de-2023-10-24-as-11.37.07_33072c7a-1024x768"
- **Posição na Página:** Posição #13 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Podologia Clínica
- **Seção Semântica:** `Corpo Principal do Conteúdo (Article / Main)`
- **Título Mais Próximo:** H1: Podologia Clínica
- **Seletor CSS:** `div.elementor-posts-container > article.elementor-post > a.elementor-post__thumbnail__link > div.elementor-post__thumbnail > img.attachment-large`
- **Formato / Tamanho:** JPG (19.3 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem-do-WhatsApp-de-2023-10-24-as-11.37.07_33072c7a.jpg](https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem-do-WhatsApp-de-2023-10-24-as-11.37.07_33072c7a.jpg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/blog](https://podologialianagoncalves.com.br/blog)

![Imagem extraída](images/img_063_Imagem-do-WhatsApp-de-2023-10-24-as-11_37_07_33072c7a.jpg)

---

### 63. `img_064_IMG-20190207-WA0086-576x1024.webp`

- **Arquivo:** `images/img_064_IMG-20190207-WA0086-576x1024.webp`
- **Descrição:** Contexto: "<img decoding="async" width="576" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/02/IMG-20190207-WA0086-576x1024.webp" class="attachment-large si"
- **Posição na Página:** Posição #14 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Calo ou verruga plantar? Como diferenciar — e por que importa
- **Seção Semântica:** `Corpo Principal do Conteúdo (Article / Main)`
- **Título Mais Próximo:** H1: Calo ou verruga plantar? Como diferenciar — e por que importa
- **Seletor CSS:** `div.elementor-posts-container > article.elementor-post > a.elementor-post__thumbnail__link > div.elementor-post__thumbnail > img.attachment-large`
- **Formato / Tamanho:** WEBP (7.3 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2024/02/IMG-20190207-WA0086-576x1024.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2024/02/IMG-20190207-WA0086-576x1024.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/blog](https://podologialianagoncalves.com.br/blog)

![Imagem extraída](images/img_064_IMG-20190207-WA0086-576x1024.webp)

---

### 64. `img_065_IMG-20190207-WA0086-169x300.webp`

- **Arquivo:** `images/img_065_IMG-20190207-WA0086-169x300.webp`
- **Descrição:** Contexto: "<img decoding="async" width="576" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/02/IMG-20190207-WA0086-576x1024.webp" class="attachment-large si"
- **Posição na Página:** Posição #15 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Calo ou verruga plantar? Como diferenciar — e por que importa
- **Seção Semântica:** `Corpo Principal do Conteúdo (Article / Main)`
- **Título Mais Próximo:** H1: Calo ou verruga plantar? Como diferenciar — e por que importa
- **Seletor CSS:** `div.elementor-posts-container > article.elementor-post > a.elementor-post__thumbnail__link > div.elementor-post__thumbnail > img.attachment-large`
- **Formato / Tamanho:** WEBP (1.5 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2024/02/IMG-20190207-WA0086-169x300.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2024/02/IMG-20190207-WA0086-169x300.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/blog](https://podologialianagoncalves.com.br/blog)

![Imagem extraída](images/img_065_IMG-20190207-WA0086-169x300.webp)

---

### 65. `img_066_IMG-20190207-WA0086.webp`

- **Arquivo:** `images/img_066_IMG-20190207-WA0086.webp`
- **Descrição:** Contexto: "<img decoding="async" width="576" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/02/IMG-20190207-WA0086-576x1024.webp" class="attachment-large si"
- **Posição na Página:** Posição #16 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Calo ou verruga plantar? Como diferenciar — e por que importa
- **Seção Semântica:** `Corpo Principal do Conteúdo (Article / Main)`
- **Título Mais Próximo:** H1: Calo ou verruga plantar? Como diferenciar — e por que importa
- **Seletor CSS:** `div.elementor-posts-container > article.elementor-post > a.elementor-post__thumbnail__link > div.elementor-post__thumbnail > img.attachment-large`
- **Formato / Tamanho:** WEBP (9.9 KB) | MIME: `image/webp`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2024/02/IMG-20190207-WA0086.webp](https://podologialianagoncalves.com.br/wp-content/uploads/2024/02/IMG-20190207-WA0086.webp)
- **Página de Origem:** [https://podologialianagoncalves.com.br/blog](https://podologialianagoncalves.com.br/blog)

![Imagem extraída](images/img_066_IMG-20190207-WA0086.webp)

---

### 66. `img_067_Design-sem-nome-1-1024x1024.png`

- **Arquivo:** `images/img_067_Design-sem-nome-1-1024x1024.png`
- **Descrição:** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1-1024x1024.png" class="attachm"
- **Posição na Página:** Posição #17 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Podoprofilaxia vs. pedicure: qual a diferença real?
- **Seção Semântica:** `Corpo Principal do Conteúdo (Article / Main)`
- **Título Mais Próximo:** H1: Podoprofilaxia vs. pedicure: qual a diferença real?
- **Seletor CSS:** `div.elementor-posts-container > article.elementor-post > a.elementor-post__thumbnail__link > div.elementor-post__thumbnail > img.attachment-large`
- **Formato / Tamanho:** PNG (196.0 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1-1024x1024.png](https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1-1024x1024.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/blog](https://podologialianagoncalves.com.br/blog)

![Imagem extraída](images/img_067_Design-sem-nome-1-1024x1024.png)

---

### 67. `img_068_Design-sem-nome-1-300x300.png`

- **Arquivo:** `images/img_068_Design-sem-nome-1-300x300.png`
- **Descrição:** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1-1024x1024.png" class="attachm"
- **Posição na Página:** Posição #18 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Podoprofilaxia vs. pedicure: qual a diferença real?
- **Seção Semântica:** `Corpo Principal do Conteúdo (Article / Main)`
- **Título Mais Próximo:** H1: Podoprofilaxia vs. pedicure: qual a diferença real?
- **Seletor CSS:** `div.elementor-posts-container > article.elementor-post > a.elementor-post__thumbnail__link > div.elementor-post__thumbnail > img.attachment-large`
- **Formato / Tamanho:** PNG (23.4 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1-300x300.png](https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1-300x300.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/blog](https://podologialianagoncalves.com.br/blog)

![Imagem extraída](images/img_068_Design-sem-nome-1-300x300.png)

---

### 68. `img_069_Design-sem-nome-1-150x150.png`

- **Arquivo:** `images/img_069_Design-sem-nome-1-150x150.png`
- **Descrição:** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1-1024x1024.png" class="attachm"
- **Posição na Página:** Posição #19 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Podoprofilaxia vs. pedicure: qual a diferença real?
- **Seção Semântica:** `Corpo Principal do Conteúdo (Article / Main)`
- **Título Mais Próximo:** H1: Podoprofilaxia vs. pedicure: qual a diferença real?
- **Seletor CSS:** `div.elementor-posts-container > article.elementor-post > a.elementor-post__thumbnail__link > div.elementor-post__thumbnail > img.attachment-large`
- **Formato / Tamanho:** PNG (6.6 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1-150x150.png](https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1-150x150.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/blog](https://podologialianagoncalves.com.br/blog)

![Imagem extraída](images/img_069_Design-sem-nome-1-150x150.png)

---

### 69. `img_070_Design-sem-nome-1-768x768.png`

- **Arquivo:** `images/img_070_Design-sem-nome-1-768x768.png`
- **Descrição:** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1-1024x1024.png" class="attachm"
- **Posição na Página:** Posição #20 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Podoprofilaxia vs. pedicure: qual a diferença real?
- **Seção Semântica:** `Corpo Principal do Conteúdo (Article / Main)`
- **Título Mais Próximo:** H1: Podoprofilaxia vs. pedicure: qual a diferença real?
- **Seletor CSS:** `div.elementor-posts-container > article.elementor-post > a.elementor-post__thumbnail__link > div.elementor-post__thumbnail > img.attachment-large`
- **Formato / Tamanho:** PNG (116.2 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1-768x768.png](https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1-768x768.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/blog](https://podologialianagoncalves.com.br/blog)

![Imagem extraída](images/img_070_Design-sem-nome-1-768x768.png)

---

### 70. `img_071_Design-sem-nome-1.png`

- **Arquivo:** `images/img_071_Design-sem-nome-1.png`
- **Descrição:** Contexto: "<img loading="lazy" decoding="async" width="800" height="800" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1-1024x1024.png" class="attachm"
- **Posição na Página:** Posição #21 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Podoprofilaxia vs. pedicure: qual a diferença real?
- **Seção Semântica:** `Corpo Principal do Conteúdo (Article / Main)`
- **Título Mais Próximo:** H1: Podoprofilaxia vs. pedicure: qual a diferença real?
- **Seletor CSS:** `div.elementor-posts-container > article.elementor-post > a.elementor-post__thumbnail__link > div.elementor-post__thumbnail > img.attachment-large`
- **Formato / Tamanho:** PNG (280.4 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1.png](https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Design-sem-nome-1.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/blog](https://podologialianagoncalves.com.br/blog)

![Imagem extraída](images/img_071_Design-sem-nome-1.png)

---

### 71. `img_072_Imagem-do-WhatsApp-de-2023-10-24-as-11_27_44_8181cf23-e16982.jpg`

- **Arquivo:** `images/img_072_Imagem-do-WhatsApp-de-2023-10-24-as-11_27_44_8181cf23-e16982.jpg`
- **Descrição:** Contexto: "<img loading="lazy" decoding="async" width="800" height="531" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-10-24-as-11.27.44_81"
- **Posição na Página:** Posição #26 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Pé diabético: os 5 sinais que pedem atenção imediata
- **Seção Semântica:** `Corpo Principal do Conteúdo (Article / Main)`
- **Título Mais Próximo:** H1: Pé diabético: os 5 sinais que pedem atenção imediata
- **Seletor CSS:** `div.elementor-posts-container > article.elementor-post > a.elementor-post__thumbnail__link > div.elementor-post__thumbnail > img.attachment-large`
- **Formato / Tamanho:** JPG (54.8 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-10-24-as-11.27.44_8181cf23-e1698245412789-1024x680.jpg](https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-10-24-as-11.27.44_8181cf23-e1698245412789-1024x680.jpg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/blog](https://podologialianagoncalves.com.br/blog)

![Imagem extraída](images/img_072_Imagem-do-WhatsApp-de-2023-10-24-as-11_27_44_8181cf23-e16982.jpg)

---

### 72. `img_073_Imagem-do-WhatsApp-de-2023-10-24-as-11_27_44_8181cf23-e16982.jpg`

- **Arquivo:** `images/img_073_Imagem-do-WhatsApp-de-2023-10-24-as-11_27_44_8181cf23-e16982.jpg`
- **Descrição:** Contexto: "<img loading="lazy" decoding="async" width="800" height="531" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-10-24-as-11.27.44_81"
- **Posição na Página:** Posição #27 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Pé diabético: os 5 sinais que pedem atenção imediata
- **Seção Semântica:** `Corpo Principal do Conteúdo (Article / Main)`
- **Título Mais Próximo:** H1: Pé diabético: os 5 sinais que pedem atenção imediata
- **Seletor CSS:** `div.elementor-posts-container > article.elementor-post > a.elementor-post__thumbnail__link > div.elementor-post__thumbnail > img.attachment-large`
- **Formato / Tamanho:** JPG (8.7 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-10-24-as-11.27.44_8181cf23-e1698245412789-300x199.jpg](https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-10-24-as-11.27.44_8181cf23-e1698245412789-300x199.jpg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/blog](https://podologialianagoncalves.com.br/blog)

![Imagem extraída](images/img_073_Imagem-do-WhatsApp-de-2023-10-24-as-11_27_44_8181cf23-e16982.jpg)

---

### 73. `img_074_Imagem-do-WhatsApp-de-2023-10-24-as-11_27_44_8181cf23-e16982.jpg`

- **Arquivo:** `images/img_074_Imagem-do-WhatsApp-de-2023-10-24-as-11_27_44_8181cf23-e16982.jpg`
- **Descrição:** Contexto: "<img loading="lazy" decoding="async" width="800" height="531" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-10-24-as-11.27.44_81"
- **Posição na Página:** Posição #28 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Pé diabético: os 5 sinais que pedem atenção imediata
- **Seção Semântica:** `Corpo Principal do Conteúdo (Article / Main)`
- **Título Mais Próximo:** H1: Pé diabético: os 5 sinais que pedem atenção imediata
- **Seletor CSS:** `div.elementor-posts-container > article.elementor-post > a.elementor-post__thumbnail__link > div.elementor-post__thumbnail > img.attachment-large`
- **Formato / Tamanho:** JPG (35.9 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-10-24-as-11.27.44_8181cf23-e1698245412789-768x510.jpg](https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-10-24-as-11.27.44_8181cf23-e1698245412789-768x510.jpg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/blog](https://podologialianagoncalves.com.br/blog)

![Imagem extraída](images/img_074_Imagem-do-WhatsApp-de-2023-10-24-as-11_27_44_8181cf23-e16982.jpg)

---

### 74. `img_075_Imagem-do-WhatsApp-de-2023-10-24-as-11_27_44_8181cf23-e16982.jpg`

- **Arquivo:** `images/img_075_Imagem-do-WhatsApp-de-2023-10-24-as-11_27_44_8181cf23-e16982.jpg`
- **Descrição:** Contexto: "<img loading="lazy" decoding="async" width="800" height="531" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-10-24-as-11.27.44_81"
- **Posição na Página:** Posição #29 na página • Seção: Corpo Principal do Conteúdo (Article / Main) • Sob H1: Pé diabético: os 5 sinais que pedem atenção imediata
- **Seção Semântica:** `Corpo Principal do Conteúdo (Article / Main)`
- **Título Mais Próximo:** H1: Pé diabético: os 5 sinais que pedem atenção imediata
- **Seletor CSS:** `div.elementor-posts-container > article.elementor-post > a.elementor-post__thumbnail__link > div.elementor-post__thumbnail > img.attachment-large`
- **Formato / Tamanho:** JPG (64.2 KB) | MIME: `image/jpeg`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-10-24-as-11.27.44_8181cf23-e1698245412789.jpg](https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-10-24-as-11.27.44_8181cf23-e1698245412789.jpg)
- **Página de Origem:** [https://podologialianagoncalves.com.br/blog](https://podologialianagoncalves.com.br/blog)

![Imagem extraída](images/img_075_Imagem-do-WhatsApp-de-2023-10-24-as-11_27_44_8181cf23-e16982.jpg)

---

### 75. `img_076_Social_Meta_Image_og_image.png`

- **Arquivo:** `images/img_076_Social_Meta_Image_og_image.png`
- **Descrição:** Texto Alt: "Social Meta Image (og:image)" | Título: "og:image" | Contexto: "Meta tag og:image"
- **Posição na Página:** Posição #11 na página • Seção: Metadados & Redes Sociais
- **Seção Semântica:** `Metadados & Redes Sociais`
- **Seletor CSS:** `meta[og:image]`
- **Formato / Tamanho:** PNG (943.3 KB) | MIME: `image/png`
- **URL Original:** [https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1.png](https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1.png)
- **Página de Origem:** [https://podologialianagoncalves.com.br/contato-podologa](https://podologialianagoncalves.com.br/contato-podologa)

![Social Meta Image (og:image)](images/img_076_Social_Meta_Image_og_image.png)

---

