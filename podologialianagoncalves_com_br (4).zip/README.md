# Crawl4AI Dataset: podologialianagoncalves_com_br

**URL Original:** https://podologialianagoncalves.com.br/  
**Domínio:** podologialianagoncalves.com.br  
**Data da Extração:** 31/08/2026, 11:45:03  
**Total de Páginas:** 28  
**Total de Imagens Baixadas:** 75  
**Total de Links Internos:** 515  
**Total de Links Externos:** 153  
**Total de Palavras:** 32.317  
**Duração da Varredura:** 26.5 segundos  

---

## 📁 Estrutura do Pacote ZIP

- `manifest.json` - Metadados gerais da extração, configurações usadas e resumo.
- `content_all.md` - Arquivo Markdown unificado com páginas completas e referências a cada imagem com descrição e posição.
- `images_catalog.md` - Catálogo visual completo com todas as imagens, descrições detalhadas, contexto e posições exatas na página.
- `images_catalog.csv` - Tabela CSV de todas as imagens, descrições, posições DOM, seletores CSS e URLs de origem.
- `data.json` - Base de dados completa em JSON com todas as páginas, metadados, links e tags.
- `links.csv` & `links.json` - Mapeamento completo de todos os links internos e externos encontrados.
- `images.json` - Catálogo bruto com todas as referências de imagens encontradas.
- `structured_data.json` - Entidades Schema.org / JSON-LD extraídas.
- `images/` - Todos os arquivos binários das imagens baixadas (JPG, PNG, WebP, SVG, GIF, AVIF) e seu manifesto (`images_manifest.json`).
- `pages/` - Cada página extraída individualmente:
  - `*.md` - Markdown limpo formatado com imagens incorporadas
  - `*.json` - Metadados e dados estruturados da página
  - `*.txt` - Texto plano sem formatação

---

## 🖼️ Mapeamento de Imagens, Descrições e Posições

Todas as imagens encontradas durante a varredura foram automaticamente baixadas para a pasta `images/`.
Cada imagem contém metadados precisos:
1. **Descrição Completa:** Texto alternativo (`alt`), legendas (`<figcaption>`), títulos (`title`) e texto de contexto ao redor.
2. **Posição na Página:** Ordem sequencial DOM (`domIndex`), seção semântica (Header, Hero, Artigo, Galeria, Sidebar, Footer), seletor CSS e título de seção mais próximo (`nearestHeading`).

---

## 🤖 Como Utilizar com Modelos de IA (LLMs) & RAG

Este conjunto de dados foi processado e limpo segundo os padrões do Crawl4AI para maximizar a densidade de informação para LLMs:

1. **RAG / Vector DBs (Pinecone, Chroma, FAISS, Weaviate):** Ingeste o arquivo `content_all.md` ou as páginas individuais em `pages/*.md`.
2. **Context Injection:** Utilize `content_all.md` e `images_catalog.md` diretamente no contexto de prompts do Gemini, Claude ou GPT.
3. **Análise de Imagens & Multimodal:** O manifesto `images/images_manifest.json` e os arquivos em `images/` fornecem a base visual completa com contexto espacial.

---
*Gerado automaticamente pelo Crawl4AI Web Scraper & Archiver.*
