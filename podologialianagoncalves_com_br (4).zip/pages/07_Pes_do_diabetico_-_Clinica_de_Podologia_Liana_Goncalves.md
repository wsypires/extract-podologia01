# Pés do diabetico - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/pes-do-diabetico
- **Data:** 2026-08-31T11:45:07.762Z

---

### 🖼️ Imagens da Página

- **Imagem 1:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #1 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 2:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #2 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 3:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #3 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 4:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #4 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 5:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #5 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 6:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #6 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 7:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #7 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 8:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #8 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 9:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #9 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 10:** Contexto: "<img decoding="async" width="768" height="857" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104-"
  - *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real?
  ![Imagem extraída](../images/img_038_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp)

- **Imagem 11:** Contexto: "<img decoding="async" width="768" height="857" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104-"
  - *Posição:* Posição #11 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real?
  ![Imagem extraída](../images/img_039_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp)

- **Imagem 12:** Contexto: "<img decoding="async" width="768" height="857" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104-"
  - *Posição:* Posição #12 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real?
  ![Imagem extraída](../images/img_040_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp)

- **Imagem 13:** Contexto: "<img decoding="async" width="768" height="857" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104-"
  - *Posição:* Posição #13 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real?
  ![Imagem extraída](../images/img_041_Imagem-do-WhatsApp-de-2023-08-18-as-10_01_31-0-e169824533010.webp)

- **Imagem 14:** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-im"
  - *Posição:* Posição #14 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real?
  ![Imagem extraída](../images/img_042_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

- **Imagem 15:** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-im"
  - *Posição:* Posição #15 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real?
  ![Imagem extraída](../images/img_043_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

- **Imagem 16:** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-im"
  - *Posição:* Posição #16 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real?
  ![Imagem extraída](../images/img_044_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

- **Imagem 17:** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-im"
  - *Posição:* Posição #17 na página • Seção: Conteúdo da Página • Sob H2: Por que um "cortezinho" é um risco real?
  ![Imagem extraída](../images/img_045_O-resultado-que-voce-merece-Protocolo-comprovado-com-alivio-.webp)

- **Imagem 18:** Contexto: "<img loading="lazy" decoding="async" width="720" height="980" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e17731752"
  - *Posição:* Posição #18 na página • Seção: Conteúdo da Página • Sob H2: Formação Específica em Diabetes e Pé Diabético
  ![Imagem extraída](../images/img_010_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399.jpg)

- **Imagem 19:** Contexto: "<img loading="lazy" decoding="async" width="720" height="980" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e17731752"
  - *Posição:* Posição #19 na página • Seção: Conteúdo da Página • Sob H2: Formação Específica em Diabetes e Pé Diabético
  ![Imagem extraída](../images/img_011_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399-220x300.jpg)

- **Imagem 20:** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
  - *Posição:* Posição #20 na página • Seção: Rodapé (Footer)
  ![Clínica de Podologia Liana Gonçalves](../images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

- **Imagem 21:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #21 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_015_Icone_Favicon_do_Site_icon.png)

- **Imagem 22:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #22 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_016_Icone_Favicon_do_Site_icon.png)

- **Imagem 23:** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
  - *Posição:* Posição #23 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (apple-touch-icon)](../images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)

---


[![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)](https://podologialianagoncalves.com.br/)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.)

🩺 Pós-Graduação em Diabetes e Complicações Crônicas

# Segurança máxima para o Pé do Diabético

Para quem tem diabetes, um corte errado pode ser fatal. Proteja sua saúde com um acompanhamento clínico especializado, protocolos de biossegurança e **15 anos de experiência em prevenção de complicações.**

[](whatsapp-float)[Agendar Avaliação Especializada](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.)

★★★★★

**4.9/5 estrelas** baseadas em **207 avaliações reais** no Google

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20768%20857'%3E%3C/svg%3E)

Prevenção é Sobrevivência

## Por que um "cortezinho" é um risco real?

Para quem tem diabetes, a cicatrização é mais lenta e a sensibilidade nos pés pode estar reduzida. Isso significa que você pode se machucar e **não sentir**, abrindo porta para infecções que evoluem rapidamente.

#### ⚠️ O Perigo da Neuropatia

A perda de sensibilidade faz com que muitos diabéticos tentem cortar calos ou unhas em casa e acabem criando feridas profundas sem perceber. Na podologia clínica, isso nunca acontece.

_✓_ Materiais 100% Estéreis (Autoclave)

_✓_ Descartáveis de uso único

_✓_ Ambiente Clínico Rigoroso

_✓_ Técnica Indolor e Segura

[Agendar com Segurança Máxima](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.)

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20768%20960'%3E%3C/svg%3E)

Prevenção é Sobrevivência

## Por que um "cortezinho" é um risco real?

Para quem tem diabetes, a cicatrização é mais lenta e a sensibilidade nos pés pode estar reduzida. Isso significa que você pode se machucar e **não sentir**, abrindo porta para infecções que evoluem rapidamente.

#### ⚠️ O Perigo da Neuropatia

A perda de sensibilidade faz com que muitos diabéticos tentem cortar calos ou unhas em casa e acabem criando feridas profundas sem perceber. Na podologia clínica, isso nunca acontece.

_✓_ Materiais 100% Estéreis (Autoclave)

_✓_ Descartáveis de uso único

_✓_ Ambiente Clínico Rigoroso

_✓_ Técnica Indolor e Segura

[Agendar com Segurança Máxima](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.)

Aviso de Saúde Crítico

## A cada 20 segundos, um diabético perde um pé

No Brasil, a diabetes é a maior causa de amputações não traumáticas. O que começa com uma simples unha encravada ou um calo mal cortado pode se transformar em uma **úlcera profunda** que leva à perda do membro em poucos dias.

#### 🚨 Não espere o pior acontecer

A perda de sensibilidade (neuropatia) é silenciosa. Você pode estar com uma ferida aberta e **não sentir absolutamente nada** até que a infecção atinja o osso. O acompanhamento clínico não é um luxo, é a **única forma de garantir que você continuará caminhando.**

Tratamento conduzido por Especialista com Pós-Graduação em Diabetes e 15 anos de experiência clínica.

[Proteger Meus Pés da Amputação](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.)

## Tire suas dúvidas e proteja sua saúde

### 🧐 Por que eu não posso cortar minhas unhas em casa?

O diabético muitas vezes tem a visão comprometida ou perda de sensibilidade nos pés (neuropatia). Isso faz com que você possa se cortar sem perceber. Um pequeno ferimento pode evoluir para uma infecção óssea e amputação em poucos dias. Na clínica, usamos iluminação cirúrgica e técnica especializada para sua segurança total.

### 📅 De quanto em quanto tempo devo vir à clínica?

O padrão ouro para a segurança do diabético é o acompanhamento mensal. Em 30 dias, unhas crescem e calosidades podem surgir, criando pontos de pressão que geram úlceras invisíveis. A visita mensal garante que qualquer problema seja detectado e resolvido antes de se tornar uma emergência.

### 🩹 Já estou com uma ferida, vocês tratam?

Sim! A Liana possui pós-graduação em Tratamento de Feridas e utiliza protocolos avançados com Laserterapia e Ozonioterapia para acelerar a cicatrização e combater infecções. Se você notou qualquer alteração, a hora de agir é agora.

Sua vida em primeiro lugar

## Proteja seu futuro e sua mobilidade

Não faça parte das estatísticas de amputação. Garanta sua **Consulta Bonificada** ao iniciar seu acompanhamento preventivo hoje.

[Proteger Meus Pés Agora](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.)

A voz de quem viveu

## Mais de 2.000 pacientes.  
207 avaliações. Uma consistência.

★★★★★ 4.9 · média Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

🩺 Especialista em pé diabético · Campo Grande-MS

# Seu pé não sente a dor.  
Mas o estrago acontece  
do mesmo jeito.

A neuropatia diabética silencia os sinais de alerta. Feridas evoluem sem dor. Infecções se aprofundam sem aviso. O acompanhamento especializado não é sobre conforto — é sobre manter seus dois pés.

🚨

**85% das amputações em diabéticos começam com uma lesão pequena e ignorada.** Não porque era inevitável — mas porque não houve acompanhamento especializado a tempo. Esse é exatamente o ciclo que quebramos aqui.

[📲 Agendar Consulta pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.) [Entender os riscos ↓](#pd-riscos)

15 anosde Especialização

2.000+Pacientes Tratados

3 Pós-gradsincl. Diabetes e Feridas

4.9 ★207 Avaliações Google

Entenda o risco

## Por que o Pé do Diabético  
Exige Cuidado Especializado

O diabetes não avisa quando está destruindo os nervos e os vasos dos seus pés. Ele age em silêncio — por meses, por anos. É por isso que o problema chega avançado na maioria das vezes: não faltou atenção, faltou informação sobre o que olhar.

⚡

### Mecanismo 1Neuropatia Diabética

O excesso de glicose danifica os nervos periféricos dos pés ao longo do tempo. O resultado: **perda progressiva da sensibilidade** — dor, calor, pressão e lesões deixam de ser sentidos normalmente.

**Consequência:** Feridas, bolhas, unhas encravadas e calos passam despercebidos e evoluem silenciosamente por dias ou semanas sem que o paciente perceba.

🩸

### Mecanismo 2Doença Vascular Periférica

O diabetes também compromete os vasos sanguíneos, reduzindo o fluxo de sangue para os pés. Com menos circulação, **a capacidade de cicatrização fica gravemente comprometida**.

**Consequência:** Uma ferida que em uma pessoa saudável cicatrizaria em dias, em um diabético pode levar semanas — e facilmente se infectar e se transformar em úlcera.

### Classificação de Risco — Quanto maior o risco, mais intenso o protocolo. Mas o acompanhamento mensal é para todos.

0

#### Sem complicações

Sem neuropatia ou doença vascular. Acompanhamento mensal preventivo para manter esse quadro.

1

#### Neuropatia presente

Sensibilidade já comprometida. Acompanhamento mensal para monitorar progressão e proteger a pele.

2

#### Risco alto

Neuropatia com deformidades ou doença vascular. Protocolo mensal intensivo com avaliação estruturada.

3

#### Risco muito alto

Histórico de úlcera ou amputação. Acompanhamento mensal obrigatório — sem exceção.

⚠️

### Não sabe qual é o seu risco? Você não está sozinho — e tem como descobrir hoje.

A maioria dos pacientes que chega à clínica nunca recebeu uma avaliação formal do risco do pé diabético. Na consulta inicial, Liana realiza a semiologia completa — neurológica, vascular, biomecânica — e você sai sabendo exatamente em que categoria está e o que fazer a partir de agora.

🚨 Não ignore esses sinais

## Sinais de Alerta que  
Todo Diabético Deve Conhecer

O perigo do pé diabético é que muitos sinais graves aparecem **sem dor** — justamente por causa da neuropatia. Se você tem diabetes, esses sinais exigem avaliação imediata.

⚡ Procure hoje

🩹

### Ferida que não cicatriza

Qualquer ferida no pé de um diabético que não fechar em 2 semanas é sinal de comprometimento vascular sério.

⚡ Procure hoje

🔴

### Vermelhidão com calor local

Pode indicar infecção profunda ou Charcot agudo — condição grave que destrói os ossos do pé se não tratada rapidamente.

⚡ Procure hoje

💧

### Secreção ou mau cheiro

Indica infecção ativa. Em diabéticos, infecções se aprofundam rapidamente e podem atingir tendões e ossos.

😶

### Dormência ou formigamento

Sinais clássicos de neuropatia periférica — indicam que a sensibilidade protetora está comprometida.

🦶

### Calos espessos e recorrentes

Em diabéticos, calos aumentam a pressão local e podem gerar úlceras por baixo deles — sem que o paciente sinta.

🌡️

### Pés sempre frios ou quentes

Assimetria de temperatura entre os pés pode indicar doença arterial periférica com redução de fluxo sanguíneo.

O que fazemos

## Condições Tratadas na  
Clínica para Pacientes Diabéticos

🔬

### Avaliação completa

Avaliação completa e biomecânica dos pés — com classificação de risco e protocolo personalizado.

🩹

### Tratamento de úlceras e feridas

Curativos especializados, desbridamento e acompanhamento da cicatrização com laser DMC.

💉

### Unha encravada em diabéticos

Protocolo específico para desencravamento sem risco de infecção — com atenção redobrada à cicatrização.

🦶

### Calos e hiperqueratoses

Remoção especializada de calosidades com identificação e alívio dos pontos de pressão.

✨

### Podoprofilaxia preventiva

Manutenção periódica dos pés para previnir e/ou identificar e tratar problemas antes que virem complicações.

📋

### Orientação e educação em saúde

Ensino de autocuidado: como inspecionar os pés, higiene correta, calçados adequados e quando buscar ajuda.

Como funciona

## Acompanhamento do  
Pé Diabético na Clínica

1

1ª Consulta · R$ 150,00

### Semiologia completa do pé diabético

Avaliação neurológica (sensibilidade, reflexos), vascular (pulsos, temperatura), biomecânica (deformidades, pontos de pressão) e dermatológica (feridas, calos, micoses, unhas). Classificação do risco e definição do protocolo de acompanhamento ideal para o seu caso.

2

Tratamento

### Tudo identificado pode ser tratado na mesma visita

Unhas encravadas, calos, feridas e micoses recebem tratamento imediato com protocolo específico para diabéticos — técnica adaptada, maior cautela na cicatrização e uso de laser DMC quando indicado. Nenhum procedimento é feito sem considerar o quadro sistêmico do paciente.

3

Educação em saúde

### Você aprende a inspecionar os seus pés

Liana ensina o autocuidado correto: como examinar os pés diariamente, o que observar, higiene adequada, como cortar as unhas com segurança, quais calçados usar e em que situações buscar atendimento imediato.

4

Acompanhamento mensal

### Todo diabético merece — e precisa de — um olhar profissional todo mês

Independentemente do grau de risco, recomendamos acompanhamento mensal para todos os nossos pacientes diabéticos. O pé diabético muda mais rápido do que parece: uma calosidade que não existia no mês passado pode estar gerando pressão perigosa agora. A visita mensal é o que permite agir antes — não depois.

Consulta inicial

R$ 150,00

O valor de uma consulta. O peso de uma decisão que protege seus pés para o resto da vida.

-   Semiologia completa do pé diabético
-   Classificação de risco (0 a 3)
-   Tratamento das condições identificadas
-   Plano de acompanhamento personalizado
-   Orientações de autocuidado detalhadas

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.)

### Por que recomendamos acompanhamento mensal para todos?

📅

#### Mudanças acontecem em semanas

Calos, pressões, fissuras e alterações de sensibilidade surgem rapidamente — o intervalo mensal garante que nada passe despercebido

🔬

#### Risco baixo hoje não é risco baixo para sempre

A neuropatia e a doença vascular progressam — o acompanhamento mensal detecta essa evolução e ajusta o protocolo antes que o quadro piore

🛡️

#### Prevenção custa menos do que tratamento

Uma consulta mensal de manutenção evita procedimentos mais complexos — e protege a qualidade de vida a longo prazo

💬

#### Você tem quem perguntar todo mês

Qualquer mudança nos pés que acontecer no intervalo — dúvida, sintoma novo, calçado diferente — tem resposta profissional garantida na próxima visita

**Formas de pagamento:** Pix, débito e crédito em até 10 vezes (sujeito à taxa da operadora). A clínica trabalha somente como particular. Nosso foco é oferecer a melhor qualidade de atendimento, equipamentos e protocolo — sem limitações impostas por convênios.

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20720%20980'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

A especialista responsável

## Formação Específica em  
Diabetes e Pé Diabético

Liana Gonçalves acumulou três pós-graduações diretamente relacionadas ao paciente diabético: Diabetes e Complicações Crônicas, Enfermagem em Dermatologia e Tratamento de Feridas, e Geriatria e Gerontologia — perfil de paciente que concentra os casos mais graves de pé diabético. Além disso, tem especialização em Semiologia do Pé Diabético, que é a avaliação diagnóstica completa que orienta todo o protocolo de cuidados.

Isso significa que ela não trata o pé como um problema isolado. Cada decisão considera o quadro completo do paciente: nível de controle glicêmico, tempo de doença, uso de medicamentos, risco vascular. É o que diferencia o atendimento clínico especializado do cuidado genérico.

### 🎓 Formação específica para pacientes diabéticos

Pós-graduação em Diabetes e Complicações Crônicas · Especialização em Semiologia do Pé Diabético · Participação no CIAP Internacional 2023, 2024 e 2025 — congresso com forte foco em pé diabético e feridas complexas.

✓ Graduação em PodologiaUnicesumar · Nível Superior

✓ Pós-Grad. Dermatologiae Tratamento de Feridas

✓ Laser DMC TherapyiLib e XT — cicatrização avançada

✓ Pós-Grad. Geriatriae Gerontologia

🩺

**Indicada por médicos endocrinologistas e clínicos gerais de Campo Grande** para o acompanhamento especializado dos pés de seus pacientes diabéticos.

Quem já foi atendido

## O Que Nossos Pacientes  
Dizem Sobre o Atendimento

★★★★★ 4.9 · 207 avaliações no Google

★★★★★

"Excelente atendimento, a atenção e o carinho começa na recepção, sou grata por ter a oportunidade de conhecê-las."

T

Telma Miria Pereira Da Silva

Verificado no Google · Out - 2023

★★★★★

"Equipe extremamente cuidadosa, profissionais ótimos, fazem questão de falar cada detalhe do procedimento e te deixar segura"

L

Laura Paniago

Verificado no Google · Jan - 2025

★★★★★

"Alto profissionalismo no atendimento, passando confiança ao cliente, muito cuidado com cada detalhe da sessão. Recepção agradável ."

L

Lucidio Naveira

Verificado no Google · Dez - 2023

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

Dúvidas frequentes

## Perguntas sobre  
Pé do Diabético

Todo diabético precisa de acompanhamento com podóloga? +

Sim — e a frequência ideal é mensal, independentemente do tempo de diagnóstico ou do controle glicêmico. O pé diabético é dinâmico: calosidades surgem, a sensibilidade muda, pontos de pressão aparecem sem aviso. **O acompanhamento mensal é o que garante que qualquer alteração seja identificada e tratada antes de se tornar um problema sério.** Não existe "diabético controlado demais para precisar de acompanhamento" — existe diabético protegido e diabético exposto ao risco.

Tenho uma ferida no pé que não está cicatrizando. É urgente? +

**Sim. Não espere.** Feridas que não cicatrizam em diabéticos são sinal de comprometimento vascular — e podem evoluir para úlceras profundas e infecções graves em questão de dias. Quanto mais cedo for avaliada e tratada, menor o risco de complicações sérias. Entre em contato pelo WhatsApp agora mesmo.

Posso cortar as unhas dos pés em casa sendo diabético? +

Com cuidado e técnica correta, sim — mas há regras importantes. As unhas devem ser cortadas reto, nunca em curva, e nunca muito rente. Nunca use tesoura de ponta fina. Boa iluminação é essencial — muitos diabéticos com neuropatia não percebem quando se machucam. **Liana ensina a técnica correta na consulta.** Para quem tem dificuldade de visão ou mobilidade, a podoprofilaxia periódica é a opção mais segura.

Que tipo de calçado o diabético deve usar? +

Calçados fechados, com bico arredondado e espaço suficiente para os dedos, solado antiderrapante e interior sem costuras salientes. **Nunca andar descalço** — nem em casa. Evitar sandálias abertas que exponham os dedos. Para quem tem deformidades, calçados ortopédicos ou palmilhas personalizadas podem ser indicados. Cada caso é avaliado individualmente na consulta.

A podóloga pode trabalhar em conjunto com meu endocrinologista? +

Sim — e é o modelo ideal de cuidado. Liana trabalha de forma integrada com a equipe médica do paciente, podendo emitir relatórios e encaminhar comunicações ao médico responsável quando necessário. Vários endocrinologistas e clínicos gerais de Campo Grande já indicam a clínica especificamente para esse acompanhamento integrado.

É possível prevenir a amputação com acompanhamento regular? +

**Sim — e essa é exatamente a função do acompanhamento especializado.** Estudos mostram que programas de cuidado preventivo do pé diabético reduzem em até 85% o risco de amputação. A grande maioria das amputações começa com uma pequena lesão ignorada que evolui por falta de tratamento adequado. Identificar e tratar precocemente é o que faz toda a diferença.

🩺 Uma consulta. Um plano. Seus dois pés.

## Você não precisa esperar  
aparecer uma ferida para agir.

Quem tem diabetes sabe que o risco é real. O que muitos ainda não sabem é que com acompanhamento especializado ele é amplamente controlável. Agende agora — saia da consulta sabendo exatamente qual é o seu grau de risco e o que fazer a partir de hoje.

🚨 Ferida no pé que não fecha? Entre em contato hoje — não amanhã.

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.) [📞 (67) 3305-0219](tel:6733050219)

Seg–Sex · 8h às 12h e 13h às 17h  
Rua Doutor Arthur Jorge, 2523 · Campo Grande-MS

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD