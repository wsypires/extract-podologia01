# Podopediatria (Podologia kids) - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/podologia-infantil-podopediatria-especialista-em-criancas
- **Data:** 2026-08-31T11:45:08.147Z

---

### 🖼️ Imagens da Página

- **Imagem 1:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #1 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 2:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #2 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 3:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #3 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 4:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #4 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 5:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #5 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 6:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #6 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 7:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #7 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 8:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #8 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 9:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #9 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 10:** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-768x768.png" class="attachment-medium_large size-me"
  - *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
  ![Imagem extraída](../images/img_046_Design-sem-768x768.png)

- **Imagem 11:** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-768x768.png" class="attachment-medium_large size-me"
  - *Posição:* Posição #11 na página • Seção: Conteúdo da Página • Sob H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
  ![Imagem extraída](../images/img_047_Design-sem-300x300.png)

- **Imagem 12:** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-768x768.png" class="attachment-medium_large size-me"
  - *Posição:* Posição #12 na página • Seção: Conteúdo da Página • Sob H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
  ![Imagem extraída](../images/img_048_Design-sem-1024x1024.png)

- **Imagem 13:** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-768x768.png" class="attachment-medium_large size-me"
  - *Posição:* Posição #13 na página • Seção: Conteúdo da Página • Sob H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
  ![Imagem extraída](../images/img_049_Design-sem-150x150.png)

- **Imagem 14:** Contexto: "<img decoding="async" width="768" height="768" src="https://podologialianagoncalves.com.br/wp-content/uploads/2024/04/Design-sem-768x768.png" class="attachment-medium_large size-me"
  - *Posição:* Posição #14 na página • Seção: Conteúdo da Página • Sob H2: Especialista com 15 Anos Cuidando de Pés de Todas as Idades
  ![Imagem extraída](../images/img_050_Design-sem.png)

- **Imagem 15:** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
  - *Posição:* Posição #15 na página • Seção: Rodapé (Footer)
  ![Clínica de Podologia Liana Gonçalves](../images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

- **Imagem 16:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #16 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_015_Icone_Favicon_do_Site_icon.png)

- **Imagem 17:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #17 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_016_Icone_Favicon_do_Site_icon.png)

- **Imagem 18:** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
  - *Posição:* Posição #18 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (apple-touch-icon)](../images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)

---


![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20meu%20filho%20na%20podopediatria.)

👶 Podologia Especializada para Crianças e Bebês

# Seu filho está com dor  
ou problema nos pés?  
Existe tratamento seguro  
desde o nascimento.

Unhas encravadas em bebês, verrugas, fungos, alterações da marcha — tratamos tudo com técnica especializada, sem anestesia injetável e com os pais presentes durante todo o atendimento.

✅

**Não é preciso esperar a criança crescer para tratar.** Quanto mais cedo o problema é identificado e corrigido, mais simples é o tratamento — e menor o impacto no desenvolvimento dos pés.

[📲 Agendar Consulta Infantil](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20meu%20filho%20na%20podopediatria.) [O que tratamos ↓](#pp-tratamentos)

Do RN Atendemos desde  
recém-nascidos

Sem agulha Anestesia tópica  
e laser

15 anos de experiência  
especializada

4.9 ★ 207 avaliações  
no Google

🦶 Atenção especializada

## Por que o Pé Infantil Precisa de  
Cuidado Especializado

O pé da criança está em desenvolvimento constante — ossos, ligamentos e tendões ainda em formação respondem de forma completamente diferente do adulto. Um problema ignorado hoje pode virar uma alteração permanente na marcha, na postura ou na estrutura do pé adulto.

🦴

### Ossos ainda em formação

Até os 18 anos os ossos do pé ainda se consolidam. Pressões incorretas, calçados inadequados ou alterações não tratadas nessa fase moldam o pé definitivo do adulto.

😶

### A criança não sabe descrever a dor

Bebês choram. Crianças pequenas param de andar, ficam irritadas ou evitam certas atividades. Os sinais estão lá — precisam de um olhar especializado para serem interpretados.

⚡

### Tratamento mais simples quanto antes iniciar

Uma unha encravada em bebê resolve em menos de 1 minuto. Uma verruga tratada cedo é eliminada antes de se multiplicar. A precocidade define a complexidade do tratamento.

👟

**Calçado correto é parte do tratamento.** Em cada consulta pediátrica, a podóloga avalia o calçado que a criança usa e orienta sobre o tipo ideal para cada fase do desenvolvimento — da marcha inicial ao calçado escolar.

O que tratamos

## Condições Tratadas na  
Podopediatria

🩹

### Unha Encravada

Inclusive em recém-nascidos. Tratamento rápido com anestesia tópica — os pais ficam ao lado durante todo o procedimento.

🦠

### Fungos nas Unhas

Diagnóstico laboratorial para identificar o fungo exato e definir o protocolo correto para a idade da criança.

🎯

### Verruga Plantar

Muito comum em crianças. Tratada com laser DMC antes que se multiplique — sem cortes e sem cicatrizes.

🦶

### Calos e Calosidades

Remoção especializada com identificação do ponto de pressão causador — especialmente importante em crianças com alterações de marcha.

🚶

### Alterações da Marcha

Pé chato, pé cavo, marcha na ponta dos pés — avaliação postural e orientação para correção precoce.

🐛

### Bicho de Pé e Micoses

Tunguíase e micoses de pele são comuns em crianças. Tratamento específico e seguro para cada faixa etária.

⚠️

**Seu bebê chora muito, tem vermelhidão no dedo do pé ou febre sem causa aparente?** Pode ser unha encravada — é mais comum em recém-nascidos do que se imagina. Leve ao podólogo antes de tentar resolver em casa.

Como funciona

## Atendimento Infantil:  
Seguro, Rápido e Sem Trauma

1

Consulta · R$ 150,00

### Avaliação clínica completa

A podóloga examina os pés da criança com atenção à faixa etária — unhas, pele, marcha, postura e calçados. Identifica a condição, explica tudo para os pais com clareza e define o protocolo adequado para a idade. **Se o tratamento iniciar no mesmo dia, a consulta é isenta.**

2

Preparação

### Analgesia com laser e anestésico tópico

Nenhum procedimento é feito sem analgesia adequada. Usamos laser DMC e anestésico tópico — **sem agulha, sem anestesia injetável**. Isso é possível porque somos éticos: atuamos apenas dentro do que a regulamentação da podologia permite, e dentro disso entregamos o máximo de conforto para a criança.

3

Procedimento

### Tratamento rápido — os pais ficam ao lado

Em cerca de 95% dos casos o procedimento dura menos de 1 minuto. Os pais acompanham tudo presencialmente — isso reduz a ansiedade da criança e dá segurança à família. Para bebês, o procedimento é feito com a criança no colo do responsável quando possível.

4

Orientações

### Guia completo para os pais

A podóloga orienta como cuidar em casa, como cortar as unhas corretamente, quais calçados usar em cada fase e quando retornar. O acompanhamento não termina na saída da clínica — continuamos disponíveis pelo WhatsApp para dúvidas.

Consulta inicial

R$ 150,00

Isenta se o tratamento iniciar no mesmo dia

-   Avaliação clínica completa adaptada à idade
-   Diagnóstico e plano de tratamento
-   Orientações detalhadas para os pais
-   Avaliação do calçado e da marcha

Procedimentos mais comuns

Unha encravada A partir de R$ 300,00

Verruga plantar Após avaliação

Fungos (consulta completa) R$ 370,00

Calos e calosidades A partir de R$ 150,00

Valor exato definido na consulta conforme grau e complexidade do caso.

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20de%20podopediatria%20para%20meu%20filho.)

### O que garantimos aos pais

👁️

#### Você acompanha tudo

Os pais ficam presentes durante toda a consulta e o procedimento — sem exceção

💉

#### Sem agulha

Anestesia apenas tópica e laser — nenhuma anestesia injetável no pé da criança

⚡

#### Procedimento rápido

Menos de 1 minuto na grande maioria dos casos — respeitando o tempo de atenção e a tolerância de cada criança

📋

#### Explicação total

Tudo é explicado antes de começar — diagnóstico, procedimento, cuidados e expectativa

**Formas de pagamento:** Pix, débito e crédito em até 10 vezes (taxa operadora). Clínica particular — não atendemos convênios.

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20768%20768'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

Quem vai atender seu filho

## Especialista com 15 Anos  
Cuidando de Pés de Todas as Idades

Liana Gonçalves atende crianças desde bebês recém-nascidos com o mesmo cuidado técnico que aplica em adultos — adaptando cada abordagem à faixa etária, ao nível de compreensão e à tolerância de cada paciente. **A podopediatria exige paciência, técnica e sensibilidade que só vêm com experiência real.**

Participante anual do CIAP — maior congresso internacional de podologia, com programação dedicada à podopediatria — e formadora de outros profissionais no Mato Grosso do Sul, Liana traz para cada atendimento infantil o que há de mais atual em técnica pediátrica. Sua formação abrangente em diversas áreas clínicas garante que cada criança seja avaliada no contexto completo da sua saúde — não apenas o sintoma isolado.

✓ Graduação em PodologiaUnicesumar · Nível Superior

✓ Laser DMC TherapyiLib e XT — analgesia infantil

✓ CIAP Internacional2023 · 2024 · 2025

✓ Pós-grad. Dermatologiae Tratamento de Feridas

✓ Tutora de cursos técnicosde Podologia pelo Senac MS

✓ 50+ especializaçõese cursos livres

🩺

**Indicada por pediatras e médicos de Campo Grande** para o acompanhamento podológico de crianças — especialmente em casos de alterações de marcha e unhas encravadas de repetição.

Dúvidas frequentes

## Perguntas sobre  
Podopediatria

Atende bebês recém-nascidos? +

Sim — inclusive recém-nascidos de dias. Casos de unha encravada em bebês são mais comuns do que a maioria imagina, e os sinais são choro excessivo sem causa aparente, vermelhidão e febre. **Quanto mais cedo for tratado, mais simples e rápido é o procedimento.**

O procedimento vai machucar meu filho? +

Essa é a preocupação de todos os pais — e ela é completamente compreensível. Usamos anestésico tópico e laser DMC antes de qualquer procedimento para minimizar ao máximo o desconforto. **Sem agulha, sem anestesia injetável.** Em crianças muito pequenas, quando possível, o procedimento é feito com a criança no colo do responsável. A grande maioria dos pais nos diz que a criança ficou muito mais tranquila do que esperavam.

Posso ficar junto durante o atendimento? +

Sim — e incentivamos isso. Os pais ficam presentes durante toda a consulta e o procedimento, sem exceção. A presença do responsável reduz significativamente a ansiedade da criança e facilita o atendimento. Também aproveitamos para orientar os pais diretamente sobre como cuidar em casa.

A partir de que idade posso levar meu filho? +

Desde o nascimento. Não há idade mínima para a podopediatria — atendemos recém-nascidos, bebês, crianças e adolescentes. Cada faixa etária tem uma abordagem específica adaptada ao desenvolvimento dos pés naquela fase.

Meu filho tem fungo na unha. Tem tratamento para crianças? +

Sim. Fazemos diagnóstico com exame micológico laboratorial para identificar o fungo exato — o mesmo rigor do adulto. O protocolo de tratamento é adaptado à faixa etária, com medicação e técnicas seguras para crianças. **Não use produtos adultos nos pés de criança sem orientação especializada.**

Como saber se meu filho tem problema nos pés? +

Fique atento a: choro ao calçar sapato, recusa de andar, pé avermelhado ou inchado, marcha diferente do esperado, tropeços frequentes, queixa de dor ao caminhar ou correr. Em bebês, choro sem causa aparente associado a vermelhidão no dedo do pé é sinal de alarme. **Em caso de dúvida, traga para avaliação — uma consulta preventiva vale mais do que esperar o problema agravar.**

O que os pais dizem

## Famílias que confiam  
os pés dos filhos à Liana

★★★★★ 4.9 · 207 avaliações no Google

★★★★★

"Acolhedor, ótimo atendimento, passa segurança e confiança. Obrigada!"

L

Luzia Petricio

Verificado no Google

★★★★★

"Atendimento excelente, desde a recepcionista até o procedimento realizado pela doutora Liana. Indico o consultório com certeza!"

A

Avaliação Google

Verificado no Google

★★★★★

"Gostei muito, trabalho sensacional, atenciosos e explicam bem o tratamento para os pés, muito bom mesmo!"

J

Avaliação Google

Verificado no Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

Também atendemos

## Outros Tratamentos para Crianças e a Família

Muitas famílias que chegam pela criança descobrem que outros membros também precisam de cuidado. Aqui na Clínica a família inteira encontra o que precisa.

[🦠

### Fungos nas Unhas

Diagnóstico laboratorial e protocolo especializado. Tratamento disponível para todas as idades.

Saiba mais →](/fungos-micose-onicomicose/) [🩹

### Unha Encravada

Tratamento rápido com alívio imediato. Atendemos adultos, bebês e casos com infecção.

Saiba mais →](/unha-encravada/) [🩺

### Pé do Diabético

Para os pais ou avós diabéticos. Acompanhamento mensal especializado e preventivo.

Saiba mais →](/pe-do-diabetico/) [✨

### Podoprofilaxia

Manutenção preventiva para toda a família — crianças, adultos e idosos.

Saiba mais →](/podoprofilaxia/)

👶 Cuidado que começa cedo

## Seu filho não precisa  
conviver com dor nos pés.

Traga ele para ser examinado — identificamos o problema na primeira consulta e, na maioria dos casos, já iniciamos o tratamento no mesmo dia. Sem agulha, sem trauma, com os pais ao lado.

[📲 Agendar Consulta Infantil](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20de%20podopediatria%20para%20meu%20filho.) [📞 (67) 3305-0219](tel:6733050219)

Seg–Sex · 8h às 12h e 13h às 17h  
Rua Doutor Arthur Jorge, 2523 · Campo Grande-MS

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD