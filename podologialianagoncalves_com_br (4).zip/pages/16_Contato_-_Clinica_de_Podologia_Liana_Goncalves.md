# Contato - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/contato-podologa/
- **Data:** 2026-08-31T11:45:14.547Z

---

### 🖼️ Imagens da Página

- **Imagem 1:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #1 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 2:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #2 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 3:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #3 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 4:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #4 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 5:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #5 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 6:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #6 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 7:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #7 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 8:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #8 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 9:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #9 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 10:** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
  - *Posição:* Posição #10 na página • Seção: Rodapé (Footer)
  ![Clínica de Podologia Liana Gonçalves](../images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

- **Imagem 11:** Texto Alt: "Social Meta Image (og:image)" | Título: "og:image" | Contexto: "Meta tag og:image"
  - *Posição:* Posição #11 na página • Seção: Metadados & Redes Sociais
  ![Social Meta Image (og:image)](../images/img_076_Social_Meta_Image_og_image.png)

- **Imagem 12:** Texto Alt: "Social Meta Image (og:image:width)" | Título: "og:image:width" | Contexto: "Meta tag og:image:width"
  - *Posição:* Posição #12 na página • Seção: Metadados & Redes Sociais
  ![Social Meta Image (og:image:width)](7081)

- **Imagem 13:** Texto Alt: "Social Meta Image (og:image:height)" | Título: "og:image:height" | Contexto: "Meta tag og:image:height"
  - *Posição:* Posição #13 na página • Seção: Metadados & Redes Sociais
  ![Social Meta Image (og:image:height)](3133)

- **Imagem 14:** Texto Alt: "Social Meta Image (og:image:type)" | Título: "og:image:type" | Contexto: "Meta tag og:image:type"
  - *Posição:* Posição #14 na página • Seção: Metadados & Redes Sociais
  ![Social Meta Image (og:image:type)](image/png)

- **Imagem 15:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #15 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_015_Icone_Favicon_do_Site_icon.png)

- **Imagem 16:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #16 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_016_Icone_Favicon_do_Site_icon.png)

- **Imagem 17:** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
  - *Posição:* Posição #17 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (apple-touch-icon)](../images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)

---


[![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)](https://podologialianagoncalves.com.br/)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

📍 Campo Grande-MS

# Agende sua Consulta —  
estamos prontos  
para te atender

O primeiro passo é simples: mande uma mensagem pelo WhatsApp ou ligue. Emily vai encontrar o melhor horário para você.

## Como nos  
encontrar

[

WhatsApp — mais rápido

(67) 99916-0929

Resposta rápida · Seg–Sex · 8h às 12h e 13h às 17h

→

](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)[

☎️

Telefone fixo

(67) 3305-0219

Seg–Sex · 8h às 12h e 13h às 17h

→

](tel:6733050219)[

📱

Celular

(67) 99916-0929

Seg–Sex · 8h às 12h e 13h às 17h

→

](tel:67999160929)[

📍

Endereço

Rua Doutor Arthur Jorge, 2523

Monte Castelo · Campo Grande-MS · CEP 79010-210

→

](https://maps.google.com/?q=Rua+Doutor+Arthur+Jorge+2523+Campo+Grande+MS)

🕐

Horário de Atendimento

Segunda a Sexta

8h às 12h · 13h às 17h

💳

### Formas de pagamento

Pix · Débito · Crédito em até 10x (taxa operadora) · Dinheiro  
Clínica particular — não atendemos convênios

### 📌 Como chegar

A clínica fica na Rua Doutor Arthur Jorge, 2523, no bairro Monte Castelo. Próximo à Av. Afonso Pena. Há estacionamento na rua.

Antes de entrar em contato

## Dúvidas frequentes  
sobre agendamento

Como faço para agendar uma consulta? +

O jeito mais rápido é pelo WhatsApp — mande uma mensagem para **(67) 99916-0929** e Emily vai confirmar o horário disponível. Você também pode ligar para **(67) 3305-0219**. O agendamento é feito de Segunda a Sexta feira · Das 8h às 12h e das 13h às 17h.

Preciso levar algum documento ou exame? +

Não é obrigatório mas facilita o cadastro em nosso sistema para a primeira consulta. Se você tiver exames anteriores relacionados ao problema — como exame micológico para fungo, ou histórico de tratamentos — traga para que a podóloga possa avaliar o histórico completo. Diabéticos devem trazer resultados recentes de glicemia quando disponíveis.

Vocês atendem por convênio ou plano de saúde? +

A clínica é particular. Aceitamos Pix, débito e crédito em até 10 vezes (sujeito à taxa da operadora). Se você tiver plano de saúde com cobertura para podologia, pode solicitar reembolso diretamente à sua operadora — **emitimos nota fiscal de todos os serviços prestados.**

Qual o valor da consulta? +

A consulta inicial custa **R$ 150** e é isenta quando o tratamento é iniciado na mesma sessão. A podoprofilaxia tem valor **a partir de R$ 200,00**. Tratamentos específicos como fungos, verruga plantar e calosidades têm valores definidos na avaliação conforme a complexidade do caso. Não há cobrança surpresa — você recebe o plano completo com valores antes de iniciar qualquer procedimento.

Tem estacionamento próximo? +

Sim. Há vagas de estacionamento na própria Rua Doutor Arthur Jorge e nas ruas adjacentes. Temos uma vaga no interior do prédio disponível para pessoas com dificuldade de locomoção. A clínica fica no bairro Monte Castelo, entre as rua Alegrete e Dolor Ferreira de Andrade, de fácil acesso pela região central de Campo Grande.

Posso levar acompanhante na consulta? +

Sim. No atendimento infantil os pais ficam presentes durante toda a consulta — isso é parte do protocolo da clínica. Para adultos, acompanhantes são bem-vindos, especialmente idosos que precisam de suporte para locomoção.

📲 Fale com a gente agora

## Pronto para cuidar  
dos seus pés de verdade?

Mande uma mensagem pelo WhatsApp — Emily responde rápido e encontra o melhor horário para você. Primeira consulta com avaliação completa.

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.) [📞 (67) 3305-0219](tel:6733050219)

Seg–Sex · 8h às 12h e 13h às 17h  
Rua Doutor Arthur Jorge, 2523 · Monte Castelo · Campo Grande-MS

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD