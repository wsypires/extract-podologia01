# Política de privacidade - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/politica-de-privacidade
- **Data:** 2026-08-31T11:45:15.054Z

---

### 🖼️ Imagens da Página

- **Imagem 1:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #1 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 2:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #2 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 3:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #3 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 4:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #4 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 5:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #5 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 6:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #6 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 7:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #7 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 8:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #8 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 9:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #9 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 10:** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
  - *Posição:* Posição #10 na página • Seção: Rodapé (Footer)
  ![Clínica de Podologia Liana Gonçalves](../images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

- **Imagem 11:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #11 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_015_Icone_Favicon_do_Site_icon.png)

- **Imagem 12:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #12 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_016_Icone_Favicon_do_Site_icon.png)

- **Imagem 13:** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
  - *Posição:* Posição #13 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (apple-touch-icon)](../images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)

---


![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

🔒 LGPD · Lei nº 13.709/2018

# Política de Privacidade

Clínica de Podologia Liana Gonçalves · Última atualização: abril de 2025  
Esta política unificada cobre privacidade, cookies, dados de saúde e direitos do titular.

## Índice

[1\. Quem somos](#pp-01) [2\. Dados que coletamos](#pp-02) [3\. Como usamos os dados](#pp-03) [4\. Base legal (LGPD)](#pp-04) [5\. Dados de saúde](#pp-05) [6\. Compartilhamento](#pp-06) [7\. Cookies e rastreamento](#pp-07) [8\. Retenção dos dados](#pp-08) [9\. Seus direitos](#pp-09) [10\. Segurança](#pp-10) [11\. Menores de idade](#pp-11) [12\. Alterações](#pp-12) [13\. Contato e DPO](#pp-13)

Seção 01

## Quem somos — Controlador dos dados

**Razão social:** HOSPITAL DO PÉ LTDA  
**Responsável:** Liana Gonçalves — Podóloga  
**Endereço:** Rua Doutor Arthur Jorge, 2523 · Monte Castelo · Campo Grande-MS · CEP 79010-210  
**Telefone:** (67) 3305-0219  
**WhatsApp:** (67) 99916-0929  
**Site:** www.podologialiana.com.br

Esta Política de Privacidade se aplica a todos os canais de atendimento da clínica: site, WhatsApp, formulários, atendimento presencial e qualquer outro meio pelo qual você compartilhe dados conosco.

Seção 02

## Quais dados coletamos

Coletamos dados em diferentes momentos do relacionamento com você:

-   **Dados de identificação:** nome completo, CPF (quando necessário para nota fiscal), data de nascimento.
-   **Dados de contato:** número de telefone/WhatsApp, endereço de e-mail.
-   **Dados de saúde (sensíveis):** histórico médico relevante para o tratamento, condições como diabetes, uso de medicamentos, alergias, resultados de exames — coletados exclusivamente para fins clínicos. Veja a Seção 5 para mais detalhes.
-   **Dados de navegação:** endereço IP, tipo de navegador, páginas visitadas, tempo de permanência — coletados automaticamente via cookies e ferramentas de análise. Veja a Seção 7.
-   **Dados de comunicação:** mensagens enviadas pelo WhatsApp, formulários de contato ou e-mail.
-   **Dados financeiros:** forma de pagamento utilizada. Não armazenamos dados de cartão de crédito — as transações são processadas diretamente pelas operadoras.

Seção 03

## Como e para que usamos seus dados

-   Agendamento, confirmação e gestão de consultas e procedimentos
-   Elaboração e manutenção do prontuário clínico
-   Comunicação sobre seu atendimento, retornos e orientações pós-procedimento
-   Envio de lembretes de consulta pelo WhatsApp (quando autorizado)
-   Emissão de nota fiscal e registro financeiro da clínica
-   Cumprimento de obrigações legais e regulatórias
-   Melhoria contínua dos serviços prestados
-   Análise de desempenho do site e campanhas de marketing digital (dados anonimizados ou pseudonimizados)

**Não utilizamos seus dados para fins comerciais não relacionados à sua saúde ou ao atendimento da clínica.** Não vendemos, alugamos ou cedemos dados a terceiros para fins de marketing.

Seção 04

## Base legal para o tratamento (LGPD)

Nos termos da Lei Geral de Proteção de Dados (Lei nº 13.709/2018), tratamos seus dados com base nas seguintes hipóteses legais:

-   **Execução de contrato (art. 7º, V):** para realizar o atendimento, procedimentos e serviços contratados por você.
-   **Consentimento (art. 7º, I e art. 11, I):** para dados sensíveis de saúde coletados no atendimento clínico, mediante consentimento expresso. Para comunicações de marketing, mediante opt-in.
-   **Obrigação legal (art. 7º, II):** para cumprimento de obrigações fiscais, trabalhistas e regulatórias aplicáveis à atividade clínica.
-   **Legítimo interesse (art. 7º, IX):** para análise de desempenho do site e melhoria dos serviços, desde que não prevaleça sobre seus direitos e liberdades fundamentais.
-   **Tutela da saúde (art. 11, II, f):** para dados de saúde necessários ao diagnóstico e tratamento, nos limites do exercício profissional regulamentado.

Seção 05

## Dados de saúde — tratamento especial

### 🩺 Dados sensíveis — proteção reforçada

Dados de saúde são classificados pela LGPD como dados pessoais sensíveis (art. 5º, II) e recebem proteção reforçada. Somente são coletados, armazenados e utilizados para fins estritamente clínicos, por profissional habilitado, mediante consentimento expresso do titular ou de seu responsável legal.

As informações de saúde coletadas durante o atendimento — histórico clínico, diagnósticos, procedimentos realizados, resultados de exames e evoluções — são registradas no prontuário do paciente e tratadas com sigilo profissional, nos termos da ética podológica e da legislação aplicável.

O prontuário do paciente é mantido pelo prazo mínimo de **5 anos** após o último atendimento, conforme orientações do Conselho Regional de Enfermagem e boas práticas da área de saúde. Após esse período, os dados são eliminados de forma segura.

O acesso ao prontuário é restrito à equipe clínica da clínica e, quando aplicável, a terceiros autorizados por você ou por obrigação legal.

Seção 06

## Compartilhamento de dados

Seus dados podem ser compartilhados nas seguintes situações:

-   **Parceiros de tecnologia:** ferramentas de agendamento, prontuário eletrônico, plataforma de site, Google Analytics e Google Ads — todos operando como operadores sob nossas instruções, com obrigações contratuais de proteção de dados.
-   **Autoridades públicas:** quando exigido por lei, decisão judicial ou regulatória.
-   **Outros profissionais de saúde:** apenas com sua autorização expressa, para fins de continuidade do tratamento (encaminhamentos, laudos).
-   **Laboratórios de análise:** para exames como o micológico, com os dados mínimos necessários para a realização do exame.

**Não compartilhamos seus dados com terceiros para fins comerciais ou de marketing sem seu consentimento explícito.**

Seção 07

## Cookies e tecnologias de rastreamento

Nosso site utiliza cookies — pequenos arquivos de texto armazenados no seu navegador — para melhorar sua experiência e analisar o desempenho do site. Abaixo estão os tipos de cookies utilizados:

Tipo

Finalidade

Exemplos

Duração

**Essenciais**

Funcionamento básico do site. Não podem ser desativados.

Sessão WordPress, segurança

Sessão

**Analíticos**

Análise de desempenho e comportamento de navegação (dados anonimizados)

Google Analytics (\_ga, \_gid)

Até 2 anos

**Marketing**

Mensuração de conversões de campanhas Google Ads e remarketing

Google Ads (\_gcl\_au, \_gcl\_aw)

Até 90 dias

**Funcionais**

Preferências do usuário e funcionalidades como chat

Plugin WhatsApp (joinchat)

Variável

**Como gerenciar cookies:** você pode configurar seu navegador para bloquear ou excluir cookies a qualquer momento. Isso pode afetar algumas funcionalidades do site. Nas configurações do Chrome, Firefox, Safari ou Edge, procure por "Cookies e dados do site" para gerenciar suas preferências.

Para optar por não ser rastreado pelo Google Analytics, instale o [complemento de desativação do Google Analytics](https://tools.google.com/dlpage/gaoptout).

Seção 08

## Por quanto tempo guardamos seus dados

-   **Prontuário clínico:** mínimo de 5 anos após o último atendimento, conforme boas práticas da área de saúde.
-   **Dados financeiros e fiscais:** 5 anos, conforme Código Tributário Nacional.
-   **Dados de navegação (cookies analíticos):** até 26 meses conforme política do Google Analytics.
-   **Comunicações por WhatsApp:** mantidas enquanto necessário para o relacionamento e atendimento.
-   **Dados de marketing (Google Ads):** até 90 dias conforme configuração padrão da plataforma.

Ao término do prazo aplicável, os dados são eliminados ou anonimizados, salvo obrigação legal de retenção.

Seção 09

## Seus direitos como titular de dados

A LGPD garante a você os seguintes direitos, que podem ser exercidos a qualquer momento mediante solicitação à clínica:

-   **Confirmação e acesso (art. 18, I e II):** confirmar se tratamos seus dados e acessar uma cópia deles.
-   **Correção (art. 18, III):** solicitar a correção de dados incompletos, inexatos ou desatualizados.
-   **Anonimização, bloqueio ou eliminação (art. 18, IV):** de dados desnecessários, excessivos ou tratados em desconformidade com a LGPD.
-   **Portabilidade (art. 18, V):** receber seus dados em formato estruturado para transferência a outro prestador, quando aplicável.
-   **Eliminação (art. 18, VI):** dos dados tratados com base no consentimento, salvo obrigação legal de retenção.
-   **Informação sobre compartilhamento (art. 18, VII):** saber com quais entidades compartilhamos seus dados.
-   **Revogação do consentimento (art. 18, IX):** retirar seu consentimento a qualquer momento, sem prejuízo do tratamento realizado anteriormente.
-   **Oposição (art. 18, § 2º):** se discordar de algum tratamento realizado com base em legítimo interesse.
-   **Reclamação à ANPD:** você tem o direito de apresentar reclamação à Autoridade Nacional de Proteção de Dados (www.gov.br/anpd).

Para exercer qualquer direito, entre em contato pelo WhatsApp **(67) 99916-0929** ou pelo e-mail da clínica. Responderemos em até **15 dias úteis**.

Seção 10

## Segurança dos dados

Adotamos medidas técnicas e organizacionais adequadas para proteger seus dados contra acesso não autorizado, perda, alteração ou divulgação indevida:

-   Acesso restrito ao prontuário — apenas equipe clínica autorizada
-   Site com certificado SSL (protocolo HTTPS) para criptografia de dados em trânsito
-   Hospedagem em servidor com backups regulares
-   Comunicações por WhatsApp com criptografia de ponta a ponta
-   Senhas de sistemas internos gerenciadas com controle de acesso

Em caso de incidente de segurança que possa acarretar risco ou dano relevante aos titulares, comunicaremos a ANPD e os afetados nos prazos previstos pela LGPD.

Seção 11

## Menores de idade

Atendemos crianças e adolescentes mediante consentimento expresso dos pais ou responsáveis legais. Os dados de saúde de menores são tratados com o mesmo rigor aplicado aos adultos, com proteção reforçada prevista no art. 14 da LGPD e no Estatuto da Criança e do Adolescente.

Não coletamos dados de menores de 18 anos de forma autônoma — qualquer dado é coletado com ciência e autorização do responsável legal, presente durante o atendimento.

Seção 12

## Alterações nesta política

Esta política pode ser atualizada periodicamente para refletir mudanças na legislação, nas práticas da clínica ou nos serviços prestados. A data da última atualização sempre será indicada no topo desta página.

Alterações relevantes serão comunicadas por WhatsApp ou e-mail aos pacientes ativos. O uso continuado dos nossos serviços após a publicação de alterações implica aceitação da nova versão.

**Versão atual:** 2.1 · Publicada em abril de 2025.

Seção 13

## Contato e Encarregado de Dados (DPO)

Para exercer seus direitos, esclarecer dúvidas sobre esta política ou reportar qualquer preocupação sobre privacidade, entre em contato:

📋

### Clínica de Podologia Liana Gonçalves

📍 Rua Doutor Arthur Jorge, 2523 · Monte Castelo · Campo Grande-MS · CEP 79010-210

📞 [(67) 3305-0219](tel:+556733050219)

📲 [(67) 99916-0929](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Tenho%20uma%20d%C3%BAvida%20sobre%20a%20Pol%C3%ADtica%20de%20Privacidade.)

Atendemos solicitações de titulares em até 15 dias úteis · Seg–Sex · 8h às 12h e das 13h às 17h

### 🏛️ Autoridade Nacional de Proteção de Dados (ANPD)

Se considerar que seus direitos não foram atendidos adequadamente, você pode registrar reclamação na ANPD: **www.gov.br/anpd**

**Última atualização:** abril de 2025 · **Versão:** 2.1  
Esta política foi elaborada em conformidade com a Lei Geral de Proteção de Dados Pessoais (Lei nº 13.709/2018) e o Marco Civil da Internet (Lei nº 12.965/2014).

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD