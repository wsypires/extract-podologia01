# Patologias - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/a-podologia
- **Data:** 2026-08-31T11:45:05.654Z

---

### 🖼️ Imagens da Página

- **Imagem 1:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #1 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 2:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #2 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 3:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #3 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 4:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #4 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 5:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #5 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 6:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #6 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 7:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #7 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 8:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #8 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 9:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #9 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 10:** Contexto: "<img decoding="async" width="640" height="664" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/12/Imagem-do-WhatsApp-de-2023-12-13-as-17.55.34_77b6483f-1.webp" "
  - *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Por que escolher a nossa Podologia Clínica?
  ![Imagem extraída](../images/img_024_Imagem-do-WhatsApp-de-2023-12-13-as-17_55_34_77b6483f-1.webp)

- **Imagem 11:** Contexto: "<img decoding="async" width="640" height="664" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/12/Imagem-do-WhatsApp-de-2023-12-13-as-17.55.34_77b6483f-1.webp" "
  - *Posição:* Posição #11 na página • Seção: Conteúdo da Página • Sob H2: Por que escolher a nossa Podologia Clínica?
  ![Imagem extraída](../images/img_025_Imagem-do-WhatsApp-de-2023-12-13-as-17_55_34_77b6483f-1-289x.webp)

- **Imagem 12:** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
  - *Posição:* Posição #12 na página • Seção: Rodapé (Footer)
  ![Clínica de Podologia Liana Gonçalves](../images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

- **Imagem 13:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #13 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_015_Icone_Favicon_do_Site_icon.png)

- **Imagem 14:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #14 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_016_Icone_Favicon_do_Site_icon.png)

- **Imagem 15:** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
  - *Posição:* Posição #15 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (apple-touch-icon)](../images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)

---


[![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)](https://podologialianagoncalves.com.br/)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

🩺 Podologia Clínica — Saúde para seus pés

# Recupere o prazer de caminhar sem dor

Tratamento especializado para Unha Encravada, Fungos, Verrugas e Pé Diabético. Alívio imediato e cuidado clínico com **15 anos de experiência em Campo Grande.**

[Agendar Avaliação pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.) [Conhecer Tratamentos](#tratamentos)

**15 Anos** De Experiência

**2.000+** Pacientes Atendidos

**4.9 ★** Avaliações no Google

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20640%20664'%3E%3C/svg%3E)

Não é Estética, é Saúde

## Por que escolher a nossa Podologia Clínica?

✓

#### Biossegurança Rigorosa

Materiais 100% esterilizados em autoclave e descartáveis de uso único para sua total segurança.

✓

#### Diagnóstico Especializado

Identificamos a causa raiz do seu problema, não apenas tratamos o sintoma superficial.

✓

#### Tecnologia de Ponta

Uso de Laser Terapêutico e equipamentos de última geração para acelerar sua recuperação.

[Quero falar com uma especialista](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

## Nossas especialidades

Identifique seu sintoma e agende uma avaliação para iniciar seu protocolo de cura.

[_🩹_

### Unha Encravada

Alívio imediato da dor e tratamento da infecção com técnicas indolores.

](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20unha%20encravada.)[_🦠_

### Fungos nas Unhas

Protocolos com Laser DMC para eliminação definitiva de micoses resistentes.

](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20fungo%20nas%20unhas.)[_🎯_

### Verruga Plantar

Remoção segura e eficaz do "olho de peixe" com cicatrização acelerada.

](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20verruga%20plantar.)[_🦶_

### Calos e Calosidades

Remoção completa e identificação da causa para evitar que retornem.

](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20calos%20e%20calosidades.)[_🩺_

### Pé Diabético

Acompanhamento preventivo vital para evitar úlceras e complicações graves.

](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20cuidados%20com%20p%C3%A9%20diab%C3%A9tico.)[_✨_

### Podoprofilaxia

A "limpeza profunda" dos pés para manutenção da saúde e prevenção de doenças.

](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20sess%C3%A3o%20de%20podoprofilaxia.)

### 🎁 Consulta com Bônus Especial

A consulta com anamnese, avaliação completa do paciente e apresentação do plano de tratamento tem o valor de R$ 150,00, mas **se você iniciar o tratamento no dia da consulta, esse valor é totalmente abatido.**

[Agendar Minha Avaliação Agora](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

A voz de quem viveu

## Mais de 2.000 pacientes.  
207 avaliações. Uma consistência.

★★★★★ 4.9 · média Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

🩺 Podologia Clínica — Não é Estética, é Saúde

# Todos os tratamentos  
em um só lugar

Da unha encravada ao pé diabético — cada condição tem um protocolo especializado, equipamentos de última geração e 15 anos de experiência clínica.

8 tratamentos  
especializados

2.000+ pacientes  
atendidos

15 anos de experiência  
clínica

4.9 ★ 207 avaliações  
no Google

Tratamentos clínicos

## Escolha o tratamento  
que você precisa

Antes de qualquer tratamento, é indispensável passar pela consulta podológica. É ela que garante um diagnóstico preciso e um protocolo personalizado para o seu caso. A consulta tem valor de R$ 150,00 e, caso você inicie o tratamento no mesmo dia, esse valor é totalmente abatido.

[

Alta demanda 🦠 Onicomicose

### Fungos nas Unhas

Diagnóstico laboratorial, limpeza especializada e laser DMC. Protocolo completo do exame ao acompanhamento.

Consulta **R$ 150,00**

Ver tratamento →

](/fungos-micose-onicomicose/)[

Alta demanda 🩹 Onicocriptose

### Unha Encravada

Alívio imediato na consulta. Atendemos bebês, adultos e casos com infecção. Retornos inclusos no valor.

Consulta **R$ 150,00**

Ver tratamento →

](/unha-encravada/)[

🩺 Diabetes

### Pé do Diabético

Acompanhamento mensal obrigatório para todo diabético. Prevenção de úlceras, amputações e complicações graves.

Consulta **R$ 150,00**

Ver tratamento →

](/pes-do-diabetico/)[

🎯 HPV plantar

### Verruga Plantar (Olho de peixe)

Remoção com protocolo clínico especializado e comprovado, cicatrização rápida e sem recidiva na maioria dos casos.

Consulta **R$ 150,00**

Ver tratamento →

](/olho-de-peixe-verruga-plantar/)[

🦶 Heloma

### Calos e Calosidades

Remoção completa com identificação da causa. Alívio imediato da dor — na maioria dos casos tratado na mesma sessão.

Consulta **R$ 150,00**

Ver tratamento →

](/calos-e-calosidades/)[

👶 Crianças e bebês

### Podopediatria

Desde recém-nascidos. Sem agulha, procedimento rápido e pais presentes durante todo o atendimento.

Consulta **R$ 150,00**

Ver tratamento →

](/podologia-infantil-podopediatria-especialista-em-criancas/)

Prevenção e terapias complementares

## Cuidado preventivo e terapias inovadoras

[✨

### Podoprofilaxia

Manutenção clínica completa dos pés — corte correto das unhas, remoção de calosidades, hidratação e avaliação preventiva. O tratamento mais procurado da clínica. A partir de R$ 200,00.

Saiba mais →](/podoprofilaxia/) [⚡

### Ozonioterapia

Tratamento inovador com ozônio medicinal — Enfermeira especializada com 15 anos de experiência — ação antifúngica, anti-inflamatória e analgésica com multiplos benefícios. Potencializa os resultados de tratamentos.

Saiba mais →](/ozonioterapia/)

📲 Primeira consulta

## Não sabe por onde começar?  
Tire suas dúvidas agora mesmo.

Na primeira consulta identificamos o problema, definimos o tratamento correto e você já sai com um plano claro — valores e prazos incluídos.

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.) [📞 (67) 3305-0219](tel:6733050219)

Seg–Sex · 8h às 12h e 13h às 17h  
Rua Doutor Arthur Jorge, 2523 · Campo Grande-MS

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD