# Unha encravada em bebê - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/unha-encravada-em-bebe
- **Data:** 2026-08-31T11:45:29.806Z

---

### 🖼️ Imagens da Página

- **Imagem 1:** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
  - *Posição:* Posição #1 na página • Seção: Cabeçalho / Navegação (Header)
  ![Imagem extraída](../images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 2:** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
  - *Posição:* Posição #2 na página • Seção: Cabeçalho / Navegação (Header)
  ![Imagem extraída](../images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 3:** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
  - *Posição:* Posição #3 na página • Seção: Cabeçalho / Navegação (Header)
  ![Imagem extraída](../images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 4:** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
  - *Posição:* Posição #4 na página • Seção: Cabeçalho / Navegação (Header)
  ![Imagem extraída](../images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 5:** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
  - *Posição:* Posição #5 na página • Seção: Cabeçalho / Navegação (Header)
  ![Imagem extraída](../images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 6:** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
  - *Posição:* Posição #6 na página • Seção: Cabeçalho / Navegação (Header)
  ![Imagem extraída](../images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 7:** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
  - *Posição:* Posição #7 na página • Seção: Cabeçalho / Navegação (Header)
  ![Imagem extraída](../images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 8:** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
  - *Posição:* Posição #8 na página • Seção: Cabeçalho / Navegação (Header)
  ![Imagem extraída](../images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 9:** Contexto: "<img width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-branco-1-1024x453.pn"
  - *Posição:* Posição #9 na página • Seção: Cabeçalho / Navegação (Header)
  ![Imagem extraída](../images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 10:** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podologia Liana Gonçalve"
  - *Posição:* Posição #10 na página • Seção: Rodapé (Footer)
  ![Clínica de Podologia Liana Gonçalves](../images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

- **Imagem 11:** Texto Alt: "Social Meta Image (og:image)" | Título: "og:image" | Contexto: "Meta tag og:image"
  - *Posição:* Posição #11 na página • Seção: Metadados & Redes Sociais
  ![Social Meta Image (og:image)](../images/img_050_Design-sem.png)

- **Imagem 12:** Texto Alt: "Social Meta Image (og:image:width)" | Título: "og:image:width" | Contexto: "Meta tag og:image:width"
  - *Posição:* Posição #12 na página • Seção: Metadados & Redes Sociais
  ![Social Meta Image (og:image:width)](1080)

- **Imagem 13:** Texto Alt: "Social Meta Image (og:image:type)" | Título: "og:image:type" | Contexto: "Meta tag og:image:type"
  - *Posição:* Posição #13 na página • Seção: Metadados & Redes Sociais
  ![Social Meta Image (og:image:type)](image/png)

- **Imagem 14:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #14 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_015_Icone_Favicon_do_Site_icon.png)

- **Imagem 15:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #15 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_016_Icone_Favicon_do_Site_icon.png)

- **Imagem 16:** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
  - *Posição:* Posição #16 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (apple-touch-icon)](../images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)

---


# Unha encravada em bebê

# Unha encravada em bebê: como identificar e o que fazer

**Categoria:** Podopediatria  
**Tempo de leitura:** 4 min

---

Bebê chorando sem causa aparente é uma das situações mais angustiantes para qualquer pai ou mãe. Fome, sono, cólica — a lista de suspeitos habituais é sempre a mesma. Mas existe uma causa que raramente entra nessa lista, apesar de ser surpreendentemente comum: **a unha encravada**.

## Por que bebês têm unha encravada?

A maioria das pessoas associa unha encravada a adultos que cortam a unha errado ou usam calçado apertado. Em bebês, a causa é diferente — e mais simples.

As unhas dos recém-nascidos são muito finas, maleáveis e crescem rapidamente. Em alguns bebês, especialmente nas primeiras semanas de vida, a pele ao redor do dedão do pé fica mais espessa e envolvente do que a unha consegue empurrar — o que faz com que a borda da unha se encrave no tecido lateral espontaneamente, sem nenhuma intervenção externa.

Não é culpa do corte. Não é culpa do calçado. É anatomia.

## Como identificar

O bebê não consegue dizer onde dói. Os sinais que pedem atenção são:

-   **Choro intenso sem causa aparente**, especialmente ao calçar meia ou roupa no pé
-   **Vermelhidão** na lateral do dedão do pé
-   **Inchaço** na região periungual
-   **Febre** sem outro foco identificado — pode indicar infecção instalada
-   O bebê **afasta o pé** quando você toca a região

Se o dedo estiver com secreção amarelada ou esverdeada, a infecção já está presente e o atendimento deve ser ainda mais imediato.

## O que não fazer

A primeira reação de muitos pais é tentar resolver em casa — empurrar a pele, cortar a ponta da unha, aplicar pomada. Esses procedimentos, sem técnica adequada, podem piorar o encravamento, machucar o tecido e transformar um caso simples em um caso com infecção.

**Não tente remover em casa.** Em bebês especialmente, a margem de erro é pequena.

## Como é o tratamento

Em nossa clínica, o tratamento de unha encravada em bebês é rápido, seguro e feito com os pais presentes — sem exceção.

O procedimento em recém-nascidos e bebês pequenos geralmente dura menos de 1 minuto. Usamos técnica específica para a faixa etária, com analgesia tópica quando necessário, sem agulha injetável. Na maioria dos casos, o alívio é imediato.

Os pais recebem orientações detalhadas sobre como cuidar em casa, como fazer o curativo e o que observar nos dias seguintes.

## A partir de que idade é possível tratar?

Desde o nascimento. Não existe idade mínima para o atendimento podológico. Já atendemos bebês com poucos dias de vida.

---

_Liana Gonçalves é podóloga com 15 anos de experiência, atendendo crianças desde recém-nascidos. Atua em Campo Grande-MS._

**[Agendar consulta pelo WhatsApp →](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Li%20o%20artigo%20sobre%20unha%20encravada%20em%20beb%C3%AA%20e%20gostaria%20de%20agendar%20uma%20consulta.)**

## Deixe um comentário [Cancelar resposta](/unha-encravada-em-bebe/#respond)

O seu endereço de e-mail não será publicado. Campos obrigatórios são marcados com \*

Comentário \*

Nome \* 

E-mail \* 

Site 

 Salvar meus dados neste navegador para a próxima vez que eu comentar.