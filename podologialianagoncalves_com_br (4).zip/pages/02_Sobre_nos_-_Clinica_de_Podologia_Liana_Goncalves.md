# Sobre nós - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/sobre-nos
- **Data:** 2026-08-31T11:45:05.137Z

---

### 🖼️ Imagens da Página

- **Imagem 1:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #1 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 2:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #2 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 3:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #3 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 4:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #4 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 5:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #5 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 6:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #6 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 7:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #7 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 8:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #8 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 9:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #9 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 10:** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-remove"
  - *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Uma paixão que começouem 2011 e nunca parou
  ![Imagem extraída](../images/img_012_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png)

- **Imagem 11:** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-remove"
  - *Posição:* Posição #11 na página • Seção: Conteúdo da Página • Sob H2: Uma paixão que começouem 2011 e nunca parou
  ![Imagem extraída](../images/img_013_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png)

- **Imagem 12:** Contexto: "<img decoding="async" width="720" height="980" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175282399.jpeg" cla"
  - *Posição:* Posição #12 na página • Seção: Conteúdo da Página • Sob H2: Liana Gonçalves
  ![Imagem extraída](../images/img_010_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399.jpg)

- **Imagem 13:** Contexto: "<img decoding="async" width="720" height="980" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175282399.jpeg" cla"
  - *Posição:* Posição #13 na página • Seção: Conteúdo da Página • Sob H2: Liana Gonçalves
  ![Imagem extraída](../images/img_011_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399-220x300.jpg)

- **Imagem 14:** Contexto: "<img loading="lazy" decoding="async" width="400" height="548" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-09-at-10.41.27-1-e177367"
  - *Posição:* Posição #14 na página • Seção: Conteúdo da Página • Sob H3: Marciana Soares
  ![Imagem extraída](../images/img_018_WhatsApp-Image-2026-03-09-at-10_41_27-1-e1773675928249.jpg)

- **Imagem 15:** Contexto: "<img loading="lazy" decoding="async" width="400" height="548" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.13-e17736753"
  - *Posição:* Posição #15 na página • Seção: Conteúdo da Página • Sob H3: Jocineia
  ![Imagem extraída](../images/img_019_WhatsApp-Image-2026-03-16-at-10_59_13-e1773675323462.jpg)

- **Imagem 16:** Contexto: "<img loading="lazy" decoding="async" width="400" height="548" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.13-e17736753"
  - *Posição:* Posição #16 na página • Seção: Conteúdo da Página • Sob H3: Jocineia
  ![Imagem extraída](../images/img_020_WhatsApp-Image-2026-03-16-at-10_59_13-e1773675323462-219x300.jpg)

- **Imagem 17:** Contexto: "<img loading="lazy" decoding="async" width="768" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.11-2-768x10"
  - *Posição:* Posição #17 na página • Seção: Conteúdo da Página • Sob H2: Emily Regis
  ![Imagem extraída](../images/img_021_WhatsApp-Image-2026-03-16-at-10_59_11-2-768x1024.jpg)

- **Imagem 18:** Contexto: "<img loading="lazy" decoding="async" width="768" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.11-2-768x10"
  - *Posição:* Posição #18 na página • Seção: Conteúdo da Página • Sob H2: Emily Regis
  ![Imagem extraída](../images/img_022_WhatsApp-Image-2026-03-16-at-10_59_11-2-225x300.jpg)

- **Imagem 19:** Contexto: "<img loading="lazy" decoding="async" width="768" height="1024" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-16-at-10.59.11-2-768x10"
  - *Posição:* Posição #19 na página • Seção: Conteúdo da Página • Sob H2: Emily Regis
  ![Imagem extraída](../images/img_023_WhatsApp-Image-2026-03-16-at-10_59_11-2.jpg)

- **Imagem 20:** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
  - *Posição:* Posição #20 na página • Seção: Rodapé (Footer)
  ![Clínica de Podologia Liana Gonçalves](../images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

- **Imagem 21:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #21 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_015_Icone_Favicon_do_Site_icon.png)

- **Imagem 22:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #22 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_016_Icone_Favicon_do_Site_icon.png)

- **Imagem 23:** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
  - *Posição:* Posição #23 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (apple-touch-icon)](../images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)

---


[![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)](https://podologialianagoncalves.com.br/)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

Nossa história · Campo Grande-MS

# Nascemos do amor à podologia.  
Crescemos pela _confiança_  
de quem cuidamos.

Desde 2019, a Clínica de Podologia Liana Gonçalves atende Campo Grande com um propósito claro: elevar o nível da podologia clínica no Mato Grosso do Sul — com rigor técnico, atualização constante e cuidado verdadeiramente personalizado.

2011 início da trajetória  
de Liana

2.000+ pacientes  
atendidos

4.9 ★ 207 avaliações  
no Google

50+ cursos e  
especializações

90% taxa de  
sucesso

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20433%20577'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

A origem

## Uma paixão que começou  
em 2011 e nunca parou

2011

### Amor à primeira vista com a podologia

Cursando Recursos Humanos, Alveliana Gonçalves teve seu primeiro contato com a podologia como auxiliar. Foi imediato: **ela abandonou o curso de RH e se dedicou completamente à podologia**. Não foi uma escolha de carreira — foi uma vocação.

2018

### O sonho começa a tomar forma

Depois de 7 anos acumulando experiência, especializações e o olhar clínico que só o tempo constrói, Liana decidiu que Campo Grande merecia **uma podologia em outro nível**. Nasceu o projeto da clínica.

2019

### A Clínica abre as portas

Com equipamentos de última geração — incluindo o laser DMC Therapy iLib e XT, referência do mercado — a Clínica de Podologia Liana Gonçalves começa a atender com um padrão que até então não existia em Campo Grande-MS.

Hoje

### Referência em Mato Grosso do Sul

Mais de 2.000 pacientes atendidos, 207 avaliações 4.9★ no Google, indicada por médicos e dermatologistas da cidade — e formando outros profissionais de podologia no estado. **O sonho virou legado.**

"Focada exclusivamente na saúde dos pés, pois ter pés sem dores é muito importante para o seu bem-estar — e eu cuido de tudo pessoalmente para garantir o nível máximo de qualidade."

— Liana Gonçalves, podóloga responsável

As pessoas por trás do cuidado

## Nossa Equipe

😊

Clínica de podologia Liana Gonçalves

Nossa equipe

Todos os profissionais que atuam em nossa clínica são treinados para estarem sempre prontos para te atender da melhor forma possível sempre que precisar, conheça um pouco mais de cada uma das pessoas que amam cuidar da saúde dos seus pés e melhorar a sua qualidade de vida.

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20720%20980'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

Podóloga Responsável · Fundadora

Podóloga · 15 anos de experiência

## Liana Gonçalves

Graduada em Podologia · Unicesumar · Nível Superior

Liana começou na podologia em 2011 por vocação pura — largou o curso de Recursos Humanos no meio para se dedicar completamente à área. Depois de 7 anos acumulando experiência e especializações, fundou em 2019 a clínica com um propósito claro: **elevar o padrão da podologia clínica em Campo Grande**.

Hoje, além de atender mais de 2.000 pacientes com 90% de taxa de sucesso, **forma outros profissionais de podologia no Mato Grosso do Sul** e participa anualmente do CIAP — o maior congresso internacional de podologia do mundo.

✓ Pós-grad. Diabetese Complicações Crônicas

✓ Pós-grad. Dermatologiae Tratamento de Feridas

✓ Pós-grad. Geriatriae Gerontologia

✓ Laser DMC TherapyiLib e XT

✓ SemiologiaPé Diabético

✓ CIAP Internacional2023 · 2024 · 2025

🩺

**Indicada por médicos e dermatologistas de Campo Grande** — e referência no MS para formação de novos profissionais de podologia.

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20400%20548'%3E%3C/svg%3E)

Marciana da Silva Soares

Enfermeira certificada Ozonioterapeuta · 15 anos

★★★★★

Enfermeira · Ozonioterapeuta

### Marciana Soares

COREN 296.442 · 15 anos de experiência

Marciana traz a visão da enfermagem clínica para potencializar os resultados dos tratamentos podológicos. Responsável pelo serviço de **ozonioterapia da clínica**, é especialista Master O3 e uma das profissionais de referência no tema em Campo Grande-MS.

Graduação em Enfermagem

Especialização Master O3 em Ozonioterapia

15 anos de experiência clínica

Responsável técnica pela ozonioterapia

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20400%20548'%3E%3C/svg%3E)

Jocineia Lima

Podóloga Clínica · Seus pés em boas mãos

★★★★★

Podóloga Clínica

### Jocineia

Podóloga · equipe clínica

Jocineia integra a equipe clínica da Liana Gonçalves atuando com os mesmos protocolos e padrão de excelência que definem cada atendimento da clínica. **Cada paciente recebe o mesmo nível de cuidado, independentemente de qual profissional esteja atendendo** — isso é uma escolha deliberada de cultura, não coincidência.

Podologia clínica

Atendimento com protocolos padronizados da clínica

Tratamentos: onicomicose, unha encravada, calos, podoprofilaxia

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20768%201024'%3E%3C/svg%3E)

O primeiro contato com a clínica

Recepção e Agendamento

## Emily Regis

Recepcionista · atendimento presencial e WhatsApp

Antes de qualquer procedimento, existe um primeiro contato — e ele importa. Emily é a pessoa que recebe cada paciente na porta, responde pelo WhatsApp, organiza a agenda e garante que a experiência na clínica comece da forma certa: **com atenção, clareza e acolhimento genuíno**.

📲

**Agendamentos pelo WhatsApp e telefone** — tira dúvidas sobre valores, horários e como funciona cada tratamento antes da consulta

😊

**Recepção presencial** — recebe cada paciente com o nome e o cuidado que cada pessoa merece desde o momento em que entra

🗂️

**Organização da agenda** — garante que os atendimentos fluam sem atrasos e que cada paciente tenha o tempo necessário para seu caso

"Cuidado começa **antes** do consultório. A experiência que queremos entregar começa já no primeiro 'olá' — seja pelo WhatsApp ou na porta da clínica."

O que nos move

## Os valores que guiam  
cada atendimento

🔬

### Rigor Clínico

Podologia é saúde, não estética. Cada protocolo é baseado em evidência científica e atualizado constantemente — por isso participamos dos principais congressos internacionais da área todo ano.

🎯

### Personalização Real

Não existe protocolo genérico aqui. Cada paciente tem um histórico, um perfil de risco, um ritmo. O plano de tratamento é construído especificamente para você — não para "a condição".

🤝

### Transparência Total

Explicamos o diagnóstico, as opções de tratamento e os custos com clareza. Você toma decisões informado — não porque "a especialista disse". Respeito à autonomia do paciente é inegociável.

📚

### Atualização Permanente

Mais de 50 especializações e cursos acumulados. CIAP Internacional 2023, 2024 e 2025. A podologia avança — e nossa equipe avança junto. O que você recebe hoje é o que há de mais atual na área.

⚡

### Tecnologia de Ponta

Laser DMC Therapy iLib e XT — referência do mercado nacional em laserterapia podológica. Equipamentos de última geração não são diferencial de luxo: são parte do resultado que entregamos.

🏆

### Resultado, Não Aparência

Nosso trabalho é medido em dor zero, mobilidade recuperada, infecções resolvidas, amputações prevenidas. Métricas de saúde — não de estética. Isso é podologia clínica de verdade.

Credenciais e reconhecimento

### Formação que vai além do básico

Cada pós-graduação e especialização foi escolhida para atender melhor os perfis mais complexos — diabéticos, idosos, pacientes com feridas crônicas.

-   Pós-grad. em Diabetes e Complicações Crônicas
-   Pós-grad. em Enfermagem em Dermatologia e Tratamento de Feridas
-   Pós-grad. em Geriatria e Gerontologia
-   Pós-grad. em Nutrição com Ênfase em Obesidade
-   Especialização Master O3 em Ozonioterapia
-   Especialização em Semiologia do Pé Diabético
-   Especialização em Laser — Descomplicando Laserterapia
-   CIAP Internacional 2023 · 2024 · 2025
-   1º Congresso de Podologia MS · XIX Jornada Internacional
-   Forma outros profissionais de podologia no MS

2.000+ Pacientes atendidos

4.9 ★ 207 avaliações no Google

90% Taxa de sucesso nos tratamentos

50+ Cursos e especializações

15 anos de trajetória na podologia

3x CIAP Internacional consecutivo

A voz de quem viveu

## Mais de 2.000 pacientes.  
207 avaliações. Uma consistência.

★★★★★ 4.9 · média Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

🔒 LGPD · Lei nº 13.709/2018

## Nosso compromisso com  
a privacidade dos seus dados

Em nossa clínica, tratamos dados pessoais e de saúde com o mesmo rigor que aplicamos aos nossos procedimentos clínicos. Seus dados são coletados apenas para o que é necessário ao seu atendimento — e protegidos em conformidade com a Lei Geral de Proteção de Dados.

🔒 LGPD Lei nº 13.709/2018  
Em conformidade

🩺

### Dados de saúde protegidos

Informações clínicas são dados sensíveis pela LGPD. Coletamos apenas o necessário para o seu tratamento, com acesso restrito à equipe clínica.

🎯

### Finalidade específica

Seus dados são usados exclusivamente para agendamento, atendimento clínico e comunicação relacionada à sua saúde. Não vendemos nem compartilhamos para fins comerciais.

✅

### Consentimento explícito

Dados sensíveis de saúde são coletados apenas com seu consentimento. Você pode revogar a qualquer momento sem prejuízo do atendimento já realizado.

🛡️

### Armazenamento seguro

Site com SSL, prontuário com acesso restrito e parceiros de tecnologia com obrigações contratuais de proteção. Seus dados não ficam expostos.

👤

### Seus direitos garantidos

Acesso, correção, portabilidade e exclusão dos seus dados. Respondemos solicitações em até 15 dias úteis pelo WhatsApp ou e-mail da clínica.

👶

### Proteção reforçada para menores

Dados de crianças e adolescentes são coletados apenas com consentimento dos responsáveis legais, presentes durante todo o atendimento.

### Política de Privacidade completa

Acesse nossa política unificada — LGPD, cookies, dados de saúde e todos os seus direitos explicados de forma clara e transparente.

[🔒 Ler política completa →](/politica-de-privacidade/)

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD