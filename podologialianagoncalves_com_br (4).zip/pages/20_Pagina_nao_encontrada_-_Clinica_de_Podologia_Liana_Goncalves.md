# Página não encontrada - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/verruga-plantar
- **Data:** 2026-08-31T11:45:21.579Z

---

### 🖼️ Imagens da Página

- **Imagem 1:** Imagem do site
  - *Posição:* Posição #1 na página • Seção: Cabeçalho / Navegação (Header)
  ![Imagem extraída](../images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 2:** Imagem do site
  - *Posição:* Posição #2 na página • Seção: Cabeçalho / Navegação (Header)
  ![Imagem extraída](../images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 3:** Imagem do site
  - *Posição:* Posição #3 na página • Seção: Cabeçalho / Navegação (Header)
  ![Imagem extraída](../images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 4:** Imagem do site
  - *Posição:* Posição #4 na página • Seção: Cabeçalho / Navegação (Header)
  ![Imagem extraída](../images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 5:** Imagem do site
  - *Posição:* Posição #5 na página • Seção: Cabeçalho / Navegação (Header)
  ![Imagem extraída](../images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 6:** Imagem do site
  - *Posição:* Posição #6 na página • Seção: Cabeçalho / Navegação (Header)
  ![Imagem extraída](../images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 7:** Imagem do site
  - *Posição:* Posição #7 na página • Seção: Cabeçalho / Navegação (Header)
  ![Imagem extraída](../images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 8:** Imagem do site
  - *Posição:* Posição #8 na página • Seção: Cabeçalho / Navegação (Header)
  ![Imagem extraída](../images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 9:** Imagem do site
  - *Posição:* Posição #9 na página • Seção: Cabeçalho / Navegação (Header)
  ![Imagem extraída](../images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 10:** Texto Alt: "Clínica de Podologia Liana Gonçalves"
  - *Posição:* Posição #10 na página • Seção: Rodapé (Footer)
  ![Clínica de Podologia Liana Gonçalves](../images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

- **Imagem 11:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #11 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_015_Icone_Favicon_do_Site_icon.png)

- **Imagem 12:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #12 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_016_Icone_Favicon_do_Site_icon.png)

- **Imagem 13:** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
  - *Posição:* Posição #13 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (apple-touch-icon)](../images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)

---


# A página não pode ser encontrada.

Parece que nada foi encontrado neste local.