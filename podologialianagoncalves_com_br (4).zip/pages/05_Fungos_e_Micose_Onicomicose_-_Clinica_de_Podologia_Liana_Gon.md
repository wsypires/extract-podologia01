# Fungos e Micose (Onicomicose) - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/fungos-micose-onicomicose
- **Data:** 2026-08-31T11:45:06.843Z

---

### 🖼️ Imagens da Página

- **Imagem 1:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #1 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 2:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #2 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 3:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #3 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 4:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #4 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 5:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #5 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 6:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #6 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 7:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #7 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 8:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #8 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 9:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #9 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 10:** Contexto: "<img decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104.jpg" title="" alt="" load"
  - *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H2: Por que pomadas e esmaltes raramente funcionam?
  ![Imagem extraída](https://podologialianagoncalves.com.br/wp-content/uploads/2023/10/Imagem-do-WhatsApp-de-2023-08-18-as-10.01.31-0-e1698245330104.jpg)

- **Imagem 11:** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2-768x960.webp" class="attachment-medium_large size-medium_lar"
  - *Posição:* Posição #11 na página • Seção: Conteúdo da Página • Sob H2: A ciência por trás da sua nova unha
  ![Imagem extraída](../images/img_032_2-768x960.webp)

- **Imagem 12:** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2-768x960.webp" class="attachment-medium_large size-medium_lar"
  - *Posição:* Posição #12 na página • Seção: Conteúdo da Página • Sob H2: A ciência por trás da sua nova unha
  ![Imagem extraída](../images/img_033_2-240x300.webp)

- **Imagem 13:** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2-768x960.webp" class="attachment-medium_large size-medium_lar"
  - *Posição:* Posição #13 na página • Seção: Conteúdo da Página • Sob H2: A ciência por trás da sua nova unha
  ![Imagem extraída](../images/img_034_2-819x1024.webp)

- **Imagem 14:** Contexto: "<img decoding="async" width="768" height="960" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/2-768x960.webp" class="attachment-medium_large size-medium_lar"
  - *Posição:* Posição #14 na página • Seção: Conteúdo da Página • Sob H2: A ciência por trás da sua nova unha
  ![Imagem extraída](../images/img_035_2.webp)

- **Imagem 15:** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_c5861866-remove"
  - *Posição:* Posição #15 na página • Seção: Conteúdo da Página • Sob H2: Especialista com15 Anos Tratando Onicomicose
  ![Imagem extraída](../images/img_036_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_c5861866-remov.webp)

- **Imagem 16:** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/04/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_c5861866-remove"
  - *Posição:* Posição #16 na página • Seção: Conteúdo da Página • Sob H2: Especialista com15 Anos Tratando Onicomicose
  ![Imagem extraída](../images/img_037_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_c5861866-remov.webp)

- **Imagem 17:** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
  - *Posição:* Posição #17 na página • Seção: Rodapé (Footer)
  ![Clínica de Podologia Liana Gonçalves](../images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

- **Imagem 18:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #18 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_015_Icone_Favicon_do_Site_icon.png)

- **Imagem 19:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #19 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_016_Icone_Favicon_do_Site_icon.png)

- **Imagem 20:** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
  - *Posição:* Posição #20 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (apple-touch-icon)](../images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)

---


[![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)](https://podologialianagoncalves.com.br/)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20fungo%20nas%20unhas.)

⚡ Protocolo Exclusivo com Laser Terapêutico

# Cansado de esconder seus pés? Elimine os Fungos de vez

Se você já tentou pomadas e esmaltes sem sucesso, conheça o tratamento clínico que atinge a raiz do fungo. Recupere a saúde e a estética das suas unhas com **tecnologia Laser e 15 anos de experiência.**

[Quero Minhas Unhas Saudáveis de Volta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20fungo%20nas%20unhas.)

★★★★★

**4.9/5 estrelas** baseadas em **207 avaliações reais** no Google

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%200%200'%3E%3C/svg%3E)

A Ciência da Cura

## Por que pomadas e esmaltes raramente funcionam?

A unha é uma barreira natural extremamente resistente. Quando você aplica uma pomada, ela **não consegue penetrar** na placa ungueal para atingir o fungo que está por baixo. É por isso que você gasta meses e o fungo sempre volta.

#### 🚫 O Ciclo da Frustração

Remédios caseiros e esmaltes de farmácia tratam apenas a superfície. O fungo continua vivo e se alimentando da queratina na parte profunda da sua unha.

### 💡 A Solução: Laser Terapêutico

O feixe de luz do Laser atravessa a unha sem dor, atingindo diretamente o foco do fungo e eliminando a infecção de dentro para fora.

[Consultar Especialista em Laser](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20fungo%20nas%20unhas.)

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20768%20960'%3E%3C/svg%3E)

Resultados Comprovados

## A ciência por trás da sua nova unha

Ao lado, você vê o que acontece quando unimos tecnologia de ponta com conhecimento clínico. Não é apenas estética; é a recuperação da saúde da sua unha através de um protocolo validado por quem entende de **Dermatologia e Diabetes.**

_✓_ Pós-Graduada em Dermatologia

_✓_ Especialista em Pé Diabético

_✓_ 15 anos eliminando micoses resistentes

"Muitos pacientes chegam desanimados após anos de tentativas. O segredo está no diagnóstico correto e no uso do Laser DMC para esterilizar a área."

[Agendar com a Especialista](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20fungo%20nas%20unhas.)

A voz de quem viveu

## Mais de 2.000 pacientes.  
207 avaliações. Uma consistência.

★★★★★ 4.9 · média Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

## Dúvidas Comuns sobre o Tratamento

### ⏱️ Quanto tempo leva para a unha ficar limpa?

O resultado é visível ja nas primeiras sessões, mas a aparência da unha melhora conforme ela cresce. Uma unha saudável cresce cerca de 1 a 2 milímetros por mês, por isso o acompanhamento mensal é fundamental para garantir que a nova unha nasça 100% livre da infecção.

### 🩹 O Laser dói ou queima?

Absolutamente não. O Laser DMC que utilizamos emite um feixe de luz que gera apenas uma leve sensação de aquecimento, totalmente suportável. É um procedimento seguro, indolor e sem efeitos colaterais.

### 👞 Posso usar sapatos normalmente?

Sim! Diferente de cirurgias, o tratamento a laser não exige repouso. Você sai da clínica e segue sua rotina normalmente. Inclusive, orientamos sobre como higienizar seus calçados para evitar que o fungo retorne.

Tecnologia a seu favor

## Recupere a liberdade dos seus pés

Não espere o fungo destruir toda a sua unha. Comece o seu protocolo hoje com a **Consulta Bonificada** ao fechar o tratamento.

[Quero Minhas Unhas Saudáveis](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20fungo%20nas%20unhas.)

🔬 Tratamento Clínico Especializado

# Fungo nas Unhas?  
Tratamento de Verdade  
— Não Só Pomada

A onicomicose não some com produto de farmácia. O tratamento correto começa com diagnóstico laboratorial e protocolo clínico personalizado — feito por especialista com 15 anos de experiência.

⚠️

**Se você está usando pomada ou esmalte antifúngico há meses sem resultado,** provavelmente o fungo já atingiu a matriz da unha. Quanto mais tempo passa, mais difícil é o tratamento.

[📲 Agendar Consulta pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20fungo%20nas%20unhas.) [Como funciona o tratamento ↓](#como-funciona)

15 anos de Especialização

2.000+ Pacientes Tratados

90% Taxa de Sucesso

4.9 ★ 207 Avaliações Google

Você se identifica?

## Sinais de que Você  
Pode Ter Fungo nas Unhas

A onicomicose raramente causa dor nos estágios iniciais — por isso muita gente ignora até o problema se agravar. Se você percebe qualquer um dos sinais abaixo, o momento de tratar é agora.

🟡

### Unhas amareladas ou marrons

A mudança de cor é um dos primeiros sinais. A unha perde o aspecto saudável e rosado, ficando opaca e descolorida.

📏

### Unha grossa e difícil de cortar

O fungo altera a estrutura da placa ungueal, deixando-a mais espessa, dura e quebradiça do que o normal.

🔍

### Separação da unha do dedo

A onicólise — descolamento da unha — é um sinal avançado de que o fungo está comprometendo a base da una.

💨

### Odor desagradável

A proliferação do fungo entre a unha e a pele pode gerar odor, especialmente após o uso de calçados fechados.

🧩

### Bordas irregulares e quebradiças

A destruição da estrutura da unha faz as bordas se desfazerem facilmente, dificultando até o corte doméstico.

📦

### Meses usando pomada sem resultado

Se você já tentou esmalte ou creme antifúngico e a unha não melhorou, é sinal de que o fungo está na matriz — onde produtos tópicos não chegam.

🚨

### Quanto mais tempo espera, mais unhas são afetadas

O fungo é contagioso e se espalha para as outras unhas — e até para outras pessoas da família. **Um caso de 2 unhas pode virar 8 ou 10 sem tratamento adequado.** Além disso, em pacientes diabéticos o fungo pode abrir porta para infecções sérias que colocam o pé em risco.

Por que não resolve sozinho

## Produto de Farmácia  
Não Elimina o Fungo da Matriz

Esmaltes e cremes antifúngicos agem na superfície da unha. O problema é que o fungo vive na matriz — a raiz da unha — onde nenhum produto tópico consegue penetrar em concentração suficiente para eliminar a infecção. É por isso que o tratamento sem diagnóstico e protocolo clínico raramente funciona.

❌

### Tratamento por conta própria

-   Sem diagnóstico — pode ser psoríase, trauma ou outra condição, não fungo
-   Produto age só na superfície, não chega à matriz da unha
-   Meses de uso sem resultado real — dinheiro perdido
-   O fungo continua se espalhando para outras unhas
-   Risco de piora e contaminação de familiares
-   Sem acompanhamento, sem plano e sem previsão de cura

✅

### Tratamento com protocolo profissional e resultados comprovados

-   Coleta micológica laboratorial para confirmar se é fungo e qual tipo
-   Protocolo clínico personalizado com base no resultado do exame
-   Limpeza especializada da área infectada já na 1ª consulta
-   Laser DMC Therapy iLib e XT — referência no mercado
-   Acompanhamento completo até a resolução do caso
-   Evolução real com resultados desde o início do tratamento

🔬

### Diagnóstico laboratorial: o que diferencia nosso tratamento

Na maioria dos casos de "fungo nas unhas" tratados por conta própria, o diagnóstico é incorreto. Somente o exame micológico confirma se é realmente um fungo — e qual espécie — permitindo escolher o tratamento certo. Em nosso protocolo a coleta para análise e a análise laboratorial estão incluídos na consulta inicial.

Passo a passo

## Como Funciona o  
Tratamento de Fungo nas Unhas

1

1ª Consulta

### Avaliação clínica e coleta micológica

Nossa podóloga avalia o estado das unhas, identifica o grau de comprometimento e realiza a coleta para exame micológico laboratorial. O exame confirma se é fungo (e qual espécie) — base para o tratamento correto. O resultado sai em aproximadamente 15 dias.

2

Ainda na 1ª consulta

### Primeira limpeza especializada

Já na consulta inicial, é realizada a remoção do tecido infectado da área afetada — procedimento que alivia o desconforto e prepara a unha para o tratamento. Sem dor, com técnica especializada.

3

Com resultado do exame

### Plano de tratamento personalizado

Com o laudo em mãos, a podóloga monta o protocolo ideal para o seu caso: combinação de laser DMC, medicação oral e/ou tópica adequada, e frequência de retornos. Cada caso é tratado de forma individual — não existe protocolo genérico aqui.

4

Sessões de acompanhamento

### Laser DMC + limpezas periódicas + aplicação de ozônio

O laser DMC é o equipamento referência do mercado para onicomicose — age diretamente no fungo sem agredir a pele ou a unha. As sessões são combinadas com limpezas clínicas periódicas e aplicações de ozônio o combate ao fungo até a resolução completa.

5

Resultado

### Unhas saudáveis com protocolos testados e resultado real

Você percebe o avanço no tratamento desde a 1ª consulta. O crescimento de unhas novas e saudáveis é progressivo — com acompanhamento até a resolução completa do caso.

### O que está incluso na Consulta Inicial

Tudo que você precisa para começar o tratamento com segurança — em uma única consulta.

R$ 370,00

Consulta inicial · Valor único

Avaliação clínica completa das unhas

Coleta e exame micológico laboratorial

Primeira limpeza especializada

Plano de tratamento personalizado

Orientações para o período em casa

Resultados visíveis desde a 1ª consulta

[📲 Agendar minha consulta agora](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20fungo%20nas%20unhas.)

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20433%20577'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

Quem vai te atender

## Especialista com  
15 Anos Tratando Onicomicose

Liana Gonçalves é graduada em Podologia pela Unicesumar, com pós-graduações em Diabetes, Dermatologia e Tratamento de Feridas. Participa anualmente do CIAP — o principal congresso internacional de podologia — e foi convidada para eventos destinados exclusivamente a médicos.

Não é à toa que médicos e dermatologistas de Campo Grande indicam a clínica para seus pacientes. Com mais de 2.000 pacientes tratados e taxa de sucesso de 90%, você está em mãos experientes.

✓ Graduação em PodologiaUnicesumar · Nível Superior

✓ Pós-Grad. Diabetese Complicações Crônicas

✓ Laser DMC TherapyiLib e XT — referência do mercado

✓ CIAP Internacional2023 · 2024 · 2025

✓ Indicada por médicose dermatologistas de CG

✓ 50+ cursos e especializaçõesem podologia clínica

Dúvidas frequentes

## Perguntas sobre  
Tratamento de Fungo

Quanto custa o tratamento de fungo nas unhas? +

A consulta inicial custa **R$ 370,00** e já inclui avaliação clínica, coleta e exame micológico laboratorial, primeira limpeza e plano de tratamento personalizado. O custo das sessões seguintes varia conforme o protocolo definido após o resultado do exame — que depende do tipo e grau de comprometimento do fungo. Você recebe uma previsão completa de valores logo na primeira consulta, sem surpresas.

O tratamento de fungo nas unhas dói? +

Não. A limpeza clínica e as sessões de laser e ozônio são realizadas com técnica especializada e não causam dor. O laser DMC e o ozônio agem diretamente no fungo sem agredir a pele ou a estrutura da unha. A maioria dos pacientes relata apenas uma leve sensação de calor durante a aplicação.

Quanto tempo leva para o fungo sumir? +

Depende uma série de fatores, como tempo de contaminação, resposta do sistema imunológico, grau de comprometimento das unhas e do número de unhas afetadas. Casos iniciais podem se resolver mais rápido; casos avançados podem levar mais tempo, acompanhando o crescimento da unha saudável. **Todas as informações possíveis são passadas na consulta inicial**, com base no seu exame — não trabalhamos com respostas genéricas.

Por que o esmalte antifúngico da farmácia não funcionou? +

Produtos tópicos agem na superfície da unha, mas o fungo vive na matriz — a raiz. A concentração do princípio ativo não é suficiente para eliminar a infecção na profundidade. Além disso, muitos casos diagnosticados como "fungo" são na verdade psoríase ungueal ou trauma — condições que não respondem a antifúngico. Só o exame micológico confirma o diagnóstico correto.

O plano de saúde cobre o tratamento? +

A clínica trabalha como particular. Aceitamos Pix, débito e crédito em até 10 vezes (sujeito à taxa da operadora). Nosso foco é oferecer a melhor qualidade de atendimento, equipamentos e protocolo — sem limitações impostas por convênios.

Tenho diabetes. Posso fazer o tratamento? +

Sim — e para diabéticos o tratamento é ainda mais urgente. O fungo nas unhas pode evoluir para infecções graves no pé diabético, com risco real de complicações sérias. Liana tem pós-graduação em Diabetes e Complicações Crônicas e especialização em Semiologia do Pé Diabético — é uma das profissionais mais capacitadas de Campo Grande para tratar esse perfil de paciente.

🔬 Comece o tratamento certo

## Chega de tentar  
produto que não resolve.

O tratamento de fungo nas unhas tem solução — com diagnóstico correto e protocolo clínico especializado. Agende sua consulta e saia com um plano real nas mãos.

⏰ Quanto mais cedo, mais simples e rápido é o tratamento

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta%20para%20tratamento%20de%20fungo%20nas%20unhas.) [📞 (67) 3305-0219](tel:6733050219)

Seg–Sex · 8h às 12h e 13h às 17h  
Rua Doutor Arthur Jorge, 2523 · Campo Grande-MS

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD