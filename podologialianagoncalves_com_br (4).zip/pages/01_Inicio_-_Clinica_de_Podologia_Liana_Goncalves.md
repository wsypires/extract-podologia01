# Início - Clínica de Podologia Liana Gonçalves

- **URL:** https://podologialianagoncalves.com.br/
- **Data:** 2026-08-31T11:45:04.400Z

---

### 🖼️ Imagens da Página

- **Imagem 1:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #1 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_001_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 2:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #2 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_002_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 3:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #3 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_003_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 4:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #4 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_004_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 5:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #5 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_005_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 6:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #6 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_006_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 7:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #7 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_007_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 8:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #8 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_008_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 9:** Contexto: "<img fetchpriority="high" decoding="async" width="800" height="354" src="https://podologialianagoncalves.com.br/wp-content/uploads/2020/02/Copia_de_seguranca_de_Copia_de_seguranca_"
  - *Posição:* Posição #9 na página • Seção: Conteúdo da Página
  ![Imagem extraída](../images/img_009_Copia_de_seguranca_de_Copia_de_seguranca_de_Logo-pronta-em-b.png)

- **Imagem 10:** Contexto: "<img decoding="async" width="720" height="980" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175282399.jpeg" cla"
  - *Posição:* Posição #10 na página • Seção: Conteúdo da Página • Sob H1: Seus Pés Merecem Cuidado Clínico. Não Improvisação.
  ![Imagem extraída](../images/img_010_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399.jpg)

- **Imagem 11:** Contexto: "<img decoding="async" width="720" height="980" src="https://podologialianagoncalves.com.br/wp-content/uploads/2026/03/WhatsApp-Image-2026-03-10-at-14.44.51-e1773175282399.jpeg" cla"
  - *Posição:* Posição #11 na página • Seção: Conteúdo da Página • Sob H1: Seus Pés Merecem Cuidado Clínico. Não Improvisação.
  ![Imagem extraída](../images/img_011_WhatsApp-Image-2026-03-10-at-14_44_51-e1773175282399-220x300.jpg)

- **Imagem 12:** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-remove"
  - *Posição:* Posição #12 na página • Seção: Conteúdo da Página • Sob H2: A Profissional que Cuida dos seus Pés
  ![Imagem extraída](../images/img_012_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png)

- **Imagem 13:** Contexto: "<img decoding="async" width="433" height="577" src="https://podologialianagoncalves.com.br/wp-content/uploads/2023/11/Imagem_do_WhatsApp_de_2023-10-07_a_s__11.42.12_88425f7b-remove"
  - *Posição:* Posição #13 na página • Seção: Conteúdo da Página • Sob H2: A Profissional que Cuida dos seus Pés
  ![Imagem extraída](../images/img_013_Imagem_do_WhatsApp_de_2023-10-07_a_s_11_42_12_88425f7b-remov.png)

- **Imagem 14:** Texto Alt: "Clínica de Podologia Liana Gonçalves" | Contexto: "<img width="429" height="202" decoding="async" src="https://podologialianagoncalves.com.br/wp-content/uploads/2025/07/Logo-clinica-2023-512-x-512-pixel.png" alt="Clínica de Podolog"
  - *Posição:* Posição #14 na página • Seção: Rodapé (Footer)
  ![Clínica de Podologia Liana Gonçalves](../images/img_014_Clinica_de_Podologia_Liana_Goncalves.png)

- **Imagem 15:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #15 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_015_Icone_Favicon_do_Site_icon.png)

- **Imagem 16:** Texto Alt: "Ícone / Favicon do Site (icon)" | Título: "icon" | Contexto: "Link tag icon"
  - *Posição:* Posição #16 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (icon)](../images/img_016_Icone_Favicon_do_Site_icon.png)

- **Imagem 17:** Texto Alt: "Ícone / Favicon do Site (apple-touch-icon)" | Título: "apple-touch-icon" | Contexto: "Link tag apple-touch-icon"
  - *Posição:* Posição #17 na página • Seção: Identidade Visual & Ícones
  ![Ícone / Favicon do Site (apple-touch-icon)](../images/img_017_Icone_Favicon_do_Site_apple-touch-icon.png)

---


[![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20800%20354'%3E%3C/svg%3E)](https://podologialianagoncalves.com.br/)

[Ligue agora!](tel:6733050219)

[Agendar Consulta](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

207 Avaliações no Google  |  7 Anos Cuidando dos seus Pés

# Seus Pés Merecem  
Cuidado Clínico.  
Não Improvisação.

Clínica de Podologia Clínica em Campo Grande — MS. Foco exclusivo na **saúde dos seus pés**, com protocolos médicos, equipamentos de ponta e mais de 15 anos de experiência especializada.

Indicada por médicos e dermatologistas de Campo Grande.

2.000+ Pacientes Tratados

90% Taxa de Sucesso

15 anos de Experiência

207 ★ Avaliações Google

[📲 Agendar pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.) [Ver tratamentos →](/a-podologia/)

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20720%20980'%3E%3C/svg%3E)

✓ Indicada por Médicos

e Dermatologistas de CG

Você se identifica?

## Você Está Sofrendo com Algum Desses Problemas?

Problemas nos pés não desaparecem sozinhos — e quanto mais você espera, mais difícil e caro fica o tratamento.

🦠

### Fungos nas Unhas

Unhas amareladas, espessas, quebradiças. Vergonha de usar sandálias. Já tentou pomadas e não resolveu?

[Entender o tratamento →](/fungos-micose-onicomicose/)

😣

### Unha Encravada

Dor intensa a cada passo, inflamação, até pus. Evitando calçados por causa da dor?

[Aliviar a dor hoje →](/unha-encravada/)

🩺

### Pé Diabético

Feridas que não cicatrizam, dormência, formigamento. O diabético precisa de acompanhamento especializado.

[Proteção especializada →](/pes-do-diabetico/)

🦶

### Calos e Calosidades

Dor ao caminhar, fissuras que sangram, pele grossa e endurecida na planta ou calcanhar.

[Resolver agora →](/calos-e-calosidades/)

🎯

### Verruga Plantar

Conhecido como olho de peixe. Dor ao pisar, lesão que cresce e pode se multiplicar se não tratada.

[Ver tratamento →](/olho-de-peixe-verruga-plantar/)

👶

### Podopediatria

Pés de crianças e bebês precisam de atenção especializada. Somos referência em podologia infantil.

[Cuidar dos pequenos →](/podologia-infantil-podopediatria-especialista-em-criancas/)

Não sabe exatamente qual é seu problema? Nossa podóloga identifica na primeira consulta.

[Falar com Especialista →](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

Nosso posicionamento

## Podologia Clínica.  
Não é Estética.  
É Saúde.

A maioria dos concorrentes ainda trata podologia como estética. Aqui, atuamos com a seriedade e os protocolos da medicina — porque os seus pés fazem parte do seu sistema de saúde, e não de um salão de beleza.

Somos indicados por médicos e dermatologistas de Campo Grande porque eles sabem: quando um paciente precisa de podologia clínica de verdade, é aqui que encontra.

🔬

**Exame Micológico Laboratorial**

Identificamos o fungo exato antes de tratar — não chutamos o protocolo.

⚡

**Laser DMC — A Marca Referência do Mercado**

Equipamentos Therapy iLib e XT para resultados precisos e sem dor.

📚

**Congressos Médicos Internacionais**

CIAP 2023, 2024 e 2025 — atualização constante nos melhores eventos da área.

🏥

**Pós-Graduações na Área Clínica**

Diabetes, Dermatologia, Geriatria — formação que vai além da podologia convencional.

15+

Anos de Experiência da Podóloga Liana

2.000+

Pacientes Atendidos e Cadastrados

90%

Taxa de Sucesso nos Tratamentos

207

Avaliações ⭐ Google

🏆

**50+ Cursos e Especializações**

CIAP Internacional · Jornada Internacional de Podologia · Pós-Graduações Clínicas

👩‍⚕️

**Indicada por médicos e dermatologistas de Campo Grande**

Quando um médico indica a nossa clínica, é porque sabe que o paciente vai receber um tratamento com base científica, equipamentos certificados e protocolo individualizado — não um atendimento genérico.

Tratamentos especializados

## Nossos Principais Tratamentos

Cada caso é único. Cada protocolo é personalizado. Isso é o que separa o tratamento eficaz do paliativo.

🦠

### Fungos nas Unhas

Carro-chefe

Diagnóstico com exame micológico laboratorial. Identificamos o fungo exato para o protocolo certo. Protocolo especializado e comprovado.

Consulta inclui

✓ Coleta micológica   ✓ Análise laboratorial  
✓ 1ª limpeza completa   ✓ Plano de tratamento

R$ 370,00  a consulta de fungos com tudo incluso

[Iniciar Tratamento →](/fungos-micose-onicomicose/)

😣

### Unha Encravada

Urgência

Procedimento rápido com alívio imediato da dor. Atendemos casos infeccionados, com granuloma, em bebês e em diabéticos.

O procedimento inclui

✓ Analgesia com laser   ✓ Todos os curativos necessários  
✓ Todos os retornos inclusos   ✓ Alívio imediato

Consulta R$ 150,00  Valor da consulta não é cobrado se fizer o procedimento no mesmo dia da consulta

[Aliviar a Dor Hoje →](/unha-encravada/)

🩺

### Pé do Diabético

Especialidade

Prevenção e tratamento especializado com pós-graduação em Diabetes. Evite úlceras e complicações graves com acompanhamento contínuo.

Nosso diferencial

✓ Pós-graduação em Diabetes   ✓ Ozonioterapia  
✓ Semiologia do pé diabético   ✓ Protocolos atualizados

Consulta R$ 150,00  Valor da consulta não é cobrado se iniciar o tratamento no mesmo dia, valor do tratamento definido na consulta

[Agendar Avaliação →](/pes-do-diabetico/)

[Ver todos os tratamentos →](/a-podologia/)

![](data:image/svg+xml,%3Csvg%20xmlns='https://www.w3.org/2000/svg'%20viewBox='0%200%20433%20577'%3E%3C/svg%3E)

Liana Gonçalves

Podóloga Clínica · 15 anos

★★★★★

Conheça a especialista

## A Profissional que  
Cuida dos seus Pés

Liana Gonçalves começou sua trajetória em 2011, quando abandonou a faculdade de Recursos Humanos ao se apaixonar pela podologia. Desde então, dedicou mais de 15 anos ao estudo e à prática da podologia clínica — com formação técnica, nível superior pela Unicesumar e mais de 50 especializações.

Participa dos principais congressos internacionais da área — incluindo o CIAP (2023, 2024 e 2025) — e foi convidada para eventos voltados exclusivamente a médicos. Não é por acaso que médicos e dermatologistas de Campo Grande indiquem a clínica para seus pacientes.

Palestrante em eventos relevantes nacionalmente como o palco da podologia na beaulty fair 2025, a maior feira de estética e saúde das américas, a segunda maior do mundo. Também atuou como tutora de turmas de curso técnico de podologia pelo Senac MS.

✓ Graduação Nível SuperiorUnicesumar · Campo Grande

✓ Pós-Grad. Diabetese Complicações Crônicas

✓ Pós-Grad. Dermatologiae Tratamento de Feridas

✓ CIAP Internacional2023 · 2024 · 2025

✓ Especialização em LaserDescomplicando Laserterapia

✓ 50+ Cursos Livrese Especializações

[Conhecer toda a trajetória →](/sobre-nos)

A voz de quem viveu

## Mais de 2.000 pacientes.  
207 avaliações. Uma consistência.

★★★★★ 4.9 · média Google

[Ver todas as 207 avaliações no Google →](https://search.google.com/local/reviews?placeid=ChIJdUYMhO7phpURGu-WUmI_6-M)

Dúvidas comuns

## Perguntas Frequentes

O procedimento vai doer? +

Usamos analgesia com laser DMC e anestésico tópico antes de qualquer procedimento. Na unha encravada, por exemplo, o procedimento dura menos de 1 minuto e o alívio da dor é imediato após a retirada da espícula. A grande maioria dos pacientes relata que foi bem menos incômodo do que imaginava.

Quanto custa uma consulta? +

A consulta padrão custa R$ 150 e inclui anamnese completa, exame da patologia e definição do protocolo personalizado. O valor da consulta é isento caso o tratamento seja iniciado no mesmo dia. Para fungos/micose, a consulta é R$ 370 e já inclui coleta para exame micológico laboratorial, primeira limpeza e plano de tratamento.

Vocês atendem plano de saúde? +

Atendemos somente particular. Aceitamos Pix, dinheiro, débito e crédito. Parcelamos em até 10x no cartão de crédito (com taxa da operadora). Nosso foco é oferecer a melhor qualidade de atendimento, equipamentos e protocolo — sem limitações impostas por convênios.

Posso saber o valor por foto antes de ir? +

Não é possível precificar o tratamento por foto — e fazemos isso pela sua segurança. O valor correto só pode ser definido após examinar pessoalmente o grau da patologia, possíveis comorbidades e outros fatores que só a podóloga identifica presencialmente. Isso garante que você receba exatamente o tratamento que precisa, nem mais nem menos.

Diabéticos podem ser atendidos? +

Sim, e é ainda mais importante que diabéticos tenham acompanhamento especializado. A Liana tem pós-graduação em Diabetes e Complicações Crônicas, além de especialização em Semiologia do Pé Diabético. O diabético com problema nos pés não pode esperar — o risco de agravamento é muito maior.

Atendem crianças e bebês? +

Sim! Somos referência em Podopediatria em Campo Grande. Atendemos bebês recém-nascidos — inclusive casos de unha encravada em recém-nascidos, que é mais comum do que se imagina. Nossa estrutura foi preparada para receber os pequenos com todo o cuidado e segurança que eles merecem.

Transparência

## Quanto Custa Cuidar  
da Saúde dos seus Pés?

Acreditamos em transparência. Abaixo os valores de referência — o valor exato do tratamento só é definido após a consulta, pois cada caso é único.

Procedimento / Consulta Investimento

🦠 Consulta de Fungos / Onicomicose

Inclui: coleta micológica · análise laboratorial · 1ª limpeza completa · plano de tratamento

R$ 370,00

😣 Consulta necessária para definir valor

O tratamento inclui: procedimento · curativos · laser · retornos e aconsulta não é cobrada se feito procedimento no mesmo dia

R$ 150,00

🧴 Podoprofilaxia (Limpeza Completa)

Higienização, corte técnico das unhas e cuidados preventivos completos

A partir de R$ 200,00

🦶 Calos, Calosidades e Calo com Núcleo

Remoção especializada com protocolo clínico

A partir de R$ 180,00

🩺 Consulta Geral (demais patologias)

Anamnese · exame clínico · definição do protocolo personalizado. Em todos os atendimentos a consulta não é cobrada caso o tratamento seja contratado no mesmo dia da consulta

R$ 150,00

💳 Parcelamos em até **10x no cartão** (taxa operadora) · Pix · Débito · Dinheiro ⚠️ Valor do tratamento definido após consulta presencial

[Tirar Dúvidas pelo WhatsApp](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.)

⚠️

## Problemas nos Pés não Desaparecem Sozinhos

Fungos ficam mais resistentes com o tempo. Unhas encravadas podem infeccionar e evoluir para granuloma. Pés diabéticos sem acompanhamento chegam à amputação.

Quanto mais cedo você agenda, mais simples e eficaz é o tratamento.

[Agendar Agora pelo WhatsApp →](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Vim%20pelo%20site%20e%20gostaria%20de%20agendar%20uma%20consulta.) [☎ (67) 3305-0219](tel:6733050219)

✓ Aprovado pelo CFM · 2025

## Ozonioterapia  
na mesma clínica

Contamos com a enfermeira Marciana Soares — especialista em ozonioterapia com 15 anos de experiência e equipamento Philozon certificado. 8 técnicas disponíveis para dor crônica, imunidade, fibromialgia, lipedema e muito mais.

[Conhecer a Ozonioterapia →](/ozonioterapia/)

🦵

Dor Crônica

🛡️

Imunidade

🌊

Lipedema

🧘

Fibromialgia

🦶

Fascite Plantar

\+ 7 outras indicações

[Ver todas →](/ozonioterapia/)

Estamos prontos para te atender

## Agende sua Consulta

[

WhatsApp

(67) 99916-0929 · Resposta rápida

→

](https://api.whatsapp.com/send?phone=5567999160929&text=Ol%C3%A1!%20Gostaria%20de%20agendar%20uma%20consulta.)[

☎

Telefone Fixo

(67) 3305-0219

→

](tel:6733050219)[

📍

Endereço

Rua Doutor Arthur Jorge, 2523 · Campo Grande - MS

→

](https://maps.google.com/?q=Rua+Doutor+Arthur+Jorge+2523+Campo+Grande+MS)

🕐

Horário de Funcionamento

Segunda a Sexta · 8h às 12h e 13h às 17h

© 2025 Clínica de Podologia Liana Gonçalves · Todos os direitos reservados

[Política de Privacidade](/politica-de-privacidade/) · [Cookies](/politica-de-privacidade/#pp-07) ·

🔒 LGPD